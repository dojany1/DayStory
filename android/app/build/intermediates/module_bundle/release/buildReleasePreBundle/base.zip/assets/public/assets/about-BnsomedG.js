import{r as e,t}from"./i18n-CAgB5cGO.js";import{t as n}from"./sanitize-DlMVmTsh.js";var r={ko:{title:`DayStory의 시작`,signature:`- 에디터 Lee`,paragraphs:[`제가 이글을 쓰고 있는 2026년의 5월 4일은 다시 오지 않을 날입니다.`,`또한 작년의 5월 4일 재작년의 5월 4일 또한 존재하였고`,`분명 누군가에게 있어서는 뜻깊은 날이었을지도`,`인류 역사에서도 큰일이 있었을 것입니다.`,`문득 생각하였습니다.`,`그동안 얼마나 많은 일이 있었고`,`얼마나 많이 잊혀졌으며`,`얼마나 많이 기억될까요`,`그게 DayStory를 시작한 이유입니다.`,`망각에 흩어지는 날들을 붙잡는데는`,`의미를 부여하는 식으로 잡을 수 있지 않을까라는 생각이었죠`,`저는 인류의 역사에서 있어서`,`일어난 일들을 글로 전달합니다.`,`여러분들은 여러분의 역사를`,`기록하실 수 있습니다.`,`사라지기보다는 살아가기를 원합니다.`]},en:{title:`The Origin of DayStory`,signature:`- Editor Lee`,paragraphs:[`May 4, 2026, the day I write this, is a day that will never return.`,`Yet, there was a May 4th last year, and the year before that.`,`It must have been a meaningful day for someone, and significant events surely took place in human history.`,`A thought crossed my mind.`,`How many things have happened, how many have been forgotten, and how many will be remembered?`,`That is why DayStory began.`,`I believed we could hold onto the days slipping into oblivion by giving them meaning.`,`I share the events of human history through words.`,`Here, you can record your own history.`,`To live, not to leave.`]},ja:{title:`DayStory の始まり`,signature:`- エディター Lee`,paragraphs:[`私がこの文章を書いている 2026 年 5 月 4 日は、二度と来ない日です。`,`しかし、去年の 5 月 4 日も、一昨年の 5 月 4 日も存在し、`,`きっと誰かにとっては意味のある日であっただろうし、`,`人類の歴史においても大きな出来事があったはずです。`,`ふと考えました。`,`これまでどれほど多くのことが起こり、`,`どれほど多くが忘れ去られ、`,`どれほど多くが記憶されるのでしょうか。`,`それが、DayStory を始めた理由です。`,`忘却へ散っていく日々を繋ぎ止めるには、`,`意味を与えることで残せるのではないかと考えたのです。`,`私は人類の歴史において`,`起きた出来事を文章で伝えます。`,`皆さんは皆さん自身の歴史を`,`記録することができます。`,`消えていくのではなく、生きていくことを。`]}};function i(){let i=document.createElement(`div`);i.className=`about-page page`;let a=r[t()]||r.ko,o=a.paragraphs.map(e=>`<p>${n(e)}</p>`).join(``);return i.innerHTML=`
    <div class="page-header page-header-with-back">
      <button class="page-header-back" id="about-back" aria-label="${e(`common.back`)}">
        <svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
          <polyline points="15 18 9 12 15 6"></polyline>
        </svg>
      </button>
      <h1 class="page-header-title">${n(e(`settings.row_about`))}</h1>
      <div class="page-header-spacer"></div>
    </div>

    <article class="about-article">
      <h2 class="about-article-title">${n(a.title)}</h2>
      <div class="about-article-body">
        ${o}
      </div>
      <div class="about-article-signature">${n(a.signature)}</div>
    </article>
  `,i.querySelector(`#about-back`).addEventListener(`click`,()=>history.back()),i}export{i as renderAbout};