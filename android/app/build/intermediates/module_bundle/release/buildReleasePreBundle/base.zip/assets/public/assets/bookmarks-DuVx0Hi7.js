import{r as e}from"./i18n-B_-hulXt.js";import{f as t}from"./stories-CrhQJ4Gf.js";import{i as n,s as r,t as i}from"./storyI18n-jEOB5Mpt.js";import{t as a}from"./toast-C-m3kd2X.js";import{t as o}from"./sanitize-DlMVmTsh.js";import{r as s}from"./index-vbnWQYO-.js";function c(){return`
    <div class="archive-page">
      <div class="archive-section-header">
        <span class="archive-section-label">${e(`bookmarks.section_label`)}</span>
        <div class="search-bar archive-search">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/>
          </svg>
          <input type="text" id="collection-search-input" placeholder="${e(`common.search_placeholder`)}" autocomplete="off" />
          <button type="button" class="search-clear" id="collection-search-clear" aria-label="${e(`common.clear`)}" hidden>
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
              <line x1="6" y1="6" x2="18" y2="18"/><line x1="6" y1="18" x2="18" y2="6"/>
            </svg>
          </button>
        </div>
      </div>
      <div id="archive-content" class="archive-content-loading">
        <div class="loading-spinner"></div>
      </div>
    </div>
  `}function l(e){d(e)}function u(){let t=document.createElement(`div`);return t.className=`archive-page page`,t.innerHTML=`
    <div class="page-header page-header-centered">
      <h1 class="page-header-title">${e(`bookmarks.title`)}</h1>
    </div>
    <div class="archive-section-header">
      <span class="archive-section-label">${e(`bookmarks.section_label`)}</span>
      <div class="search-bar archive-search">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
          <circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/>
        </svg>
        <input type="text" id="collection-search-input" placeholder="${e(`common.search_placeholder`)}" autocomplete="off" />
        <button type="button" class="search-clear" id="collection-search-clear" aria-label="${e(`common.clear`)}" hidden>
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <line x1="6" y1="6" x2="18" y2="18"/><line x1="6" y1="18" x2="18" y2="6"/>
          </svg>
        </button>
      </div>
    </div>
    <div id="archive-content" class="archive-content-loading">
      <div class="loading-spinner"></div>
    </div>
  `,l(t),t}async function d(t){let r=t.querySelector(`#archive-content`),o=(await n().catch(()=>[])||[]).map(i);o.sort((e,t)=>String(t.publish_date||``).localeCompare(String(e.publish_date||``)));let c={bookmarks:o,queryStr:``},l=()=>{p(r,c.queryStr?c.bookmarks.filter(e=>(e.figure_name||``).toLowerCase().includes(c.queryStr)||(e.country||``).toLowerCase().includes(c.queryStr)||(e.summary||``).toLowerCase().includes(c.queryStr)):c.bookmarks,`bookmarks`,e=>h(c,e),{searching:!!c.queryStr})};l();let u=t.querySelector(`#collection-search-input`),d=t.querySelector(`#collection-search-clear`),m=()=>{d&&(d.hidden=!u.value)};u&&u.addEventListener(`input`,e=>{c.queryStr=e.target.value.trim().toLowerCase(),m(),l()}),d&&d.addEventListener(`click`,()=>{u&&(u.value=``,c.queryStr=``,m(),l(),u.focus())});function h(t,n){s(n,`history`,t.bookmarks.map(e=>e.id),{hideHint:!0,onRemove:async n=>{await f(t,n),a(e(`bookmarks.removed`),`success`),l()}})}}async function f(e,t){if(!(!t||!t.id)){try{await r(t.id)}catch{}e.bookmarks=e.bookmarks.filter(e=>e.id!==t.id)}}function p(t,n,r,i,a={}){if(!n.length){t.className=``,t.style.display=`flex`,t.style.padding=``,t.innerHTML=`
      <div class="empty-state">
        <div class="empty-state-title">${a.searching?e(`bookmarks.empty_search`):e(r===`received`?`bookmarks.empty_received`:`bookmarks.empty_mine`)}</div>
        ${!a.searching&&r===`received`?`<div class="empty-state-desc">${e(`bookmarks.empty_received_desc`)}</div>`:``}
      </div>
    `;return}t.className=`archive-grid`,t.style.display=``,t.style.padding=``,t.innerHTML=n.map(e=>m(e)).join(``),t.querySelectorAll(`.history-card-mini`).forEach((e,t)=>{let r=n[t];e.addEventListener(`click`,()=>i(r))})}function m(e){let{valid:n,year:r,month:i,day:a}=t(e),s=n?i:``,c=n?a<10?`0`+a:a:``,l=n?`${r} / ${String(i).padStart(2,`0`)} / ${String(a).padStart(2,`0`)}`:``,u=e.image_url||``,d=u?`src="${o(u)}"`:``;return`
    <div class="history-card-mini" data-story-id="${o(e.id)}">
      <div class="mini-card-top">
        <div class="mini-top-left">
          <div class="mini-year">${o(e.historical_year||``)}</div>
          <div class="mini-date">${s}${s!==``&&c!==``?`. `:``}${c}</div>
        </div>
        <div class="mini-top-right">
          ${o(e.card_count||``)} ${o(e.country||``)}<br>
          ${l}
        </div>
      </div>
      <div class="mini-card-image-wrap">
        <img ${d} alt="${o(e.figure_name||``)}" loading="lazy" decoding="async" />
        <div class="mini-card-overlay">
          ${o(e.figure_name||``)}
        </div>
      </div>
    </div>
  `}export{l as initArchiveSection,c as renderArchiveSection,u as renderBookmarks};