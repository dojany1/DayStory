import{r as e}from"./date-BXCTTgfI.js";import{a as t}from"./router-7m-s0x-D.js";import{n}from"./state-DQ9Huans.js";import{r}from"./i18n-DQjfkUMB.js";import{i,s as a,t as o}from"./storyI18n-CidmYVJi.js";import{t as s}from"./toast-C65VsBgm.js";import{t as c}from"./sanitize-rT1jjWTx.js";import{d as l,i as u}from"./index-BvRF4SpI.js";function d(){return`
    <div class="archive-page">
      ${v()}
      <div id="archive-content" class="archive-content-loading">
        <div class="loading-spinner"></div>
      </div>
    </div>
  `}var f={myStoryClickMode:`navigate`};function p(e,t={}){h(e,{...f,...t})}function m(){let e=document.createElement(`div`);return e.className=`archive-page page`,e.innerHTML=`
    <div class="page-header page-header-centered">
      <h1 class="page-header-title">${r(`bookmarks.title`)}</h1>
    </div>
    ${v()}
    <div id="archive-content" class="archive-content-loading">
      <div class="loading-spinner"></div>
    </div>
  `,p(e),e}async function h(e,a=f){let c=e.querySelector(`#archive-content`),d=n(`user`),[p,m]=await Promise.all([i().catch(()=>[]),d?.id?l(d.id).catch(()=>[]):Promise.resolve([])]),h=(p||[]).map(o);h.sort((e,t)=>String(t.publish_date||``).localeCompare(String(e.publish_date||``)));let v=m||[];v.sort((e,t)=>String(t.publish_date||``).localeCompare(String(e.publish_date||``)));let y={bookmarks:h,myStories:v,activeTab:`history`,queryStr:``},b=()=>{let e=y.activeTab===`history`?y.bookmarks:y.myStories;_(c,y.queryStr?e.filter(e=>y.activeTab===`history`?(e.figure_name||``).toLowerCase().includes(y.queryStr)||(e.country||``).toLowerCase().includes(y.queryStr)||(e.summary||``).toLowerCase().includes(y.queryStr):(e.title||``).toLowerCase().includes(y.queryStr)||(e.body||``).toLowerCase().includes(y.queryStr)):e,y.activeTab,e=>{if(y.activeTab===`history`){T(y,e);return}if(a.myStoryClickMode===`popup`){u(e,`mine`,[],{});return}t(`/mystory`)},{searching:!!y.queryStr,onToggle:y.activeTab===`history`?(e,t)=>{e&&(t?y.bookmarks.some(t=>t.id===e.id)||y.bookmarks.push(e):y.bookmarks=y.bookmarks.filter(t=>t.id!==e.id))}:void 0})};b();let x=e.querySelector(`.archive-toggle`);e.querySelectorAll(`.archive-toggle .calendar-toggle-btn`).forEach(t=>{t.addEventListener(`click`,()=>{let n=t.dataset.tab;if(n===y.activeTab)return;y.activeTab=n,y.queryStr=``;let r=e.querySelector(`#collection-search-input`);r&&(r.value=``),w(),e.querySelectorAll(`.archive-toggle .calendar-toggle-btn`).forEach(e=>e.classList.toggle(`active`,e.dataset.tab===n)),x&&(x.dataset.mode=n),b()})});let S=e.querySelector(`#collection-search-input`),C=e.querySelector(`#collection-search-clear`);function w(){C&&(C.hidden=!S?.value)}S&&S.addEventListener(`input`,e=>{y.queryStr=e.target.value.trim().toLowerCase(),w(),b()}),C&&C.addEventListener(`click`,()=>{S&&(S.value=``,y.queryStr=``,w(),b(),S.focus())});function T(e,t){u(t,`history`,e.bookmarks.map(e=>e.id),{hideHint:!0,onRemove:async t=>{await g(e,t),s(r(`bookmarks.removed`),`success`),b()},onBookmarkChange:(n,r)=>{r?e.bookmarks.some(e=>e.id===n)||e.bookmarks.push(t):e.bookmarks=e.bookmarks.filter(e=>e.id!==n);let i=document.querySelector(`.mini-bookmark-btn[data-story-id="${n}"]`);i&&i.classList.toggle(`active`,r)}})}}async function g(e,t){if(!(!t||!t.id)){try{await a(t.id)}catch{}e.bookmarks=e.bookmarks.filter(e=>e.id!==t.id)}}function _(e,t,n,i,o={}){if(!t.length){e.className=``,e.style.display=`flex`,e.style.padding=``,e.innerHTML=`
      <div class="empty-state">
        <div class="empty-state-title">${o.searching?r(`bookmarks.empty_search`):n===`mine`?`아직 작성한 일화가 없습니다`:r(`bookmarks.empty_mine`)}</div>
      </div>
    `;return}e.className=`archive-grid`,e.style.display=``,e.style.padding=``,e.innerHTML=t.map(e=>n===`mine`?b(e):y(e)).join(``),e.querySelectorAll(`.history-card-mini`).forEach((e,n)=>{let r=t[n];e.addEventListener(`click`,()=>i(r))}),e.querySelectorAll(`.mini-bookmark-btn`).forEach(e=>{e.addEventListener(`click`,async n=>{n.stopPropagation();let r=e.dataset.storyId,i=t.find(e=>e.id===r),s=await a(r);e.classList.toggle(`active`,s.bookmarked),o.onToggle&&o.onToggle(i,s.bookmarked)})})}function v(){return`
    <div class="archive-section-header">
      <div class="calendar-toggle archive-toggle" data-mode="history">
        <button type="button" class="calendar-toggle-btn active" data-tab="history" aria-label="${c(r(`calendar.tab_history`))}">
          <svg viewBox="0 0 24 24" fill="currentColor" stroke="currentColor" stroke-width="2" aria-hidden="true" focusable="false">
            <path d="M19 21l-7-5-7 5V5a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2z"/>
          </svg>
        </button>
        <button type="button" class="calendar-toggle-btn" data-tab="mine">나의 카드</button>
        <span class="calendar-toggle-thumb" aria-hidden="true"></span>
      </div>
      <div class="search-bar archive-search">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
          <circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/>
        </svg>
        <input type="text" id="collection-search-input" placeholder="${r(`common.search_placeholder`)}" autocomplete="off" />
        <button type="button" class="search-clear" id="collection-search-clear" aria-label="${r(`common.clear`)}" hidden>
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <line x1="6" y1="6" x2="18" y2="18"/><line x1="6" y1="18" x2="18" y2="6"/>
          </svg>
        </button>
      </div>
    </div>
  `}function y(t){let{valid:n,year:r,month:i,day:a}=e(t),o=n?i:``,s=n?a<10?`0`+a:a:``,l=n?`${r} / ${String(i).padStart(2,`0`)} / ${String(a).padStart(2,`0`)}`:``,u=t.image_url||``,d=u?`src="${c(u)}"`:``;return`
    <div class="history-card-mini" data-story-id="${c(t.id)}">
      <div class="mini-card-top">
        <div class="mini-top-left">
          <div class="mini-year">${c(t.historical_year||``)}</div>
          <div class="mini-date">${o}${o!==``&&s!==``?`. `:``}${s}</div>
        </div>
        <div class="mini-top-right">
          <button class="mini-bookmark-btn bookmark-btn active" data-story-id="${c(t.id)}" aria-label="북마크">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
              <path d="M19 21l-7-5-7 5V5a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2z"/>
            </svg>
          </button>
          <span class="mini-top-text">
            ${c(t.card_count||``)} ${c(t.country||``)}<br>
            ${l}
          </span>
        </div>
      </div>
      <div class="mini-card-image-wrap">
        <img ${d} alt="${c(t.figure_name||``)}" loading="lazy" decoding="async" />
        <div class="mini-card-overlay">
          ${c(t.figure_name||``)}
        </div>
      </div>
    </div>
  `}function b(e){let[t=``,n=``,r=``]=(e.publish_date||``).split(`-`),i=c(e.image_url||e.image_thumb_url||``);return`
    <div class="history-card-mini my-story-mini" data-story-id="${c(e.id||``)}">
      <div class="mini-card-top">
        <div class="mini-top-left">
          <div class="mini-date">${n}. ${r}</div>
        </div>
        <span class="mini-top-text">${c(t)}</span>
      </div>
      <div class="mini-card-image-wrap">
        ${i?`<img src="${i}" alt="" loading="lazy" decoding="async" />`:`<div class="mini-card-no-image"></div>`}
        <div class="mini-card-overlay">${c(e.title||``)}</div>
      </div>
    </div>
  `}export{p as initArchiveSection,d as renderArchiveSection,m as renderBookmarks};