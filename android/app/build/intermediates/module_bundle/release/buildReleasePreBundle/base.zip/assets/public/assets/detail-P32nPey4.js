import{r as e}from"./i18n-CAgB5cGO.js";import{a as t}from"./stories-DjoDJ8Ga.js";import{n,o as r,r as i,s as a,t as o}from"./storyI18n-D4h3I9Tp.js";import{t as s}from"./toast-DL5HJnQ3.js";import{n as c,t as l}from"./sanitize-DlMVmTsh.js";function u(e){if(!e)return null;if(typeof e==`string`){let[t,...n]=e.split(`|`),r=t.trim(),i=n.join(`|`).trim();return!r&&!i?null:{title:r||i,url:i}}if(typeof e==`object`){let t=String(e.title||e.name||e.label||e.text||``).trim(),n=String(e.url||e.href||``).trim();return!t&&!n?null:{title:t||n,url:n}}return null}function d(e){return(Array.isArray(e)?e:String(e||``).split(`
`)).map(u).filter(Boolean)}function f(e,t){let n=String(e.image_source||``).trim(),r=String(e.image_license||``).trim(),i=n||r;return!i&&!t.length?``:`
    <section class="detail-attribution" aria-label="이미지 출처 및 참고 자료">
      ${i?`
        <div class="detail-license">
          <div class="detail-sources-title">이미지 출처</div>
          <div class="detail-license-text">
            ${n?`<div>출처: ${l(n)}</div>`:``}
            ${r?`<div>라이선스: ${l(r)}</div>`:``}
          </div>
        </div>
      `:``}
      ${t.length?`
        <div class="detail-sources">
          <div class="detail-sources-title">참고 자료</div>
          ${t.map(e=>{let t=l(e.title),n=c(e.url);return n?`
              <a href="${n}" target="_blank" rel="noopener" class="detail-source-item">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" style="width:14px;height:14px;flex-shrink:0">
                  <path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"/>
                  <polyline points="15 3 21 3 21 9"/><line x1="10" y1="14" x2="21" y2="3"/>
                </svg>
                ${t}
              </a>
            `:`<div class="detail-source-item detail-source-text">${t}</div>`}).join(``)}
        </div>
      `:``}
    </section>
  `}function p(e){let t=document.createElement(`div`);return t.className=`detail-page page`,t.innerHTML=`
    <div style="display:flex;justify-content:center;align-items:center;min-height:60vh;">
      <div class="loading-spinner"></div>
    </div>
  `,m(t,e.id),t}async function m(c,u){let p=await t(u);if(!p){c.innerHTML=`
      <div class="empty-state">
        <div class="empty-state-title">${e(`common.load_failed_title`)}</div>
      </div>
    `;return}let m=o(p),h=await r(u),g=new Date(m.publish_date),_=g.getMonth()+1,v=g.getDate(),y=m.body.split(`
`).filter(e=>e.trim()).map(e=>`<p>${l(e)}</p>`).join(``),b=(m.editor_comment||m.editor&&m.editor.comment||``).trim(),x=(m.editor&&m.editor.displayName||`DayStory`).trim()||`DayStory`,S=m.editor&&m.editor.photoURL||``,C=l(b).replace(/\n/g,`<br />`),w=[m.historical_date,m.country].map(e=>String(e??``).trim()).filter(Boolean).map(e=>l(e)).join(` · `),T=f(m,d(m.story_sources||m.sources||[]));c.innerHTML=`
    <!-- 상단 헤더: 뒤로가기 -->
    <div class="detail-header" id="detail-header">
      <button class="page-header-back" id="detail-back">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
          <polyline points="15 18 9 12 15 6"/>
        </svg>
      </button>
    </div>

    <!-- 히어로 이미지 영역 -->
    <div class="detail-hero">
      <img src="${l(m.image_url)}" alt="${l(m.figure_name)}" loading="eager" decoding="async" fetchpriority="high" width="1200" height="1500" />
      <div class="detail-hero-overlay">
        <div class="detail-hero-year">${l(m.historical_year)}</div>
        <div class="detail-hero-monthday">${_}. ${v<10?`0`+v:v}</div>
      </div>
    </div>

    <!-- 본문 영역 -->
    <div class="detail-content">
      <div class="detail-title-row">
        <h1 class="detail-figure-name">${l(m.figure_name)}</h1>
        <div class="detail-title-actions">
          <button class="btn-icon bookmark-btn ${h?`active`:``}" id="detail-bookmark" aria-label="보관함">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
              <path d="M19 21l-7-5-7 5V5a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2z"/>
            </svg>
          </button>
          <button class="btn-icon" id="detail-share" aria-label="공유">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
              <circle cx="18" cy="5" r="3"/><circle cx="6" cy="12" r="3"/><circle cx="18" cy="19" r="3"/>
              <line x1="8.59" y1="13.51" x2="15.42" y2="17.49"/>
              <line x1="15.41" y1="6.51" x2="8.59" y2="10.49"/>
            </svg>
          </button>
        </div>
      </div>
      <div class="detail-body">${y}</div>
      <div class="detail-historical-date">${w}</div>
      ${b?`
        <section class="detail-editor-note" aria-label="에디터의 말">
          <div class="detail-editor-note-header">
            <div class="detail-editor-avatar-wrap">
              ${S?`<img class="detail-editor-avatar" src="${l(S)}" alt="${l(x)}" loading="lazy" decoding="async" />`:`<span class="detail-editor-avatar-fallback" aria-hidden="true">D</span>`}
            </div>
            <div class="detail-editor-name">${l(x)}</div>
          </div>
          <p class="detail-editor-note-text">${C}</p>
        </section>
      `:``}
      ${T}
    </div>
  `,document.getElementById(`detail-back`)?.addEventListener(`click`,()=>window.history.back()),document.getElementById(`detail-bookmark`)?.addEventListener(`click`,async()=>{let e=await a(u);if(e.error){s(e.error,`error`);return}h=e.bookmarked,c.querySelectorAll(`#detail-bookmark`).forEach(e=>{e.classList.toggle(`active`,h)}),s(h?`보관함에 저장했습니다`:`보관함에서 해제했습니다`,`success`)}),document.getElementById(`detail-share`)?.addEventListener(`click`,async()=>{if(navigator.share){await i(m,{kind:`history`});return}try{let e=n(m.id);await navigator.clipboard.writeText(`[DayStory] ${m.figure_name}\n\n${m.summary||``}\n${e}`),s(`클립보드에 복사했습니다`,`success`)}catch{}})}export{p as renderDetail};