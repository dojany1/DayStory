import{i as e,n as t,o as n,r,t as i}from"./cropper-RFou76ed.js";import{a,s as o}from"./router-hybKseu2.js";import{n as s}from"./state-8PRbPWwW.js";import{t as c}from"./firebase-DGvE0Cu9.js";import{a as l,c as u,l as d,n as f,t as p}from"./stories-DlcbpjXX.js";import{t as m}from"./toast-C-m3kd2X.js";import{n as h,t as g}from"./sanitize-DlMVmTsh.js";import{a as _,o as v,s as y}from"./index-b529ZtNJ.js";var b=n(i(),1),x=4/5;function S(){let e=document.createElement(`div`);e.className=`editor-page page`;let t=s(`profile`);if(!t||t.role!==`editor`)return e.innerHTML=`
      <div class="page-header"><h1 class="page-header-title">에디터</h1></div>
      <div class="empty-state">
        <div class="empty-state-title">에디터 권한이 필요합니다</div>
        <div class="empty-state-desc">관리자에게 에디터 권한을 요청하세요</div>
      </div>
    `,e;e.innerHTML=`
    <div class="editor-calendar-header calendar-header">
      <div class="editor-calendar-title-row">
        <button class="page-header-back" id="editor-back" aria-label="뒤로가기">
          <svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 19l-7-7 7-7"></path></svg>
        </button>
        <h1 class="calendar-title">콘텐츠 관리</h1>
      </div>
    </div>

    <div class="editor-stats" id="editor-stats">
      <button type="button" class="editor-stat active" data-filter="all"><span class="editor-stat-label">전체</span><span class="editor-stat-value" id="stat-total">-</span></button>
      <button type="button" class="editor-stat" data-filter="published"><span class="editor-stat-label">발행</span><span class="editor-stat-value" id="stat-published">-</span></button>
      <button type="button" class="editor-stat" data-filter="scheduled"><span class="editor-stat-label">예약</span><span class="editor-stat-value" id="stat-scheduled">-</span></button>
      <button type="button" class="editor-stat" data-filter="draft"><span class="editor-stat-label">초안</span><span class="editor-stat-value" id="stat-draft">-</span></button>
    </div>

    <div class="calendar-month-nav editor-month-nav">
      <button type="button" class="calendar-month-arrow" id="editor-prev-month" aria-label="이전 달">
        <svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2"><path d="M15 18l-6-6 6-6"/></svg>
      </button>
      <div class="calendar-month-label" id="editor-month-label">-</div>
      <button type="button" class="calendar-month-arrow" id="editor-next-month" aria-label="다음 달">
        <svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2"><path d="M9 18l6-6-6-6"/></svg>
      </button>
    </div>

    <div class="calendar-weekdays editor-calendar-weekdays" aria-hidden="true">
      <div class="calendar-weekday sun">일</div>
      <div class="calendar-weekday">월</div>
      <div class="calendar-weekday">화</div>
      <div class="calendar-weekday">수</div>
      <div class="calendar-weekday">목</div>
      <div class="calendar-weekday">금</div>
      <div class="calendar-weekday sat">토</div>
    </div>

    <div id="editor-calendar-grid" class="editor-calendar-grid calendar-grid">
      <div class="calendar-grid-loading"><div class="loading-spinner"></div></div>
    </div>
  `;let n=[],r=`all`,i=new Date,o=i.getFullYear(),c=i.getMonth();async function l(){n=await f();let e=v(n);e&&(o=e.year,c=e.monthIndex),u(),d()}function u(){let e=e=>document.getElementById(e);e(`stat-total`)&&(e(`stat-total`).textContent=n.length,e(`stat-published`).textContent=n.filter(e=>e.status===`published`).length,e(`stat-draft`).textContent=n.filter(e=>e.status===`draft`).length,e(`stat-scheduled`).textContent=n.filter(e=>e.status===`scheduled`).length)}function d(){let t=e.querySelector(`#editor-calendar-grid`),r=e.querySelector(`#editor-month-label`);if(!t||!r)return;r.textContent=`${o}년 ${c+1}월`;let i=new Date(o,c,1).getDay(),s=new Date(o,c+1,0).getDate(),l=[];n.filter(e=>{let[t,n]=String(e?.publish_date||``).split(`-`).map(Number);return t===o&&n===c+1});for(let e=0;e<i;e+=1)l.push(`<div class="editor-calendar-cell editor-calendar-cell-blank cal-cell cal-cell-blank" aria-hidden="true"></div>`);for(let e=1;e<=s;e+=1){let t=y(o,c,e),n=p(t),r=new Date(o,c,e).getDay(),i=r===0?` sun`:r===6?` sat`:``,a=n.length?` editor-calendar-cell-has-story`:` editor-calendar-cell-empty`;l.push(`
        <div class="editor-calendar-cell cal-cell${i}${a}" data-date="${t}" role="button" tabindex="0">
          <div class="cal-cell-day">${e}</div>
          <div class="editor-calendar-stories">
            ${n.map(m).join(``)}
          </div>
        </div>
      `)}t.innerHTML=l.join(``),t.querySelectorAll(`.editor-calendar-cell[data-date]`).forEach(e=>{let t=()=>a(`/editor/new?date=${e.dataset.date}`);e.addEventListener(`click`,e=>{e.target.closest(`.editor-calendar-story`)||t()}),e.addEventListener(`keydown`,e=>{(e.key===`Enter`||e.key===` `)&&(e.preventDefault(),t())})}),t.querySelectorAll(`.editor-calendar-story`).forEach(e=>{e.addEventListener(`click`,t=>{t.stopPropagation(),a(`/editor/new?edit=${e.dataset.id}`)})})}function p(e){return n.filter(t=>t.publish_date===e).filter(e=>r===`all`||e.status===r)}function m(e){let t=g(e.title||e.figure_name||`제목 없음`),n=g(e.country||``),r=h(e.image_url||``),i=r?`src="${g(r)}"`:``,a=_(e.status);return`
      <button type="button" class="editor-calendar-story" data-id="${g(e.id)}">
        <span class="editor-calendar-thumb">
          <img ${i} alt="" loading="lazy" decoding="async" />
        </span>
        <span class="editor-calendar-story-title">${t}</span>
        <span class="editor-calendar-story-meta">${n}</span>
        ${a}
        <span class="editor-calendar-actions" aria-hidden="true"></span>
      </button>
    `}function _(e){let[t,n]={published:[`badge-accent`,`발행됨`],draft:[`badge-draft`,`초안`],scheduled:[`badge-scheduled`,`예약`],archived:[`badge-archived`,`보관`]}[e]||[``,e||`상태 없음`];return`<span class="badge ${t}">${g(n)}</span>`}function v(e){let t=[...e].filter(e=>b(e.publish_date)).sort((e,t)=>t.publish_date.localeCompare(e.publish_date))[0];if(!t)return null;let[n,r]=t.publish_date.split(`-`).map(Number);return{year:n,monthIndex:r-1}}function y(e,t,n){return`${e}-${String(t+1).padStart(2,`0`)}-${String(n).padStart(2,`0`)}`}function b(e){return typeof e==`string`&&/^\d{4}-\d{2}-\d{2}$/.test(e)}return setTimeout(()=>{document.getElementById(`editor-back`)?.addEventListener(`click`,()=>{history.back()}),e.querySelectorAll(`.editor-stat`).forEach(t=>{t.addEventListener(`click`,()=>{e.querySelectorAll(`.editor-stat`).forEach(e=>e.classList.remove(`active`)),t.classList.add(`active`),r=t.dataset.filter,d()})}),document.getElementById(`editor-prev-month`)?.addEventListener(`click`,()=>{--c,c<0&&(c=11,--o),d()}),document.getElementById(`editor-next-month`)?.addEventListener(`click`,()=>{c+=1,c>11&&(c=0,o+=1),d()}),l()},0),e}function C(){let n=document.createElement(`div`);n.className=`editor-new-page page`;let i=s(`profile`);if(!i||i.role!==`editor`)return n.innerHTML=`
      <div class="page-header"><h1 class="page-header-title">권한 없음</h1></div>
    `,n;let a=window.location.hash,h=null,g=null;if(a.includes(`?`)){let e=new URLSearchParams(a.split(`?`)[1]);h=e.get(`edit`),g=e.get(`date`)}n.innerHTML=`
    <!-- 상단 헤더 -->
    <div class="editor-new-header">
      <button class="page-header-back" id="editor-new-back">
        <svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 19l-7-7 7-7"></path></svg>
      </button>
      <h1 class="page-header-title" style="flex:1; text-align:center;">${h?`일화 수정`:`새 일화 작성`}</h1>
      <div style="width:36px;"></div> <!-- 중앙 정렬 맞춤용 -->
    </div>

    <!-- 미리보기 -->
    <div class="editor-preview-section">
      <div class="preview-scale-wrapper" id="editor-preview-area">
        <!-- 스켈레톤 상태나 카드가 렌더링 될 영역 -->
      </div>
      <div style="text-align:center; margin-top:var(--space-3); font-size:var(--text-xs); color:var(--color-text-tertiary);"></div>
    </div>

    <!-- 입력 폼 -->
    <div class="editor-form-section section">
      <!-- 언어 탭: 한국어(필수) / English / 日本語 -->
      <div class="editor-lang-tabs" role="tablist" aria-label="언어">
        <button type="button" class="editor-lang-tab active" data-lang="ko" role="tab" aria-selected="true">한국어</button>
        <button type="button" class="editor-lang-tab" data-lang="en" role="tab" aria-selected="false">English</button>
        <button type="button" class="editor-lang-tab" data-lang="ja" role="tab" aria-selected="false">日本語</button>
      </div>
      <div class="editor-lang-hint">한국어는 필수, 영어/일본어는 비우면 카드에서 한국어로 자동 표시됩니다.</div>

      <form id="story-form" class="story-form">
        <!-- 1. 제목 (가로 단독) -->
        <div class="input-group">
          <label class="input-label">제목 (인물/사건명) *</label>
          <input class="input-field" id="sf-title" placeholder="예: Isaac Newton" required />
        </div>

        <!-- 2. 역사적 연도 / 발행일 -->
        <div style="display:grid;grid-template-columns:1fr 1fr;gap:var(--space-3);">
          <div class="input-group">
            <label class="input-label">역사적 연도</label>
            <input class="input-field" type="number" id="sf-hist-year" placeholder="1666" />
          </div>
          <div class="input-group">
            <label class="input-label">발행일 *</label>
            <input class="input-field" type="date" id="sf-publish-date" required />
          </div>
        </div>

        <!-- 3. 국가 -->
        <div class="input-group">
          <label class="input-label">국가</label>
          <input class="input-field" id="sf-country" placeholder="영국" />
        </div>

        <!-- 4. 본문 -->
        <div class="input-group">
          <label class="input-label">본문 *</label>
          <textarea class="input-field" id="sf-body" placeholder="역사 일화 본문을 입력하세요..." style="min-height:200px; resize:vertical; line-height:1.6; font-family:var(--font-body);" required></textarea>
        </div>

        <!-- 4-1. 에디터 한마디 -->
        <div class="input-group">
          <label class="input-label">에디터 한마디</label>
          <textarea class="input-field" id="sf-editor-comment" placeholder="카드 뒷면에 표시될 에디터의 코멘트" rows="3" style="resize:vertical; line-height:1.6; font-family:var(--font-body);"></textarea>
        </div>

        <!-- 5. 이미지 업로드/URL -->
        <div class="input-group">
          <label class="input-label">이미지 업로드 및 URL</label>
          <div style="display:flex; gap:var(--space-2); align-items:center;">
            <input class="input-field" id="sf-image" placeholder="URL 직접 입력 또는 사진 선택" style="flex:1;" />
            <input type="hidden" id="sf-image-thumb" />
            <button type="button" id="sf-image-edit-btn" class="btn btn-secondary" style="display:none; margin:0; padding:var(--space-2) var(--space-3); font-size:var(--text-sm); white-space:nowrap;">편집</button>
            <button type="button" id="sf-image-gallery-btn" class="btn btn-secondary" style="cursor:pointer; margin:0; padding:var(--space-2) var(--space-3); font-size:var(--text-sm); white-space:nowrap;">보관함</button>
            <button type="button" id="sf-image-camera-btn" class="btn btn-secondary" style="cursor:pointer; margin:0; padding:var(--space-2) var(--space-3); font-size:var(--text-sm); white-space:nowrap;">촬영</button>
          </div>
          <div id="sf-image-status" style="font-size:var(--text-xs); color:var(--color-primary); margin-top:var(--space-1); display:none;">사진을 업로드하는 중입니다... ⏳</div>
        </div>

        <!-- 6. 이미지 출처 및 라이선스 -->
        <div class="input-group">
          <label class="input-label">이미지 출처 및 라이선스</label>
          <input class="input-field" id="sf-image-source" placeholder="예: Unsplash (CC0), Wikimedia Commons" />
        </div>

        <div style="display:flex;flex-direction:column;gap:var(--space-3);margin-top:var(--space-6);margin-bottom:var(--space-10);">
          <button type="submit" class="btn btn-primary btn-full" style="font-size:var(--text-md); padding:var(--space-4);">발행하기</button>
          <div style="display:flex;gap:var(--space-3);">
            <button type="button" class="btn btn-secondary btn-full" id="sf-save-draft">초안 저장</button>
            <button type="button" class="btn btn-full" id="sf-schedule" style="background:var(--color-info);color:#fff;border:none;">예약 발행</button>
          </div>
        </div>
      </form>
    </div>
  `;let S=!1,C=!1,w=e=>{S&&!C&&(e.preventDefault(),e.returnValue=``)};window.addEventListener(`beforeunload`,w),o(async e=>!C&&S&&!await _({title:`저장되지 않은 정보가 있습니다`,message:`정말 나가시겠습니까?`,confirmText:`나가기`,cancelText:`계속 작성`,danger:!0})?!1:(window.removeEventListener(`beforeunload`,w),o(null),!0));let T=[`sf-title`,`sf-body`,`sf-country`,`sf-editor-comment`],E={ko:{"sf-title":``,"sf-body":``,"sf-country":``,"sf-editor-comment":``},en:{"sf-title":``,"sf-body":``,"sf-country":``,"sf-editor-comment":``},ja:{"sf-title":``,"sf-body":``,"sf-country":``,"sf-editor-comment":``}},D=`ko`;function O(){T.forEach(e=>{let t=document.getElementById(e);t&&(E[D][e]=t.value)})}function k(e){T.forEach(t=>{let n=document.getElementById(t);n&&(n.value=E[e][t]||``)})}function A(){document.querySelectorAll(`.editor-lang-tab`).forEach(e=>{e.addEventListener(`click`,()=>{let t=e.dataset.lang;t!==D&&(O(),D=t,k(D),document.querySelectorAll(`.editor-lang-tab`).forEach(e=>{let t=e.dataset.lang===D;e.classList.toggle(`active`,t),e.setAttribute(`aria-selected`,t?`true`:`false`)}),j(!0))})})}setTimeout(async()=>{let n=!1,i=[];try{i=await f()}catch{}if(h){let e=await l(h);e&&(document.getElementById(`sf-hist-year`).value=e.historical_year||``,document.getElementById(`sf-publish-date`).value=e.publish_date||``,document.getElementById(`sf-image`).value=e.image_url||``,document.getElementById(`sf-image-thumb`).value=e.image_thumb_url||``,document.getElementById(`sf-image-source`).value=e.image_source||``,E.ko[`sf-title`]=e.title||e.figure_name||``,E.ko[`sf-body`]=e.body||``,E.ko[`sf-country`]=e.country||``,E.ko[`sf-editor-comment`]=e.editor_comment||e.editor&&e.editor.comment||``,[`en`,`ja`].forEach(t=>{let n=e.i18n&&e.i18n[t]||{};E[t][`sf-title`]=n.title||n.figure_name||``,E[t][`sf-body`]=n.body||``,E[t][`sf-country`]=n.country||``,E[t][`sf-editor-comment`]=n.editor_comment||``}),k(`ko`),n=!0)}else /^\d{4}-\d{2}-\d{2}$/.test(g||``)&&(document.getElementById(`sf-publish-date`).value=g);A(),document.getElementById(`editor-new-back`)?.addEventListener(`click`,()=>{history.back()});function a(){let e=document.getElementById(`sf-image`)?.value.trim(),t=document.getElementById(`sf-image-edit-btn`);t&&(t.style.display=e?`inline-block`:`none`)}let o=document.getElementById(`story-form`);o&&o.addEventListener(`input`,()=>{S=!0,j(),a()}),j(n),a();async function _(e,t=!1,n){let r=e;if(t){if(!(e.includes(`firebasestorage.googleapis.com`)||e.includes(`.firebasestorage.app`))){m(`외부 이미지는 편집할 수 없습니다.
[사진 추가]로 새 이미지를 업로드해주세요.`,`error`);return}try{let t=await fetch(e);if(!t.ok)throw Error(`이미지 다운로드 실패`);let n=await t.blob();r=URL.createObjectURL(n)}catch(e){console.error(`이미지 fetch 실패:`,e),m(`이미지를 불러올 수 없습니다. 다시 시도해주세요.`,`error`);return}}let i=document.createElement(`div`);i.className=`crop-modal-overlay`,i.innerHTML=`
        <div class="crop-modal-header">
          <button type="button" class="crop-modal-back-btn" id="btn-crop-back" aria-label="닫기">
            <svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
              <polyline points="15 18 9 12 15 6"/>
            </svg>
          </button>
          카드 이미지 편집
        </div>
        <div class="crop-modal-body">
          <img id="cropper-image" src="${r}" decoding="async" style="max-width: 100%; display: block;" />
        </div>
        <div class="crop-modal-footer">
          <button type="button" class="btn-rotate" id="btn-crop-rotate">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
              <path d="M21.5 2v6h-6M21.34 15.57a10 10 0 1 1-.53-11.23l5.67 5.66" />
            </svg>
            회전
          </button>
          <button type="button" class="btn-crop-confirm" id="btn-crop-confirm">다음</button>
        </div>
      `,(document.querySelector(`.mobile-wrapper`)||document.body).appendChild(i),v(),i.querySelector(`#btn-crop-back`).addEventListener(`click`,()=>{i.style.opacity=`0`,y(),setTimeout(()=>{o&&o.destroy(),t&&r.startsWith(`blob:`)&&URL.revokeObjectURL(r),i.remove()},300)}),setTimeout(()=>i.style.opacity=`1`,10);let a=i.querySelector(`#cropper-image`),o;a.onload=()=>{o=new b.default(a,{aspectRatio:x,viewMode:1,dragMode:`move`,autoCropArea:.9,restore:!1,guides:!0,center:!0,highlight:!1,cropBoxMovable:!0,cropBoxResizable:!0,toggleDragModeOnDblclick:!1})},a.onerror=()=>{m(`이미지를 불러올 수 없어 편집이 제한됩니다.`,`error`),t&&r.startsWith(`blob:`)&&URL.revokeObjectURL(r),y(),i.remove()},i.querySelector(`#btn-crop-rotate`).addEventListener(`click`,()=>{o&&o.rotate(90)}),i.querySelector(`#btn-crop-confirm`).addEventListener(`click`,()=>{let e=i.querySelector(`#btn-crop-confirm`);e.textContent=`처리 중...`,e.disabled=!0,o&&o.getCroppedCanvas({maxWidth:1200,maxHeight:1500,imageSmoothingEnabled:!0,imageSmoothingQuality:`high`}).toBlob(async a=>{if(!a){m(`크롭 오류가 발생했습니다.`,`error`),e.textContent=`다음`,e.disabled=!1;return}i.style.opacity=`0`,y(),setTimeout(()=>{o.destroy(),t&&r.startsWith(`blob:`)&&URL.revokeObjectURL(r),i.remove()},300),n(a)},`image/jpeg`,.85)})}async function w(e,t){let n=document.getElementById(`sf-image-status`),r=document.getElementById(`sf-image`);if(!(!n||!r))try{n.style.display=`block`,n.style.color=`var(--color-primary)`,n.textContent=`사진을 업로드하는 중입니다... ⏳`,e.name=t;let r=c?.currentUser?.uid||s(`user`)?.id;if(!r){n.style.color=`var(--color-error)`,n.textContent=`로그인이 필요합니다.`;return}let{image_url:i}=await d(e,{uid:r,folder:`editor_images`}),o=document.getElementById(`sf-image`),l=document.getElementById(`sf-image-thumb`);o&&(o.value=i),l&&(l.value=``),a(),n.textContent=`업로드 완료! ✅`,n.style.color=`var(--color-info)`,S=!0}catch(e){console.error(`이미지 업로드 오류:`,e),n.style.color=`var(--color-error)`,n.textContent=`업로드 실패: `+e.message,m(`이미지 업로드 실패: `+e.message,`error`)}finally{setTimeout(()=>{n&&n.textContent.includes(`완료`)&&(n.style.display=`none`)},3e3)}}async function T(n){try{let t=n===`camera`?await r():await e();if(!t)return;_(t.dataUrl,!1,e=>{w(e,n===`camera`?`camera_image.jpeg`:`gallery_image.jpeg`)})}catch(e){if(e instanceof t){m(e.message,`warning`);return}m(e?.message||`사진을 불러올 수 없습니다.`,`error`)}}document.getElementById(`sf-image-gallery-btn`)?.addEventListener(`click`,()=>T(`gallery`)),document.getElementById(`sf-image-camera-btn`)?.addEventListener(`click`,()=>T(`camera`)),document.getElementById(`sf-image-edit-btn`)?.addEventListener(`click`,async()=>{let e=document.getElementById(`sf-image`)?.value.trim();e&&_(e,!0,e=>{w(e,`edited_image.jpeg`)})});let D=document.getElementById(`sf-schedule`),M=document.getElementById(`sf-publish-date`);function N(){if(!D||!M)return;let e=M.value;if(!e){D.disabled=!0,D.style.opacity=`0.4`,D.title=`발행일을 먼저 선택하세요`;return}let t=new Date(e+`T00:00:00`),n=new Date;n.setHours(0,0,0,0);let r=t>n;D.disabled=!r,D.style.opacity=r?`1`:`0.4`,D.title=r?``:`예약 발행일은 미래 날짜여야 합니다`}N(),M?.addEventListener(`change`,e=>{let t=e.target.value;t&&i.find(e=>e.publish_date===t&&String(e.id)!==String(h))&&(m(`이미 등록된 일화가 있는 날짜입니다.`,`error`),e.target.value=``,S=!0,j()),N()});function P(){O();let e=parseInt(document.getElementById(`sf-hist-year`).value)||null,t=c?.currentUser,n=s(`user`),r=s(`profile`)||{},i={uid:t?.uid||n?.id||`dokhubooks_uid`,email:t?.email||n?.email||`dokhubooks@gmail.com`,displayName:t?.displayName||r.displayName||(n?.email?n.email.split(`@`)[0]:`DayStory`),photoURL:r.photoURL||t?.photoURL||``},a=E.ko,o=(a[`sf-title`]||``).trim(),l=e=>{let t=E[e],n={};return Object.entries({"sf-title":[`title`,`figure_name`],"sf-body":[`body`],"sf-country":[`country`],"sf-editor-comment":[`editor_comment`]}).forEach(([e,r])=>{let i=(t[e]||``).trim();i&&r.forEach(e=>{n[e]=i})}),n},u=l(`en`),d=l(`ja`),f={};Object.keys(u).length&&(f.en=u),Object.keys(d).length&&(f.ja=d);let p={figure_name:o,title:o,summary:``,body:(a[`sf-body`]||``).trim(),historical_date:e?`${e}년`:``,historical_year:e,country:(a[`sf-country`]||``).trim(),publish_date:document.getElementById(`sf-publish-date`).value,image_url:document.getElementById(`sf-image`).value.trim(),image_thumb_url:document.getElementById(`sf-image-thumb`)?.value.trim()||``,image_source:document.getElementById(`sf-image-source`).value.trim(),card_count:``,editor:i,editor_comment:(a[`sf-editor-comment`]||``).trim()};return Object.keys(f).length&&(p.i18n=f),p}document.getElementById(`sf-save-draft`)?.addEventListener(`click`,async()=>{C=!0;let e=P();e.status=`draft`;try{h?(await u(h,e),m(`초안 저장 완료`,`success`)):(await p(e),m(`초안 생성 완료`,`success`)),history.back()}catch(e){C=!1,m(`저장 실패: `+e.message,`error`)}}),o?.addEventListener(`submit`,async e=>{e.preventDefault(),C=!0;let t=P();t.status=`published`,t.published_at=new Date().toISOString();try{h?(await u(h,t),m(`수정 및 발행 완료`,`success`)):(await p(t),m(`새 일화 발행 완료!`,`success`)),history.back()}catch(e){C=!1,m(`발행 실패: `+e.message,`error`)}}),document.getElementById(`sf-schedule`)?.addEventListener(`click`,async()=>{let e=P();if(!e.publish_date){m(`예약 발행일을 선택해주세요`,`error`);return}e.publish_date=e.publish_date.split(`T`)[0],e.scheduled_date=e.publish_date,C=!0,e.status=`scheduled`;try{h?await u(h,e):await p(e),m(`${e.publish_date}에 발행 예약됨`,`success`),history.back()}catch(e){C=!1,m(`예약 실패: `+e.message,`error`)}})},0);function j(e=!1){let t=n.querySelector(`#editor-preview-area`);if(!t)return;let r=document.getElementById(`sf-title`)?.value.trim(),i=document.getElementById(`sf-body`)?.value.trim(),a=document.getElementById(`sf-image`)?.value.trim();if(!e&&!r&&!i&&!a){t.innerHTML=`<div style="width:360px; max-width:100%; zoom:0.7;"><div class="skeleton-card"></div></div>`;return}let o=e=>(e||``).replace(/[&<>'"]/g,e=>({"&":`&amp;`,"<":`&lt;`,">":`&gt;`,"'":`&#39;`,'"':`&quot;`})[e]),l=o(r||`제목 없음`),u=(i||`본문이 표시됩니다...`).split(/\n|\\n/).map(e=>e.trim()?`<p>${o(e)}</p>`:`<p><br></p>`).join(``),d=o(document.getElementById(`sf-hist-year`)?.value||`???`),f=o(document.getElementById(`sf-country`)?.value||``),p=document.getElementById(`sf-publish-date`)?.value;p||=new Date().toISOString().split(`T`)[0];let m=new Date(p),h=m.getMonth()+1,g=m.getDate(),_=new Date().getFullYear(),v=a||``,y=c?.currentUser,b=(s(`profile`)||{}).photoURL||y?.photoURL||``,x=o(document.getElementById(`sf-editor-comment`)?.value.trim()||``);t.innerHTML=`
        <div class="flip-container">
          <div class="flipper" id="preview-flipper">
            <div class="front history-card-front">
              <div class="history-card-top">
                <div class="card-top-left">
                  <div class="card-year">${d}</div>
                  <div class="card-date">${h}. ${g}</div>
                </div>
                <div class="card-top-right">
                  <div class="card-actions">
                    <!-- 미리보기용 비활성 액션 버튼 -->
                    <button class="card-action-btn" aria-label="공유" disabled>
                      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <circle cx="18" cy="5" r="3"/><circle cx="6" cy="12" r="3"/><circle cx="18" cy="19" r="3"/>
                        <line x1="8.59" y1="13.51" x2="15.42" y2="17.49"/><line x1="15.41" y1="6.51" x2="8.59" y2="10.49"/>
                      </svg>
                    </button>
                    <button class="card-action-btn" aria-label="보관함" disabled>
                      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <path d="M19 21l-7-5-7 5V5a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2z"/>
                      </svg>
                    </button>
                  </div>
                  <div class="card-meta">
                    ${f}<br>
                    ${_} / ${String(h).padStart(2,`0`)} / ${String(g).padStart(2,`0`)}
                  </div>
                </div>
              </div>
              <div class="history-card-image-wrap">
                <img src="${o(v)}" alt="${l}" loading="eager" decoding="async" fetchpriority="high" width="1200" height="1500" onerror="this.style.display='none'" draggable="false" />
                <div class="card-image-title">${l}</div>
              </div>
            </div>
            <div class="back history-card-back">
              <div class="back-title">${l}</div>
              <hr class="back-divider" />
              <div class="back-body">
                ${u||`<p>본문이 표시됩니다...</p>`}
              </div>
              <div class="back-footer">
                <button class="back-editor-btn" type="button" title="에디터 한마디" style="${x&&x.trim()!==``?``:`visibility: hidden; pointer-events: none;`}">
                  <img src="${o(b)}" alt="editor" class="back-editor-avatar" loading="lazy" decoding="async" onerror="this.style.display='none';this.nextElementSibling.style.display='flex'" />
                  <span class="back-editor-avatar-fallback" style="display:none">✍️</span>
                </button>
                <div class="back-date-actions">
                  <div class="back-date">${d}년 ${h}월 ${g}일</div>
                  <button class="card-detail-shortcut-btn" type="button" aria-label="상세 보기" title="상세 보기" disabled>상세 보기</button>
                </div>
              </div>
            </div>
          </div>
        </div>
    `;let S=t.querySelector(`#preview-flipper`);S&&S.addEventListener(`click`,e=>{if(e.target.closest(`.back-editor-btn`)||e.target.closest(`.card-detail-shortcut-btn`))return;let n=t.querySelector(`.editor-comment-bubble`);if(n&&!n.contains(e.target)){n.remove();return}S.classList.toggle(`flipped`)});let C=t.querySelector(`.back-editor-btn`);if(C){let e=0,n=null,r=null,i=()=>{let e=t.querySelector(`.editor-comment-bubble`);e&&e.remove(),n&&clearTimeout(n),n=null,r&&=(r(),null)},a=()=>{r&&r();let e=e=>{let n=t.querySelector(`.editor-comment-bubble`);if(!n){r&&=(r(),null);return}let a=e.target;C.contains(a)||n.contains(a)||i()};document.addEventListener(`click`,e),document.addEventListener(`touchstart`,e,{passive:!0}),r=()=>{document.removeEventListener(`click`,e),document.removeEventListener(`touchstart`,e)}},o=r=>{if(r&&(r.stopPropagation(),r.type===`touchend`&&(e=Date.now(),r.preventDefault()),r.type===`click`&&Date.now()-e<650))return;let o=document.getElementById(`sf-editor-comment`)?.value.trim()||`에디터 코멘트가 없습니다.`;if(t.querySelector(`.editor-comment-bubble`)){i();return}let s=document.createElement(`div`);s.className=`editor-comment-bubble`,s.textContent=o,C.parentElement.appendChild(s),a(),n=setTimeout(()=>{i()},3e3)};C.addEventListener(`click`,o),C.addEventListener(`touchend`,o)}}return n}export{S as renderEditor,C as renderEditorNew};