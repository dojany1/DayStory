const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/web-Yz73wu6w.js","assets/dist-N3LOKtlT.js","assets/login-D0yLL7_J.js","assets/preload-helper-Dd-HcVz_.js","assets/definitions-DpJzfrOC.js","assets/index.esm-D5wgknfe.js","assets/firebase-CMykNrkF.js","assets/toast-DL5HJnQ3.js","assets/router-hybKseu2.js","assets/state-8PRbPWwW.js","assets/detail-P32nPey4.js","assets/storyI18n-D4h3I9Tp.js","assets/i18n-CAgB5cGO.js","assets/stories-DjoDJ8Ga.js","assets/sanitize-DlMVmTsh.js","assets/receivedCards-8POjwrst.js","assets/profile-j-LFABpd.js","assets/cropper-DfNRxLcH.js","assets/cropper-cx_wrqbx.css","assets/pageHeader-CzG3S3Fi.js","assets/bookmarks-CHgGixuw.js","assets/scrollLock-ByagqdMz.js","assets/search-wY_yJ26U.js","assets/settings-DyFSTtHj.js","assets/report-C5QkzEhM.js","assets/editor-wxwB_9rA.js","assets/mystory-vj8FuVPi.js","assets/license-Cgs_AAnm.js","assets/about-BnsomedG.js"])))=>i.map(i=>d[i]);
import{a as e,i as t,n,o as r,s as i}from"./router-hybKseu2.js";import{n as a,r as o,t as s}from"./state-8PRbPWwW.js";import{n as c,r as l}from"./i18n-CAgB5cGO.js";import{O as u}from"./index.esm-D5wgknfe.js";import{_ as d,b as f,d as p,f as m,g as h,i as g,l as _,m as v,n as y,p as b,r as x,s as S,t as C,u as w,v as T,x as E,y as D}from"./firebase-CMykNrkF.js";import{i as ee,t as O}from"./dist-N3LOKtlT.js";import{t as k}from"./preload-helper-Dd-HcVz_.js";import{d as A,o as te,p as j,r as ne,u as re}from"./stories-DjoDJ8Ga.js";import{a as ie,r as M,s as ae,t as N}from"./storyI18n-D4h3I9Tp.js";import{t as P}from"./toast-DL5HJnQ3.js";import{t as F}from"./sanitize-DlMVmTsh.js";import{n as oe,t as se}from"./scrollLock-ByagqdMz.js";(function(){let e=document.createElement(`link`).relList;if(e&&e.supports&&e.supports(`modulepreload`))return;for(let e of document.querySelectorAll(`link[rel="modulepreload"]`))n(e);new MutationObserver(e=>{for(let t of e)if(t.type===`childList`)for(let e of t.addedNodes)e.tagName===`LINK`&&e.rel===`modulepreload`&&n(e)}).observe(document,{childList:!0,subtree:!0});function t(e){let t={};return e.integrity&&(t.integrity=e.integrity),e.referrerPolicy&&(t.referrerPolicy=e.referrerPolicy),e.crossOrigin===`use-credentials`?t.credentials=`include`:e.crossOrigin===`anonymous`?t.credentials=`omit`:t.credentials=`same-origin`,t}function n(e){if(e.ep)return;e.ep=!0;let n=t(e);fetch(e.href,n)}})();var I=ee(`App`,{web:()=>k(()=>import(`./web-Yz73wu6w.js`).then(e=>new e.AppWeb),__vite__mapDeps([0,1]))}),L=ee(`DayStoryWidget`),R=()=>O.getPlatform&&O.getPlatform()===`android`,ce=`daystory:letterReadDate:`;function z(){return A()}async function le(e){if(R())try{await L.setLetterState({hasNewLetter:!!e})}catch(e){console.warn(`[widget] setLetterState 실패:`,e)}}async function ue(e,t=z()){if(R())try{await L.setDiaryState({hasTodayDiary:!!e,diaryDate:t||z()})}catch(e){console.warn(`[widget] setDiaryState 실패:`,e)}}async function de(){let e=ce+z();try{if(localStorage.getItem(e)===`1`)return;localStorage.setItem(e,`1`)}catch{}await le(!1)}async function fe(e){if(!Array.isArray(e))return;let t=z();await ue(e.some(e=>e&&e.publish_date===t),t)}var B=`ds_collected_cards`;function V(){try{return JSON.parse(localStorage.getItem(B)||`{}`)}catch{return{}}}function H(e){localStorage.setItem(B,JSON.stringify(e))}function U(e){return!!V()[e]}function W(e){return e===A()}function G(e,t,n={}){if(U(e))return{ok:!0,alreadyCollected:!0};if(!n.bypass&&!W(t))return{ok:!1,alreadyCollected:!1};let r=V();return r[e]=A(),H(r),{ok:!0,alreadyCollected:!1}}function pe(e){if(!Array.isArray(e)||e.length===0)return 0;let t=V(),n=A(),r=0;for(let i of e)!i||t[i]||(t[i]=n,r+=1);return r>0&&H(t),r}async function me(e){if(!y)return[];try{let t=d(w(y,`userStories`),E(`uid`,`==`,e),h(`publish_date`,`desc`),h(`created_at`,`desc`));return(await Promise.race([v(t),new Promise((e,t)=>setTimeout(()=>t(Error(`timeout`)),5e3))])).docs.map(e=>({id:e.id,...e.data()}))}catch(e){return console.warn(`fetchMyStories 에러:`,e),[]}}async function he(e,t){if(!y)return null;try{let n=await b(m(y,`userStories`,e));return n.exists()&&n.data().uid===t?{id:n.id,...n.data()}:null}catch(e){return console.warn(`fetchMyStoryById 에러:`,e),null}}async function ge(e){if(!y){console.log(`[DB Mock] createMyStory:`,e);return}await _(w(y,`userStories`),{...e,created_at:T(),updated_at:T()})}async function _e(e,t){if(!y){console.log(`[DB Mock] updateMyStory:`,e,t);return}await f(m(y,`userStories`,e),{...t,updated_at:T()})}async function ve(e){if(!y){console.log(`[DB Mock] deleteMyStory:`,e);return}try{let t=await b(m(y,`userStories`,e));if(t.exists()){let e=t.data();e.image_url&&(e.image_url.includes(`firebasestorage`)||e.image_url.includes(`.firebasestorage.app`))&&await g(S(x,e.image_url)).catch(e=>console.warn(`Storage delete fail`,e))}}catch(e){console.warn(`deleteMyStory image delete skip:`,e)}await p(m(y,`userStories`,e))}function ye({title:e,message:t=``,confirmText:n=`확인`,cancelText:r=`취소`,danger:i=!1}={}){return new Promise(a=>{document.querySelectorAll(`.confirm-dialog-overlay`).forEach(e=>e.remove());let o=document.createElement(`div`);o.className=`confirm-dialog-overlay`,o.setAttribute(`role`,`dialog`),o.setAttribute(`aria-modal`,`true`);let s=String(t).split(`
`).map(e=>`<p class="confirm-dialog-line">${K(e)}</p>`).join(``);o.innerHTML=`
      <div class="confirm-dialog">
        <div class="confirm-dialog-title">${K(e||``)}</div>
        ${t?`<div class="confirm-dialog-message">${s}</div>`:``}
        <div class="confirm-dialog-actions">
          <button type="button" class="confirm-dialog-btn confirm-dialog-cancel">${K(r)}</button>
          <button type="button" class="confirm-dialog-btn confirm-dialog-confirm${i?` is-danger`:``}">${K(n)}</button>
        </div>
      </div>
    `,(document.querySelector(`.mobile-wrapper`)||document.body).appendChild(o),se(),requestAnimationFrame(()=>o.classList.add(`visible`));let c=e=>{oe(),o.classList.remove(`visible`),setTimeout(()=>{o.remove(),a(e)},180)};o.querySelector(`.confirm-dialog-cancel`).addEventListener(`click`,()=>c(!1)),o.querySelector(`.confirm-dialog-confirm`).addEventListener(`click`,()=>c(!0)),o.addEventListener(`click`,e=>{e.target===o&&c(!1)});let l=e=>{e.key===`Escape`&&(document.removeEventListener(`keydown`,l),c(!1))};document.addEventListener(`keydown`,l)})}function K(e){return e==null?``:String(e).replace(/&/g,`&amp;`).replace(/</g,`&lt;`).replace(/>/g,`&gt;`).replace(/"/g,`&quot;`).replace(/'/g,`&#x27;`)}var be=[`일`,`월`,`화`,`수`,`목`,`금`,`토`];function q(e,t){return e.year===t.getFullYear()&&e.month===t.getMonth()}function J(t,n,r){let i=t.querySelector(`#calendar-grid`),o=t.querySelector(`#cal-month-label`);if(!i||!o)return;o.textContent=`${n.year}년 ${n.month+1}월`;let s=t.querySelector(`#cal-next-month`);if(s){let e=q(n,r);s.disabled=e,s.classList.toggle(`disabled`,e)}let c=n.mode===`history`?n.historyStories:n.myStories,l=new Map;c.forEach(e=>{e&&e.publish_date&&l.set(e.publish_date,e)}),c.filter(e=>{if(!e?.publish_date)return!1;let[t,r]=e.publish_date.split(`-`);return Number(t)===n.year&&Number(r)===n.month+1}),(a(`profile`)||{}).role;let u=j(`${n.year}-${String(n.month+1).padStart(2,`0`)}-01`).getDay(),d=re(n.year,n.month+1),f=``;for(let e=0;e<u;e++)f+=`<div class="cal-cell cal-cell-blank"></div>`;for(let e=1;e<=d;e++){let t=String(n.month+1).padStart(2,`0`),i=String(e).padStart(2,`0`),a=`${n.year}-${t}-${i}`,o=l.get(a),s=j(a);if(!s)continue;let c=s>r,u=s.getTime()===r.getTime(),d=s.getDay(),p=n.mode===`mine`&&!o&&!c,m=[`cal-cell`,c?`cal-cell-future`:``,u?`cal-cell-today`:``,o?`cal-cell-has-story`:`cal-cell-empty`,p?`cal-cell-mine-write`:``,d===0?`sun`:d===6?`sat`:``].filter(Boolean).join(` `),h=o?xe(o,n.mode):``;f+=`
      <button type="button" class="${m}" data-date="${a}" ${o||p?``:`disabled aria-disabled="true"`}>
        <span class="cal-cell-day">${e}</span>
        ${h}
        ${p&&u?`<div class="cal-cell-write-prompt">
           <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round">
             <line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/>
           </svg>
         </div>`:``}
      </button>
    `}let p=(7-(u+d)%7)%7;for(let e=0;e<p;e++)f+=`<div class="cal-cell cal-cell-blank"></div>`;i.innerHTML=f,i.querySelectorAll(`.cal-cell-has-story`).forEach(e=>{e.addEventListener(`click`,()=>{let t=e.dataset.date,r=l.get(t);r&&Se(r,n.mode,n.bookmarkedIds)})}),i.querySelectorAll(`.cal-cell-mine-write`).forEach(t=>{t.addEventListener(`click`,()=>{let n=t.dataset.date;n&&e(`/mystory/new?date=${n}`)})})}function xe(e,t){let n=e.image_url||``;return`
    <span class="cal-cell-peek" aria-hidden="true">
      <img class="cal-cell-peek-img" ${n?`src="${F(n)}"`:``} alt="" loading="lazy" decoding="async" draggable="false" />
      <span class="cal-cell-peek-title">${F(t===`history`?e.figure_name||e.title||``:e.title||``)}</span>
    </span>
  `}function Se(t,n,r=[],i={}){document.querySelectorAll(`.calendar-card-popup`).forEach(e=>e.remove()),n===`history`&&(t=N(t));let o=j(t.publish_date||``),s=!!o,c=s?o.getMonth()+1:``,u=s?o.getDate():``,d=s?o.getFullYear():``,f=n===`history`&&t.id?U(t.id):!1;n===`history`&&!f&&t.id&&t.publish_date&&!W(t.publish_date)&&G(t.id,t.publish_date,{bypass:!0}).ok&&(f=!0),n===`history`&&t.publish_date&&W(t.publish_date);let p=document.createElement(`div`);p.className=`calendar-card-popup`,p.innerHTML=`
    <div class="calendar-card-popup-inner">
      <button type="button" class="calendar-card-popup-close" aria-label="닫기">
        <svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" stroke-width="2.5">
          <line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/>
        </svg>
      </button>
      <div class="calendar-card-popup-stage">
        ${n===`history`?Ce(t,d,c,u,r,f,{showDeleteBtn:!!i.onRemove}):Te(t,d,c,u,we(t))}
      </div>
      ${i.hideHint?``:`<div class="calendar-card-popup-hint">${l(f?`calendar.card_collected_hint`:`calendar.card_tap_hint`)}</div>`}
    </div>
  `,document.body.appendChild(p),se(),requestAnimationFrame(()=>p.classList.add(`open`));let m=()=>{oe(),p.classList.remove(`open`),setTimeout(()=>{p.parentNode&&p.remove()},240)};if(p.querySelector(`.calendar-card-popup-close`).addEventListener(`click`,e=>{e.stopPropagation(),m()}),p.addEventListener(`click`,e=>{(e.target===p||e.target.classList.contains(`calendar-card-popup-inner`))&&m()}),i.onRemove){let e=p.querySelector(`.card-delete-btn`);e&&e.addEventListener(`click`,async e=>{e.stopPropagation(),await ye({title:l(`bookmarks.remove_confirm_title`),message:l(`bookmarks.remove_confirm_message`),confirmText:l(`bookmarks.remove_btn`),cancelText:l(`common.cancel`),danger:!0})&&(await i.onRemove(t),m())})}let h=p.querySelector(`.flipper`);h&&h.addEventListener(`click`,e=>{e.target.closest(`.card-action-btn`)||e.target.closest(`.card-detail-shortcut-btn`)||e.target.closest(`.back-editor-btn`)||e.target.closest(`.editor-comment-bubble`)||e.target.closest(`.collect-btn`)||h.classList.contains(`is-flipping`)||(h.classList.add(`is-flipping`),h.classList.toggle(`flipped`),setTimeout(()=>h.classList.remove(`is-flipping`),400))});let g=p.querySelector(`.collect-btn`);g&&n===`history`&&t.id&&g.addEventListener(`click`,e=>{if(e.stopPropagation(),U(t.id))return;if(!G(t.id,t.publish_date||``).ok){P(l(`calendar.collect_locked_toast`),`info`);return}g.classList.add(`collect-btn--done`),g.disabled=!0,g.textContent=l(`calendar.collected_button`),P(l(`calendar.collect_success_text`),`success`);let n=p.querySelector(`.calendar-card-popup-hint`);n&&(n.textContent=l(`calendar.card_collected_hint`)),p._collected=!0});let _=p.querySelector(`.card-detail-shortcut-btn`);_&&n===`history`&&t.id&&_.addEventListener(`click`,n=>{n.stopPropagation(),m(),e(`/detail/${t.id}`)});let v=p.querySelector(`.back-editor-btn`);if(v){let e=null,t=()=>{let t=p.querySelector(`.editor-comment-bubble`);t&&t.remove(),e&&=(e(),null)};v.addEventListener(`click`,n=>{n.stopPropagation();let r=p.querySelector(`.editor-comment-bubble`);if(r){if(r.contains(n.target))return;t();return}let i=v.dataset.comment,a=v.dataset.editorName||`DayStory`;if(!i)return;let o=document.createElement(`div`);o.className=`editor-comment-bubble`;let s=document.createElement(`span`);s.className=`editor-comment-name`,s.textContent=a,o.appendChild(s),o.appendChild(document.createTextNode(i)),v.appendChild(o);let c=e=>{v.contains(e.target)||t()};document.addEventListener(`click`,c),e=()=>document.removeEventListener(`click`,c)})}if(n!==`history`){let n=p.querySelector(`.share-my-story-btn`),r=p.querySelector(`.edit-my-story-btn`);n&&n.addEventListener(`click`,async e=>{e.stopPropagation(),await M(t,{kind:`mystory`,includeImage:!1})}),r&&r.addEventListener(`click`,t=>{t.stopPropagation(),m(),e(`/mystory/new?edit=`+r.dataset.id)})}if(n===`history`){let n=p.querySelector(`.card-action-btn[aria-label="공유"]`),i=p.querySelector(`.card-action-btn[aria-label="보관함"]`);n&&n.addEventListener(`click`,async n=>{n.stopPropagation();let r=a(`user`);if(r&&r.id===`guest`){P(l(`toast.login_required`),`info`),m(),e(`/login`);return}await M(t,{kind:`history`})}),i&&i.addEventListener(`click`,async n=>{n.stopPropagation();let o=a(`user`);if(o&&o.id===`guest`){P(l(`toast.login_required`),`info`),m(),e(`/login`);return}let s=await ae(t.id);if(s.error){P(s.error,`error`);return}P(s.bookmarked?l(`toast.bookmark_added`):l(`toast.bookmark_removed`),`success`);let c=i.querySelector(`svg`);if(c&&(c.style.fill=s.bookmarked?`currentColor`:`none`),s.bookmarked&&!r.includes(t.id))r.push(t.id);else if(!s.bookmarked){let e=r.indexOf(t.id);e>-1&&r.splice(e,1)}})}}function Ce(e,t,n,r,i=[],a=!1,o={}){let s=(e.body||``).split(/\n|\\n/).map(e=>e.trim()?`<p>${F(e)}</p>`:`<p><br></p>`).join(``),c=!!(e.id&&i.includes(e.id)),u=e.editor_comment||``,d=e.editor&&e.editor.photoURL||``,f=e.editor&&e.editor.displayName||`DayStory`,p=!u.trim(),m=e.image_url||``,h=m?`src="${F(m)}"`:``;return`
    <div class="flip-container">
      <div class="flipper">
        <div class="front history-card-front">
          <div class="history-card-top">
            <div class="card-top-left">
              <div class="card-year">${F(e.historical_year||t)}</div>
              <div class="card-date">${n}. ${r}</div>
            </div>
            <div class="card-top-right">
              <div class="card-actions">
                <button class="card-action-btn" aria-label="공유">
                  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                    <circle cx="18" cy="5" r="3"/><circle cx="6" cy="12" r="3"/><circle cx="18" cy="19" r="3"/>
                    <line x1="8.59" y1="13.51" x2="15.42" y2="17.49"/><line x1="15.41" y1="6.51" x2="8.59" y2="10.49"/>
                  </svg>
                </button>
                <button class="card-action-btn" aria-label="보관함">
                  <svg viewBox="0 0 24 24" fill="${c?`currentColor`:`none`}" stroke="currentColor" stroke-width="2">
                    <path d="M19 21l-7-5-7 5V5a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2z"/>
                  </svg>
                </button>
              </div>
              <div class="card-meta">
                ${F(e.country||``)}<br>
                ${t} / ${String(n).padStart(2,`0`)} / ${String(r).padStart(2,`0`)}
              </div>
            </div>
          </div>
          <div class="history-card-image-wrap">
            <img ${h} alt="${F(e.figure_name||``)}" loading="eager" decoding="async" width="320" height="400" draggable="false" />
            <div class="card-image-title">${F(e.figure_name||``)}</div>
          </div>
        </div>
        <div class="back history-card-back">
          ${o.showDeleteBtn?`
            <button class="card-delete-btn" type="button" aria-label="${F(l(`bookmarks.remove_btn`))}" title="${F(l(`bookmarks.remove_btn`))}">
              <svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                <polyline points="3 6 5 6 21 6"/>
                <path d="M19 6l-1 14a2 2 0 0 1-2 2H8a2 2 0 0 1-2-2L5 6"/>
                <path d="M10 11v6"/><path d="M14 11v6"/>
                <path d="M9 6V4a2 2 0 0 1 2-2h2a2 2 0 0 1 2 2v2"/>
              </svg>
            </button>`:``}
          <div class="back-title">${F(e.figure_name||``)}</div>
          <hr class="back-divider" />
          <div class="back-body">${s}</div>
          <div class="back-footer">
            <button class="back-editor-btn" type="button" title="에디터 한마디" data-comment="${F(u)}" data-editor-name="${F(f)}" style="${p?`visibility: hidden; pointer-events: none;`:``}">
              ${d?`<img src="${F(d)}" alt="editor" class="back-editor-avatar" loading="lazy" decoding="async" onerror="this.style.display='none';this.nextElementSibling.style.display='flex'" /><span class="back-editor-avatar-fallback" style="display:none">✍️</span>`:`<span class="back-editor-avatar-fallback">✍️</span>`}
            </button>
            <div class="back-date-actions">
              <div class="back-date">${F(e.historical_year||t)}년 ${n}월 ${r}일</div>
              <button class="card-detail-shortcut-btn" type="button">${F(l(`home.detail_button`))}</button>
            </div>
          </div>
        </div>
      </div>
    </div>
  `}function we(e){let t=a(`profile`)||{},n=a(`user`)||{},r=typeof n.email==`string`?n.email.split(`@`)[0]:``;return[e.author_nickname,e.authorNickname,e.author?.nickname,e.author?.displayName,t.nickname,n.displayName,r].map(e=>typeof e==`string`?e.trim():``).find(Boolean)||`사용자`}function Te(e,t,n,r,i=``){let a=(e.body||``).split(/\n|\\n/).map(e=>e.trim()?`<p>${F(e)}</p>`:`<p><br></p>`).join(``),o=e.image_url||``,s=o?`src="${F(o)}"`:``;return`
    <div class="flip-container">
      <div class="flipper mystory-flipper">
        <div class="front history-card-front">
          <div class="history-card-top">
            <div class="card-top-left">
              <div class="card-year mystory-card-year">${t}</div>
              <div class="card-date">${n}. ${r}</div>
            </div>
            <div class="card-top-right">
              <div class="card-actions">
                <button class="card-action-btn share-my-story-btn" data-id="${F(e.id||``)}" aria-label="공유">
                  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                    <circle cx="18" cy="5" r="3"/><circle cx="6" cy="12" r="3"/><circle cx="18" cy="19" r="3"/>
                    <line x1="8.59" y1="13.51" x2="15.42" y2="17.49"/><line x1="15.41" y1="6.51" x2="8.59" y2="10.49"/>
                  </svg>
                </button>
                <button class="card-action-btn edit-my-story-btn" data-id="${F(e.id||``)}" aria-label="수정">
                  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                    <path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"></path>
                    <path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"></path>
                  </svg>
                </button>
              </div>
              <div class="card-meta">${F(i)}</div>
            </div>
          </div>
          <div class="history-card-image-wrap">
            <img ${s} alt="${F(e.title||``)}" loading="eager" decoding="async" width="320" height="400" draggable="false" />
            <div class="card-image-title">${F(e.title||``)}</div>
          </div>
        </div>
        <div class="back history-card-back">
          <div class="back-title">${F(e.title||``)}</div>
          <hr class="back-divider" />
          <div class="back-body">${a}</div>
          <div class="back-footer">
            <div class="back-date">${t}년 ${n}월 ${r}일</div>
          </div>
        </div>
      </div>
    </div>
  `}var Ee=400,De=560,Oe=`<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M2 7v10"/><path d="M6 5v14"/><rect width="12" height="18" x="10" y="3" rx="2"/></svg>`,ke=`<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M8 2v4"/><path d="M16 2v4"/><rect width="18" height="18" x="3" y="4" rx="2"/><path d="M3 10h18"/><path d="M8 14h.01"/><path d="M12 14h.01"/><path d="M16 14h.01"/><path d="M8 18h.01"/><path d="M12 18h.01"/><path d="M16 18h.01"/></svg>`,Ae=0,je=1500;function Me(){let e=document.createElement(`div`);e.className=`editorstory-page page`;let t=sessionStorage.getItem(`ds_session_view`)??(localStorage.getItem(`ds_default_view`)||`card`);return e.innerHTML=`
    <div class="editorstory-header">
      <h1 class="editorstory-title"></h1>
    </div>

    <div class="wheel-pickers-container">
      <div class="wheel-year-label" id="editorstory-year-label">${new Date().getFullYear()}</div>
      <div class="wheel-picker-wrapper">
        <div class="wheel-selection-box"></div>
        <div class="modern-wheel-scroll" id="editorstory-month-scroll"></div>
        <button type="button" class="view-toggle-btn" id="editorstory-view-toggle" aria-label="보기 방식 변경">${t===`calendar`?ke:Oe}</button>
      </div>
      <div class="wheel-picker-wrapper" id="editorstory-day-picker">
        <div class="wheel-selection-box"></div>
        <div class="modern-wheel-scroll" id="editorstory-calendar"></div>
      </div>
    </div>

    <div class="editorstory-card-area" id="editorstory-card-area">
      <div style="display:flex;justify-content:center;padding:var(--space-8);width:100%;">
        <div class="loading-spinner"></div>
      </div>
    </div>

    <div class="page-calendar-view" id="editorstory-cal-view" hidden>
      <div class="calendar-month-nav">
        <button type="button" class="calendar-month-arrow" id="cal-prev-month" aria-label="이전 달">
          <svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" stroke-width="2"><polyline points="15 18 9 12 15 6"/></svg>
        </button>
        <div class="calendar-month-label" id="cal-month-label">—</div>
        <button type="button" class="calendar-month-arrow" id="cal-next-month" aria-label="다음 달">
          <svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" stroke-width="2"><polyline points="9 18 15 12 9 6"/></svg>
        </button>
      </div>
      <div class="calendar-weekdays">
        ${be.map((e,t)=>`<div class="calendar-weekday ${t===0?`sun`:t===6?`sat`:``}">${e}</div>`).join(``)}
      </div>
      <div class="calendar-grid" id="calendar-grid">
        <div class="calendar-grid-loading"><div class="loading-spinner"></div></div>
      </div>
    </div>
  `,t===`calendar`&&(e.querySelector(`#editorstory-day-picker`).hidden=!0,e.querySelector(`#editorstory-card-area`).hidden=!0,e.querySelector(`#editorstory-cal-view`).hidden=!1),Ne(e),e}async function Ne(e){try{let[t,n,r]=await Promise.all([ne(),te(),ie()]),i=new Date(n.publish_date+`T00:00:00`),a=t||[];pe([n,...a].map(e=>e?.id).filter(Boolean));let o=e.querySelector(`#editorstory-month-scroll`),s=e.querySelector(`#editorstory-calendar`),c=e.querySelector(`#editorstory-card-area`),l=i.getFullYear(),u=i.getMonth()+1,d=i.getDate(),f=i,p=!0;if(o&&(o.innerHTML=Array.from({length:12},(e,t)=>{let n=t+1;return`<div class="wheel-item${n>u?` disabled`:``}" data-month="${n}">${n}</div>`}).join(``)),s){let e=[];for(let t=1;t<=u;t++){let n=t===u?d:new Date(l,t,0).getDate();for(let r=1;r<=n;r++){let n=String(t).padStart(2,`0`),i=String(r).padStart(2,`0`);e.push(`<div class="wheel-item" data-date="${l}-${n}-${i}" data-month="${t}" data-day="${r}">${r}</div>`)}}s.innerHTML=e.join(``)}function m(e){let t=e.getBoundingClientRect().left+e.offsetWidth/2,n=null,r=1/0;return e.querySelectorAll(`.wheel-item:not(.disabled)`).forEach(e=>{let i=e.getBoundingClientRect().left+e.offsetWidth/2,a=Math.abs(t-i);a<r&&(r=a,n=e)}),n}function h(e){let t=o.querySelector(`.wheel-item.active`);if(t&&parseInt(t.dataset.month,10)===e)return;let n=o.querySelector(`.wheel-item[data-month="${e}"]`);if(!n)return;o.querySelectorAll(`.wheel-item`).forEach(e=>e.classList.remove(`active`)),n.classList.add(`active`);let r=n.offsetLeft-o.offsetWidth/2+n.offsetWidth/2;o.scrollTo({left:r,behavior:`smooth`})}function g(e=!1){let t;if(e?t=s.querySelector(`.wheel-item.active`):(t=m(s),t&&(s.querySelectorAll(`.wheel-item`).forEach(e=>e.classList.remove(`active`)),t.classList.add(`active`))),!t)return;h(parseInt(t.dataset.month,10));let i=t.dataset.date,o=new Date(i+`T00:00:00`);if(f&&f.getTime()===o.getTime()&&!p)return;let l=p?null:o>f?`next`:`prev`;f=o,Pe(c,a.find(e=>e.publish_date===i)||(n.publish_date===i?n:null),o,r,l),p=!1}let _;s.addEventListener(`scroll`,()=>{clearTimeout(_),_=setTimeout(()=>{g(!1)},150)},{passive:!0});let v;o.addEventListener(`scroll`,()=>{T===`card`&&(clearTimeout(v),v=setTimeout(()=>{let e=m(o);if(!e||e.classList.contains(`disabled`))return;let t=s.querySelector(`.wheel-item.active`),n=t?parseInt(t.dataset.month,10):-1;parseInt(e.dataset.month,10)===n?(o.querySelectorAll(`.wheel-item`).forEach(e=>e.classList.remove(`active`)),e.classList.add(`active`)):y(e)},150))},{passive:!0});let y=e=>{if(e.classList.contains(`disabled`))return;let t=parseInt(e.dataset.month,10),n=t===u?String(d).padStart(2,`0`):`01`,r=`${l}-${String(t).padStart(2,`0`)}-${n}`,i=s.querySelector(`.wheel-item[data-date="${r}"]`);if(!i)return;s.querySelectorAll(`.wheel-item`).forEach(e=>e.classList.remove(`active`)),i.classList.add(`active`),o.querySelectorAll(`.wheel-item`).forEach(e=>e.classList.remove(`active`)),e.classList.add(`active`),clearTimeout(_);let a=i.offsetLeft-s.offsetWidth/2+i.offsetWidth/2;s.scrollTo({left:a,behavior:`smooth`});let c=e.offsetLeft-o.offsetWidth/2+e.offsetWidth/2;o.scrollTo({left:c,behavior:`smooth`}),g(!0)},b=e=>{s.querySelectorAll(`.wheel-item`).forEach(e=>e.classList.remove(`active`)),e.classList.add(`active`),clearTimeout(_),g(!0);let t=e.offsetLeft-s.offsetWidth/2+e.offsetWidth/2;s.scrollTo({left:t,behavior:`smooth`})};o.querySelectorAll(`.wheel-item`).forEach(e=>e.addEventListener(`click`,()=>y(e))),s.querySelectorAll(`.wheel-item`).forEach(e=>e.addEventListener(`click`,()=>b(e))),setTimeout(()=>{requestAnimationFrame(()=>{let e=`${l}-${String(u).padStart(2,`0`)}-${String(d).padStart(2,`0`)}`,t=s.querySelector(`.wheel-item[data-date="${e}"]`),n=t?parseInt(t.dataset.month,10):u,r=o.querySelector(`.wheel-item[data-month="${n}"]`);t&&(t.classList.add(`active`),C.hidden||(s.scrollLeft=t.offsetLeft-s.offsetWidth/2+t.offsetWidth/2)),r&&(r.classList.add(`active`),o.scrollLeft=r.offsetLeft-o.offsetWidth/2+r.offsetWidth/2),de(),C.hidden||g(!0)})},0);let x={mode:`history`,year:l,month:i.getMonth(),historyStories:a,myStories:[],bookmarkedIds:r},S=e.querySelector(`#editorstory-view-toggle`),C=e.querySelector(`#editorstory-day-picker`),w=e.querySelector(`#editorstory-cal-view`),T=sessionStorage.getItem(`ds_session_view`)??(localStorage.getItem(`ds_default_view`)||`card`);T===`calendar`&&J(e,x,i),S.addEventListener(`click`,()=>{T===`card`?(T=`calendar`,sessionStorage.setItem(`ds_session_view`,`calendar`),S.innerHTML=ke,C.hidden=!0,c.hidden=!0,w.hidden=!1,requestAnimationFrame(()=>{w.classList.add(`view-enter`),J(e,x,i),setTimeout(()=>w.classList.remove(`view-enter`),250)})):(T=`card`,sessionStorage.setItem(`ds_session_view`,`card`),S.innerHTML=Oe,w.hidden=!0,C.hidden=!1,c.hidden=!1,requestAnimationFrame(()=>{let e=s.querySelector(`.wheel-item.active`);e&&(s.scrollLeft=e.offsetLeft-s.offsetWidth/2+e.offsetWidth/2),g(!0),c.classList.add(`view-enter`),setTimeout(()=>c.classList.remove(`view-enter`),250)}))});let E;o.addEventListener(`scroll`,()=>{T===`calendar`&&(clearTimeout(E),E=setTimeout(()=>{let t=m(o);if(!t)return;let n=parseInt(t.dataset.month,10)-1;n===x.month&&x.year===l||(x.month=n,x.year=l,J(e,x,i))},150))},{passive:!0}),e.querySelector(`#cal-prev-month`).addEventListener(`click`,()=>{--x.month,x.month<0&&(x.month=11,--x.year);let t=e.querySelector(`#editorstory-year-label`);t&&(t.textContent=x.year),J(e,x,i),h(x.month+1)}),e.querySelector(`#cal-next-month`).addEventListener(`click`,()=>{if(q(x,i))return;x.month+=1,x.month>11&&(x.month=0,x.year+=1);let t=e.querySelector(`#editorstory-year-label`);t&&(t.textContent=x.year),J(e,x,i),h(x.month+1)})}catch(t){console.error(`에디터 일화 데이터 로딩 실패:`,t),e.innerHTML=`
      <div class="editorstory-header"><h1 class="editorstory-title">Day Story</h1></div>
      <div class="empty-state">
        <div class="empty-state-title">${l(`common.load_failed_title`)}</div>
        <div class="empty-state-desc" style="color:var(--danger-color);margin-bottom:var(--space-2)">
          ${F(t.message||l(`common.unknown_error`))}
        </div>
        <div class="empty-state-desc">${l(`common.load_failed_desc`)}</div>
        <button class="btn btn-primary" onclick="location.reload()" style="margin-top:var(--space-4)">
          ${l(`common.refresh`)}
        </button>
      </div>
    `}}function Pe(e,t,n,r,i){if(!e)return;t=t?N(t):null;let a=Array.from(e.querySelectorAll(`.flip-container`)),o=a.pop()||null;a.forEach(e=>e.remove());let s=t?new Date(t.publish_date+`T00:00:00`):n,c=s.getMonth()+1,u=s.getDate(),d=n.getFullYear(),f=document.createElement(`div`);if(f.className=`flip-container`,t){let e=t.image_url||``,n=e?`src="${F(e)}"`:``;f.innerHTML=`
      <div class="flipper">
        <div class="front history-card-front">
          <div class="history-card-top">
            <div class="card-top-left">
              <div class="card-year">${F(t.historical_year)}</div>
              <div class="card-date">${c}. ${u}</div>
            </div>
            <div class="card-top-right">
              <div class="card-actions">
                <button class="card-action-btn" aria-label="공유">
                  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                    <circle cx="18" cy="5" r="3"/><circle cx="6" cy="12" r="3"/><circle cx="18" cy="19" r="3"/>
                    <line x1="8.59" y1="13.51" x2="15.42" y2="17.49"/><line x1="15.41" y1="6.51" x2="8.59" y2="10.49"/>
                  </svg>
                </button>
                <button class="card-action-btn" aria-label="보관함">
                  <svg viewBox="0 0 24 24" fill="${t&&r.includes(t.id)?`currentColor`:`none`}" stroke="currentColor" stroke-width="2">
                    <path d="M19 21l-7-5-7 5V5a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2z"/>
                  </svg>
                </button>
              </div>
              <div class="card-meta">
                ${F(t.card_count||``)} ${F(t.country)}<br>
                ${d} / ${String(c).padStart(2,`0`)} / ${String(u).padStart(2,`0`)}
              </div>
            </div>
          </div>
          <div class="history-card-image-wrap">
            <img ${n} alt="${F(t.figure_name)}" loading="eager" decoding="async" width="320" height="400" draggable="false" />
            <div class="card-image-title">${F(t.figure_name)}</div>
          </div>
        </div>
        <div class="back history-card-back">
          <div class="back-title">${F(t.figure_name)}</div>
          <hr class="back-divider" />
          <div class="back-body">
            ${(t.body||``).split(/\n|\\n/).map(e=>e.trim()?`<p>${F(e)}</p>`:`<p><br></p>`).join(``)}
          </div>
          <div class="back-footer">
            <button class="back-editor-btn" type="button" title="에디터 한마디" data-story-id="${F(t.id)}" data-comment="${F(t.editor_comment||``)}" data-editor-name="${F(t.editor&&t.editor.displayName||`DayStory`)}" style="${t.editor_comment&&t.editor_comment.trim()!==``?``:`visibility: hidden; pointer-events: none;`}">
              ${t.editor&&t.editor.photoURL?`<img src="${F(t.editor.photoURL)}" alt="editor" class="back-editor-avatar" loading="lazy" decoding="async" onerror="this.style.display='none';this.nextElementSibling.style.display='flex'" /><span class="back-editor-avatar-fallback" style="display:none">✍️</span>`:`<span class="back-editor-avatar-fallback">✍️</span>`}
            </button>
            <div class="back-date-actions">
              <div class="back-date">${F(t.historical_year)}년 ${c}월 ${u}일</div>
              <button class="card-detail-shortcut-btn" type="button" aria-label="${l(`home.detail_button`)}" title="${l(`home.detail_button`)}">${l(`home.detail_button`)}</button>
            </div>
          </div>
        </div>
      </div>
    `}else{let e=`${[`JAN`,`FEB`,`MAR`,`APR`,`MAY`,`JUN`,`JUL`,`AUG`,`SEP`,`OCT`,`NOV`,`DEC`][s.getMonth()]} ${u}, ${d}`;f.innerHTML=`
      <div class="flipper">
        <div class="front history-card-front empty-story-card">
          <div class="empty-story-day-circle">${u}</div>
          <div class="empty-story-title">${l(`home.empty_card_title`)}</div>
          <div class="empty-story-date">${e}</div>
        </div>
      </div>
    `}if(!i||!o){e.innerHTML=``,e.appendChild(f),Fe(f,t,r);return}o.classList.add(`card-stack-item`,`stack-exit-${i}`),f.classList.add(`card-stack-item`,`stack-enter-${i}`),e.appendChild(f),f.offsetWidth,f.classList.add(`active`);let p=()=>{o.parentNode&&o.remove(),f.classList.remove(`card-stack-item`,`stack-enter-${i}`,`active`),Fe(f,t,r)};f.addEventListener(`transitionend`,p,{once:!0}),setTimeout(()=>{f.classList.contains(`card-stack-item`)&&p()},De)}function Fe(t,n,r){let i=t.querySelector(`.flipper`);if(!i)return;let o=0,s=0,c=!1,u=null,d=!1,f=!1,p=0,m=0,h=0,g=0,_=null,v=(e,t,n=!1)=>{d||i.classList.contains(`is-flipping`)||(o=e,s=t,c=!1,u=null,f=n,m=Date.now(),h=e,g=t)},y=(e,t)=>{if(d)return;let n=e-o,r=t-s;if((Math.abs(n)>15||Math.abs(r)>15)&&(_=null),!u){if(Math.abs(n)<15&&Math.abs(r)<15)return;u=Math.abs(n)>Math.abs(r)?`x`:`y`}if(u===`y`)return;c||=(i.style.transition=`none`,!0);let a=i.classList.contains(`flipped`)?`rotateY(180deg)`:``;i.style.transform=`translateX(${n*.62}px) ${a}`},b=(e,t)=>{if(!c||d)return;d=!0;let n=e-o;if(i.style.transition=`transform 220ms cubic-bezier(0.16, 1, 0.3, 1)`,i.classList.add(`is-flipping`),u===`x`&&Math.abs(n)>64){if(f){i.style.transform=``,setTimeout(()=>{i.style.transition=``,i.classList.remove(`is-flipping`),c=!1,d=!1},220);return}if(Date.now()-Ae>=je){Ae=Date.now();let e=n<0?1:-1,t=document.getElementById(`editorstory-calendar`);if(t){let n=Array.from(t.querySelectorAll(`.wheel-item`)),r=n[n.findIndex(e=>e.classList.contains(`active`))+e];r&&r.click()}}}i.style.transform=``,setTimeout(()=>{i.style.transition=``,i.classList.remove(`is-flipping`),c=!1,d=!1},220)};i.addEventListener(`touchstart`,e=>{p=Date.now();let t=!!e.target.closest(`.back-body`);_=e.target,v(e.touches[0].clientX,e.touches[0].clientY,t)},{passive:!0}),i.addEventListener(`touchmove`,e=>{y(e.touches[0].clientX,e.touches[0].clientY),c&&e.preventDefault()},{passive:!1}),i.addEventListener(`touchend`,e=>{p=Date.now();let t=e.changedTouches[0].clientX,r=e.changedTouches[0].clientY;if(_&&_.closest(`.back-body`)&&!c&&Date.now()-m<=400&&Math.abs(t-h)<=20&&Math.abs(r-g)<=20){if(!n||i.classList.contains(`is-flipping`))return;i.classList.add(`is-flipping`),i.classList.toggle(`flipped`),setTimeout(()=>i.classList.remove(`is-flipping`),400);return}b(t,r)});let x=!1;i.addEventListener(`mousedown`,e=>{Date.now()-p<650||e.target.closest(`button`)||e.target.closest(`.back-body`)||(x=!0,v(e.clientX,e.clientY,!1))}),window._editorStoryMouseMove&&window.removeEventListener(`mousemove`,window._editorStoryMouseMove),window._editorStoryMouseUp&&window.removeEventListener(`mouseup`,window._editorStoryMouseUp),window._editorStoryMouseMove=e=>{x&&y(e.clientX,e.clientY)},window._editorStoryMouseUp=e=>{x&&(x=!1,b(e.clientX,e.clientY))},window.addEventListener(`mousemove`,window._editorStoryMouseMove),window.addEventListener(`mouseup`,window._editorStoryMouseUp);let S=t.querySelector(`.card-detail-shortcut-btn`),C=t.querySelector(`.card-action-btn[aria-label="공유"]`),w=t.querySelector(`.card-action-btn[aria-label="보관함"]`);S&&n&&S.addEventListener(`click`,t=>{t.stopPropagation(),e(`/detail/${n.id}`)}),C&&C.addEventListener(`click`,async t=>{t.stopPropagation();let r=a(`user`);if(r&&r.id===`guest`){P(l(`toast.login_required`),`info`),e(`/login`);return}await M(n,{kind:`history`})}),w&&w.addEventListener(`click`,async t=>{t.stopPropagation();let i=a(`user`);if(i&&i.id===`guest`){P(l(`toast.login_required`),`info`),e(`/login`);return}let o=await ae(n.id);if(o.error){P(o.error,`error`);return}if(P(o.bookmarked?l(`toast.bookmark_added`):l(`toast.bookmark_removed`),`success`),w.querySelector(`svg`).style.fill=o.bookmarked?`currentColor`:`none`,o.bookmarked&&!r.includes(n.id))r.push(n.id);else if(!o.bookmarked){let e=r.indexOf(n.id);e>-1&&r.splice(e,1)}}),i.addEventListener(`click`,e=>{if(!n||e.target.closest(`.card-action-btn`)||e.target.closest(`.back-editor-btn`)||e.target.closest(`.card-detail-shortcut-btn`)||c||i.classList.contains(`is-flipping`)||e.pointerType===`touch`&&e.target.closest(`.back-body`))return;let r=t.querySelector(`.editor-comment-bubble`);if(r&&!r.contains(e.target)){r.remove();return}if(n.id&&n.publish_date&&!U(n.id))if(W(n.publish_date)){let e=G(n.id,n.publish_date);e.ok&&!e.alreadyCollected&&P(l(`calendar.collect_success_text`),`success`)}else G(n.id,n.publish_date,{bypass:!0});i.classList.add(`is-flipping`),i.classList.toggle(`flipped`),document.dispatchEvent(new CustomEvent(`ds:card-flipped`)),setTimeout(()=>i.classList.remove(`is-flipping`),Ee)});let T=t.querySelector(`.back-editor-btn`);if(T){let e=null,n=()=>{let n=t.querySelector(`.editor-comment-bubble`);n&&n.remove(),e&&=(e(),null)},r=()=>{e&&e();let r=r=>{let i=t.querySelector(`.editor-comment-bubble`);if(!i){e&&=(e(),null);return}let a=r.target;T.contains(a)||i.contains(a)||n()};document.addEventListener(`click`,r),e=()=>{document.removeEventListener(`click`,r)}};T.addEventListener(`click`,e=>{e&&e.stopPropagation();let i=t.querySelector(`.editor-comment-bubble`);if(i){if(i.contains(e.target))return;n();return}let a=T.dataset.comment,o=T.dataset.editorName||`DayStory`;if(!a)return;let s=document.createElement(`div`);s.className=`editor-comment-bubble`;let c=document.createElement(`span`);c.className=`editor-comment-name`,c.textContent=o,s.appendChild(c),s.appendChild(document.createTextNode(a)),T.appendChild(s),r()})}}c();function Ie(){typeof navigator>`u`||!(`serviceWorker`in navigator)||navigator.serviceWorker.register(`/daystory-image-cache-sw.js`).catch(e=>{console.warn(`Image cache worker registration skipped:`,e)})}Ie(),r(`/login`,()=>k(()=>import(`./login-D0yLL7_J.js`).then(e=>e.renderLogin()),__vite__mapDeps([2,3,4,1,5,6,7,8,9]))),r(`/signup`,()=>k(()=>import(`./login-D0yLL7_J.js`).then(e=>e.renderSignup()),__vite__mapDeps([2,3,4,1,5,6,7,8,9]))),r(`/editorstory`,()=>Me()),r(`/detail/:id`,e=>k(()=>import(`./detail-P32nPey4.js`).then(t=>t.renderDetail(e)),__vite__mapDeps([10,11,3,1,6,5,12,8,9,7,13,14]))),r(`/share/:id`,async e=>{let[{recordReceived:t},n]=await Promise.all([k(()=>import(`./receivedCards-8POjwrst.js`),__vite__mapDeps([15,13,6,1,5])),k(()=>import(`./detail-P32nPey4.js`),__vite__mapDeps([10,11,3,1,6,5,12,8,9,7,13,14]))]);return t(e.id),n.renderDetail(e)}),r(`/profile`,()=>k(()=>import(`./profile-j-LFABpd.js`).then(e=>e.renderProfile()),__vite__mapDeps([16,17,1,18,6,5,19,7,20,11,3,12,8,9,13,14,21]))),r(`/search`,()=>k(()=>import(`./search-wY_yJ26U.js`).then(e=>e.renderSearch()),__vite__mapDeps([22,13,6,1,5,8,14]))),r(`/settings`,()=>k(()=>import(`./settings-DyFSTtHj.js`).then(e=>e.renderSettings()),__vite__mapDeps([23,3,1,5,6,12,8,9,19,7,21]))),r(`/report`,()=>k(()=>import(`./report-C5QkzEhM.js`).then(e=>e.renderReport()),__vite__mapDeps([24,7,8]))),r(`/editor`,()=>k(()=>import(`./editor-wxwB_9rA.js`).then(e=>e.renderEditor()),__vite__mapDeps([25,17,1,18,6,5,7,13,8,9,14,21]))),r(`/editor/new`,()=>k(()=>import(`./editor-wxwB_9rA.js`).then(e=>e.renderEditorNew()),__vite__mapDeps([25,17,1,18,6,5,7,13,8,9,14,21]))),r(`/mystory`,()=>k(()=>import(`./mystory-vj8FuVPi.js`).then(e=>e.renderMyStory()),__vite__mapDeps([26,17,1,18,11,3,6,5,12,8,9,19,7,13,14,21]))),r(`/mystory/new`,()=>k(()=>import(`./mystory-vj8FuVPi.js`).then(e=>e.renderMyStoryNew()),__vite__mapDeps([26,17,1,18,11,3,6,5,12,8,9,19,7,13,14,21]))),r(`/bookmarks`,()=>k(()=>import(`./bookmarks-CHgGixuw.js`).then(e=>e.renderBookmarks()),__vite__mapDeps([20,11,3,1,6,5,12,8,9,7,13,14]))),r(`/license`,()=>k(()=>import(`./license-Cgs_AAnm.js`).then(e=>e.renderLicense()),__vite__mapDeps([27,13,6,1,5]))),r(`/about`,()=>k(()=>import(`./about-BnsomedG.js`).then(e=>e.renderAbout()),__vite__mapDeps([28,12,8,9,14]))),i(t=>{let n=a(`user`);n||(n={id:`guest`,role:`guest`},o(`user`,n));let r=document.getElementById(`bottom-nav`);if(r){let e=t.startsWith(`/detail/`)||t===`/report`||t===`/login`||t===`/signup`||t===`/license`||t===`/settings`||t===`/about`||t===`/mystory/new`;r.style.display=e?`none`:`flex`}return(t===`/login`||t===`/signup`)&&n&&n.id!==`guest`?(e(`/editorstory`),!1):!0});var Y=null;function Le(t){if(!t)return!1;let n;try{n=new URL(t)}catch{return!1}if(n.protocol!==`daystory:`)return!1;let r=[n.hostname,n.pathname.replace(/^\/+/,``)].filter(Boolean).join(`/`);return t===`daystory://letter`||r===`letter`?(e(`/editorstory`),!0):t===`daystory://diary/new`||r===`diary/new`?(e(`/mystory/new?date=${A()}`),!0):!1}function Re(e){if(e){if(!Z){Y=e;return}Le(e)}}var X=!1,ze=!1,Z=!1;function Q(){if(Z||!X||!ze)return;Z=!0;let e=document.getElementById(`splash-screen`),n=document.getElementById(`app-container`);if(n&&(n.style.display=`flex`),e&&(e.classList.add(`hide`),e.addEventListener(`transitionend`,()=>e.remove()),setTimeout(()=>{e.parentNode&&e.remove()},500)),t(),Y){let e=Y;Y=null,Le(e)}}C&&u(C,async t=>{try{if(t){if(o(`user`,{id:t.uid,email:t.email,displayName:t.displayName}),y)try{let e=m(y,`profiles`,t.uid),n=await b(e),r=null,i=[`daystory@test.com`,`dokhubooks@gmail.com`,`ldj729@gmail.com`].includes(t.email);n.exists()?(r=n.data(),i&&r.role!==`editor`&&(r.role=`editor`,await D(e,r,{merge:!0}))):i&&(r={role:`editor`,created_at:new Date().toISOString()},await D(e,r)),r&&(o(`profile`,r),r.theme&&o(`theme`,r.theme),r.font_size&&o(`fontSize`,r.font_size))}catch(e){console.warn(`프로필 로드 (또는 생성) 실패:`,e)}let n=document.getElementById(`bottom-nav`);n&&(n.style.display=`flex`);let r=window.location.hash;(r===`#/login`||r===`#/signup`||!r)&&e(`/editorstory`)}else o(`user`,{id:`guest`,role:`guest`}),o(`profile`,null)}catch(e){console.warn(`인증 상태 변경 중 오류:`,e)}finally{X=!0,Q()}});async function $(){s(),ze=!0,C||(o(`user`,{id:`guest`,role:`guest`}),X=!0),Q(),setTimeout(()=>{Z||(console.warn(`인증 응답 지연으로 강제 시작합니다.`),X=!0,Q())},5e3)}if(document.readyState===`loading`?document.addEventListener(`DOMContentLoaded`,$):$(),O.isNativePlatform()&&(I.addListener(`appUrlOpen`,({url:e})=>{Re(e)}),I.getLaunchUrl().then(e=>Re(e?.url)).catch(e=>console.warn(`위젯 딥링크 확인 실패:`,e)),I.addListener(`appStateChange`,({isActive:e})=>{e&&syncSubscriptionState().catch(()=>{})})),O.isNativePlatform()){let t={"/editorstory":{depth:0,parent:null},"/login":{depth:1,parent:`/editorstory`},"/mystory":{depth:1,parent:`/editorstory`},"/archive":{depth:1,parent:`/editorstory`},"/search":{depth:1,parent:`/editorstory`},"/settings":{depth:1,parent:`/editorstory`},"/detail":{depth:2,parent:`/archive`},"/report":{depth:2,parent:null},"/editor":{depth:2,parent:`/settings`},"/editor/new":{depth:3,parent:`/editor`}};function r(e){if(t[e])return t[e];let n=`/`+e.split(`/`).filter(Boolean)[0];return t[n]?t[n]:{depth:1,parent:`/editorstory`}}let i=0;function a(){let e=document.createElement(`div`);e.innerText=`한 번 더 눌러 종료`,Object.assign(e.style,{position:`fixed`,bottom:`100px`,left:`50%`,transform:`translateX(-50%)`,backgroundColor:`rgba(0,0,0,0.7)`,color:`white`,padding:`12px 24px`,borderRadius:`24px`,zIndex:`10000`,fontSize:`var(--text-sm)`,fontFamily:`var(--font-sans)`,pointerEvents:`none`,transition:`opacity 0.3s ease`}),document.body.appendChild(e),setTimeout(()=>{e.style.opacity=`0`,setTimeout(()=>e.remove(),300)},2e3)}I.addListener(`backButton`,()=>{let t=r(n());if(t.depth===0){let e=Date.now();e-i<2e3?I.exitApp():(i=e,a());return}t.parent?e(t.parent):window.history.back()})}export{ye as a,me as c,fe as d,I as f,J as i,he as l,q as n,ge as o,Se as r,ve as s,be as t,_e as u};