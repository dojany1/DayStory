const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/web-Yz73wu6w.js","assets/dist-N3LOKtlT.js","assets/login-ClYrVLa-.js","assets/esm-CBiP99B1.js","assets/preload-helper-Dd-HcVz_.js","assets/definitions-DpJzfrOC.js","assets/index.esm-Bc1dmMJH.js","assets/firebase-DGvE0Cu9.js","assets/toast-C-m3kd2X.js","assets/router-hybKseu2.js","assets/state-8PRbPWwW.js","assets/detail-DcN1st1f.js","assets/storyI18n-jEOB5Mpt.js","assets/i18n-B_-hulXt.js","assets/stories-CrhQJ4Gf.js","assets/sanitize-DlMVmTsh.js","assets/receivedCards-wnhZcpR0.js","assets/profile-CMgOfGhd.js","assets/cropper-RFou76ed.js","assets/cropper-cx_wrqbx.css","assets/pageHeader-C1YuwkAJ.js","assets/bookmarks-DuVx0Hi7.js","assets/scrollLock-ByagqdMz.js","assets/search-BGPtmJYx.js","assets/settings-C8hWT7px.js","assets/report-pI6Q5s_8.js","assets/editor-DhIJBcsK.js","assets/mystory-vFmZ-LNo.js","assets/license-owjVvUdM.js","assets/about-CMrlj38O.js"])))=>i.map(i=>d[i]);
import{a as e,i as t,n,o as r,s as i}from"./router-hybKseu2.js";import{n as a,r as o,t as s}from"./state-8PRbPWwW.js";import{n as c,r as l}from"./i18n-B_-hulXt.js";import{O as u}from"./index.esm-Bc1dmMJH.js";import{S as d,_ as f,b as p,c as m,d as h,f as g,h as _,i as v,m as y,n as b,p as x,r as S,t as C,u as w,v as T,x as E,y as D}from"./firebase-DGvE0Cu9.js";import{i as ee,t as O}from"./dist-N3LOKtlT.js";import{t as k}from"./preload-helper-Dd-HcVz_.js";import{d as A,o as te,p as j,r as ne,u as re}from"./stories-CrhQJ4Gf.js";import{a as ie,r as M,s as N,t as P}from"./storyI18n-jEOB5Mpt.js";import{t as F}from"./toast-C-m3kd2X.js";import{t as I}from"./sanitize-DlMVmTsh.js";import{n as ae,t as oe}from"./scrollLock-ByagqdMz.js";(function(){let e=document.createElement(`link`).relList;if(e&&e.supports&&e.supports(`modulepreload`))return;for(let e of document.querySelectorAll(`link[rel="modulepreload"]`))n(e);new MutationObserver(e=>{for(let t of e)if(t.type===`childList`)for(let e of t.addedNodes)e.tagName===`LINK`&&e.rel===`modulepreload`&&n(e)}).observe(document,{childList:!0,subtree:!0});function t(e){let t={};return e.integrity&&(t.integrity=e.integrity),e.referrerPolicy&&(t.referrerPolicy=e.referrerPolicy),e.crossOrigin===`use-credentials`?t.credentials=`include`:e.crossOrigin===`anonymous`?t.credentials=`omit`:t.credentials=`same-origin`,t}function n(e){if(e.ep)return;e.ep=!0;let n=t(e);fetch(e.href,n)}})();var se={name:`daystory`,version:`1.3.5`,private:!0,type:`module`,scripts:{dev:`vite`,build:`vite build`,preview:`vite preview`,test:`vitest run --environment jsdom`,"harness:auto":`node scripts/codex-harness.mjs`,harness:`node scripts/codex-harness.mjs`,"harness:status":`node scripts/codex-harness.mjs --status`,"harness:commit":`node scripts/harness-commit.mjs`},devDependencies:{"@capacitor/assets":`^3.0.5`,jsdom:`^29.0.2`,vite:`^8.0.1`,vitest:`^4.1.5`},dependencies:{"@capacitor-firebase/authentication":`^8.2.0`,"@capacitor/android":`^8.3.4`,"@capacitor/app":`^8.1.0`,"@capacitor/camera":`^8.0.0`,"@capacitor/cli":`^8.3.0`,"@capacitor/core":`^8.3.0`,"@capacitor/device":`^8.0.2`,"@capacitor/ios":`^8.3.4`,"@capacitor/local-notifications":`^8.0.2`,"@capacitor/share":`^8.0.1`,"@capacitor/splash-screen":`^8.0.1`,"@capacitor/status-bar":`^8.0.2`,"@revenuecat/purchases-capacitor":`^13.1.0`,cropperjs:`^1.6.2`,firebase:`^10.14.1`}},L=ee(`App`,{web:()=>k(()=>import(`./web-Yz73wu6w.js`).then(e=>new e.AppWeb),__vite__mapDeps([0,1]))}),ce=ee(`DayStoryWidget`),R=()=>O.getPlatform&&O.getPlatform()===`android`,le=`daystory:letterReadDate:`;function z(){return A()}async function ue(e){if(R())try{await ce.setLetterState({hasNewLetter:!!e})}catch(e){console.warn(`[widget] setLetterState 실패:`,e)}}async function de(e,t=z()){if(R())try{await ce.setDiaryState({hasTodayDiary:!!e,diaryDate:t||z()})}catch(e){console.warn(`[widget] setDiaryState 실패:`,e)}}async function fe(){let e=le+z();try{if(localStorage.getItem(e)===`1`)return;localStorage.setItem(e,`1`)}catch{}await ue(!1)}async function pe(e){if(!Array.isArray(e))return;let t=z();await de(e.some(e=>e&&e.publish_date===t),t)}var B=`ds_collected_cards`;function V(){try{return JSON.parse(localStorage.getItem(B)||`{}`)}catch{return{}}}function H(e){localStorage.setItem(B,JSON.stringify(e))}function U(e){return!!V()[e]}function W(e){return e===A()}function G(e,t,n={}){if(U(e))return{ok:!0,alreadyCollected:!0};if(!n.bypass&&!W(t))return{ok:!1,alreadyCollected:!1};let r=V();return r[e]=A(),H(r),{ok:!0,alreadyCollected:!1}}function me(e){if(!Array.isArray(e)||e.length===0)return 0;let t=V(),n=A(),r=0;for(let i of e)!i||t[i]||(t[i]=n,r+=1);return r>0&&H(t),r}async function he(e){if(!b)return[];try{let t=T(h(b,`userStories`),d(`uid`,`==`,e),f(`publish_date`,`desc`),f(`created_at`,`desc`));return(await Promise.race([_(t),new Promise((e,t)=>setTimeout(()=>t(Error(`timeout`)),5e3))])).docs.map(e=>({id:e.id,...e.data()}))}catch(e){return console.warn(`fetchMyStories 에러:`,e),[]}}async function ge(e,t){if(!b)return null;try{let n=await y(x(b,`userStories`,e));return n.exists()&&n.data().uid===t?{id:n.id,...n.data()}:null}catch(e){return console.warn(`fetchMyStoryById 에러:`,e),null}}async function _e(e){if(!b){console.log(`[DB Mock] createMyStory:`,e);return}await w(h(b,`userStories`),{...e,created_at:D(),updated_at:D()})}async function ve(e,t){if(!b){console.log(`[DB Mock] updateMyStory:`,e,t);return}await E(x(b,`userStories`,e),{...t,updated_at:D()})}async function ye(e){if(!b){console.log(`[DB Mock] deleteMyStory:`,e);return}try{let t=await y(x(b,`userStories`,e));if(t.exists()){let e=t.data();e.image_url&&(e.image_url.includes(`firebasestorage`)||e.image_url.includes(`.firebasestorage.app`))&&await v(m(S,e.image_url)).catch(e=>console.warn(`Storage delete fail`,e))}}catch(e){console.warn(`deleteMyStory image delete skip:`,e)}await g(x(b,`userStories`,e))}function K({title:e,message:t=``,confirmText:n=`확인`,cancelText:r=`취소`,danger:i=!1,holdDuration:a=0,holdMessage:o}={}){return new Promise(s=>{document.querySelectorAll(`.confirm-dialog-overlay`).forEach(e=>e.remove());let c=document.createElement(`div`);c.className=`confirm-dialog-overlay`,c.setAttribute(`role`,`dialog`),c.setAttribute(`aria-modal`,`true`);let l=String(t).split(`
`).map(e=>`<p class="confirm-dialog-line">${q(e)}</p>`).join(``),u=Number.isFinite(a)&&a>0,d=u?Math.ceil(a/1e3):0,f=typeof o==`function`?o:e=>`${e}초간 누르고 계세요...`,p=u?f(d):``;c.innerHTML=`
      <div class="confirm-dialog">
        ${u?`<div class="confirm-dialog-status" aria-live="polite">${q(p)}</div>`:``}
        <div class="confirm-dialog-title">${q(e||``)}</div>
        ${t?`<div class="confirm-dialog-message">${l}</div>`:``}
        <div class="confirm-dialog-actions">
          <button type="button" class="confirm-dialog-btn confirm-dialog-cancel">${q(r)}</button>
          <button type="button" class="confirm-dialog-btn confirm-dialog-confirm${i?` is-danger`:``}${u?` has-hold`:``}">
            <span class="confirm-dialog-confirm-fill" aria-hidden="true"></span>
            <span class="confirm-dialog-confirm-label">${q(n)}</span>
          </button>
        </div>
      </div>
    `,(document.querySelector(`.mobile-wrapper`)||document.body).appendChild(c),oe(),requestAnimationFrame(()=>c.classList.add(`visible`));let m=c.querySelector(`.confirm-dialog-confirm`),h=c.querySelector(`.confirm-dialog-status`),g=c.querySelector(`.confirm-dialog-confirm-fill`),_=0,v=0,y=!1,b=!1,x=({silent:e=!1}={})=>{u&&(y=!1,_&&=(cancelAnimationFrame(_),0),m&&m.classList.remove(`is-holding`),g&&(g.style.transform=`scaleX(0)`),!e&&h&&(h.textContent=p))},S=()=>{if(!y)return;let e=performance.now()-v,t=Math.min(1,e/a);g&&(g.style.transform=`scaleX(${t})`);let n=Math.max(0,Math.ceil((a-e)/1e3));if(h&&(h.textContent=f(n)),t>=1){b=!0,x({silent:!0}),w(!0);return}_=requestAnimationFrame(S)},C=e=>{!u||b||y||(e&&typeof e.preventDefault==`function`&&e.preventDefault(),y=!0,v=performance.now(),m&&m.classList.add(`is-holding`),h&&(h.textContent=f(d)),_=requestAnimationFrame(S))},w=e=>{x({silent:!0}),document.removeEventListener(`keydown`,T),ae(),c.classList.remove(`visible`),setTimeout(()=>{c.remove(),s(e)},180)};c.querySelector(`.confirm-dialog-cancel`).addEventListener(`click`,()=>w(!1)),u?(m.addEventListener(`pointerdown`,e=>{if(!(e.button!==void 0&&e.button!==0)){try{m.setPointerCapture(e.pointerId)}catch{}C(e)}}),[`pointerup`,`pointercancel`,`pointerleave`,`lostpointercapture`].forEach(e=>{m.addEventListener(e,()=>x())}),m.addEventListener(`click`,e=>{b||(e.preventDefault(),e.stopPropagation())})):m.addEventListener(`click`,()=>w(!0)),c.addEventListener(`click`,e=>{e.target===c&&w(!1)});let T=e=>{e.key===`Escape`&&w(!1)};document.addEventListener(`keydown`,T)})}function q(e){return e==null?``:String(e).replace(/&/g,`&amp;`).replace(/</g,`&lt;`).replace(/>/g,`&gt;`).replace(/"/g,`&quot;`).replace(/'/g,`&#x27;`)}var be=[`일`,`월`,`화`,`수`,`목`,`금`,`토`];function J(e,t){return e.year===t.getFullYear()&&e.month===t.getMonth()}function Y(t,n,r){let i=t.querySelector(`#calendar-grid`),o=t.querySelector(`#cal-month-label`);if(!i||!o)return;o.textContent=`${n.year}년 ${n.month+1}월`;let s=t.querySelector(`#cal-next-month`);if(s){let e=J(n,r);s.disabled=e,s.classList.toggle(`disabled`,e)}let c=n.mode===`history`?n.historyStories:n.myStories,l=new Map;c.forEach(e=>{e&&e.publish_date&&l.set(e.publish_date,e)}),c.filter(e=>{if(!e?.publish_date)return!1;let[t,r]=e.publish_date.split(`-`);return Number(t)===n.year&&Number(r)===n.month+1}),(a(`profile`)||{}).role;let u=j(`${n.year}-${String(n.month+1).padStart(2,`0`)}-01`).getDay(),d=re(n.year,n.month+1),f=``;for(let e=0;e<u;e++)f+=`<div class="cal-cell cal-cell-blank"></div>`;for(let e=1;e<=d;e++){let t=String(n.month+1).padStart(2,`0`),i=String(e).padStart(2,`0`),a=`${n.year}-${t}-${i}`,o=l.get(a),s=j(a);if(!s)continue;let c=s>r,u=s.getTime()===r.getTime(),d=s.getDay(),p=n.mode===`mine`&&!o&&!c,m=[`cal-cell`,c?`cal-cell-future`:``,u?`cal-cell-today`:``,o?`cal-cell-has-story`:`cal-cell-empty`,p?`cal-cell-mine-write`:``,d===0?`sun`:d===6?`sat`:``].filter(Boolean).join(` `),h=o?xe(o,n.mode):``;f+=`
      <button type="button" class="${m}" data-date="${a}" ${o||p?``:`disabled aria-disabled="true"`}>
        <span class="cal-cell-day">${e}</span>
        ${h}
        ${p&&u?`<div class="cal-cell-write-prompt">
           <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round">
             <line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/>
           </svg>
         </div>`:``}
      </button>
    `}let p=(7-(u+d)%7)%7;for(let e=0;e<p;e++)f+=`<div class="cal-cell cal-cell-blank"></div>`;i.innerHTML=f,i.querySelectorAll(`.cal-cell-has-story`).forEach(e=>{e.addEventListener(`click`,()=>{let t=e.dataset.date,r=l.get(t);r&&Se(r,n.mode,n.bookmarkedIds)})}),i.querySelectorAll(`.cal-cell-mine-write`).forEach(t=>{t.addEventListener(`click`,()=>{let n=t.dataset.date;n&&e(`/mystory/new?date=${n}`)})})}function xe(e,t){let n=e.image_url||``;return`
    <span class="cal-cell-peek" aria-hidden="true">
      <img class="cal-cell-peek-img" ${n?`src="${I(n)}"`:``} alt="" loading="lazy" decoding="async" draggable="false" />
      <span class="cal-cell-peek-title">${I(t===`history`?e.figure_name||e.title||``:e.title||``)}</span>
    </span>
  `}function Se(t,n,r=[],i={}){document.querySelectorAll(`.calendar-card-popup`).forEach(e=>e.remove()),n===`history`&&(t=P(t));let o=j(t.publish_date||``),s=!!o,c=s?o.getMonth()+1:``,u=s?o.getDate():``,d=s?o.getFullYear():``,f=n===`history`&&t.id?U(t.id):!1;n===`history`&&!f&&t.id&&t.publish_date&&!W(t.publish_date)&&G(t.id,t.publish_date,{bypass:!0}).ok&&(f=!0),n===`history`&&t.publish_date&&W(t.publish_date);let p=document.createElement(`div`);p.className=`calendar-card-popup`,p.innerHTML=`
    <div class="calendar-card-popup-inner">
      <button type="button" class="calendar-card-popup-close" aria-label="닫기">
        <svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" stroke-width="2.5">
          <line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/>
        </svg>
      </button>
      <div class="calendar-card-popup-stage">
        ${n===`history`?Ce(t,d,c,u,r,f,{showDeleteBtn:!!i.onRemove}):Te(t,d,c,u,we(t))}
      </div>
      ${i.hideHint?``:`<div class="calendar-card-popup-hint">${l(f?`calendar.card_collected_hint`:`calendar.card_tap_hint`)}</div>`}
    </div>
  `,document.body.appendChild(p),oe(),requestAnimationFrame(()=>p.classList.add(`open`));let m=()=>{ae(),p.classList.remove(`open`),setTimeout(()=>{p.parentNode&&p.remove()},240)};if(p.querySelector(`.calendar-card-popup-close`).addEventListener(`click`,e=>{e.stopPropagation(),m()}),p.addEventListener(`click`,e=>{(e.target===p||e.target.classList.contains(`calendar-card-popup-inner`))&&m()}),i.onRemove){let e=p.querySelector(`.card-delete-btn`);e&&e.addEventListener(`click`,async e=>{e.stopPropagation(),await K({title:l(`bookmarks.remove_confirm_title`),message:l(`bookmarks.remove_confirm_message`),confirmText:l(`bookmarks.remove_btn`),cancelText:l(`common.cancel`),danger:!0})&&(await i.onRemove(t),m())})}let h=p.querySelector(`.flipper`);h&&h.addEventListener(`click`,e=>{e.target.closest(`.card-action-btn`)||e.target.closest(`.card-detail-shortcut-btn`)||e.target.closest(`.back-editor-btn`)||e.target.closest(`.editor-comment-bubble`)||e.target.closest(`.collect-btn`)||h.classList.contains(`is-flipping`)||(h.classList.add(`is-flipping`),h.classList.toggle(`flipped`),setTimeout(()=>h.classList.remove(`is-flipping`),400))});let g=p.querySelector(`.collect-btn`);g&&n===`history`&&t.id&&g.addEventListener(`click`,e=>{if(e.stopPropagation(),U(t.id))return;if(!G(t.id,t.publish_date||``).ok){F(l(`calendar.collect_locked_toast`),`info`);return}g.classList.add(`collect-btn--done`),g.disabled=!0,g.textContent=l(`calendar.collected_button`),F(l(`calendar.collect_success_text`),`success`);let n=p.querySelector(`.calendar-card-popup-hint`);n&&(n.textContent=l(`calendar.card_collected_hint`)),p._collected=!0});let _=p.querySelector(`.card-detail-shortcut-btn`);_&&n===`history`&&t.id&&_.addEventListener(`click`,n=>{n.stopPropagation(),m(),e(`/detail/${t.id}`)});let v=p.querySelector(`.back-editor-btn`);if(v){let e=null,t=()=>{let t=p.querySelector(`.editor-comment-bubble`);t&&t.remove(),e&&=(e(),null)};v.addEventListener(`click`,n=>{n.stopPropagation();let r=p.querySelector(`.editor-comment-bubble`);if(r){if(r.contains(n.target))return;t();return}let i=v.dataset.comment,a=v.dataset.editorName||`DayStory`;if(!i)return;let o=document.createElement(`div`);o.className=`editor-comment-bubble`;let s=document.createElement(`span`);s.className=`editor-comment-name`,s.textContent=a,o.appendChild(s),o.appendChild(document.createTextNode(i)),v.appendChild(o);let c=e=>{v.contains(e.target)||t()};document.addEventListener(`click`,c),e=()=>document.removeEventListener(`click`,c)})}if(n!==`history`){let n=p.querySelector(`.share-my-story-btn`),r=p.querySelector(`.edit-my-story-btn`);n&&n.addEventListener(`click`,async e=>{e.stopPropagation(),await M(t,{kind:`mystory`,includeImage:!1})}),r&&r.addEventListener(`click`,t=>{t.stopPropagation(),m(),e(`/mystory/new?edit=`+r.dataset.id)})}if(n===`history`){let n=p.querySelector(`.card-action-btn[aria-label="공유"]`),i=p.querySelector(`.card-action-btn[aria-label="보관함"]`);n&&n.addEventListener(`click`,async n=>{n.stopPropagation();let r=a(`user`);if(r&&r.id===`guest`){F(l(`toast.login_required`),`info`),m(),e(`/login`);return}await M(t,{kind:`history`})}),i&&i.addEventListener(`click`,async n=>{n.stopPropagation();let o=a(`user`);if(o&&o.id===`guest`){F(l(`toast.login_required`),`info`),m(),e(`/login`);return}let s=await N(t.id);if(s.error){F(s.error,`error`);return}F(s.bookmarked?l(`toast.bookmark_added`):l(`toast.bookmark_removed`),`success`);let c=i.querySelector(`svg`);if(c&&(c.style.fill=s.bookmarked?`currentColor`:`none`),s.bookmarked&&!r.includes(t.id))r.push(t.id);else if(!s.bookmarked){let e=r.indexOf(t.id);e>-1&&r.splice(e,1)}})}}function Ce(e,t,n,r,i=[],a=!1,o={}){let s=(e.body||``).split(/\n|\\n/).map(e=>e.trim()?`<p>${I(e)}</p>`:`<p><br></p>`).join(``),c=!!(e.id&&i.includes(e.id)),u=e.editor_comment||``,d=e.editor&&e.editor.photoURL||``,f=e.editor&&e.editor.displayName||`DayStory`,p=!u.trim(),m=e.image_url||``,h=m?`src="${I(m)}"`:``;return`
    <div class="flip-container">
      <div class="flipper">
        <div class="front history-card-front">
          <div class="history-card-top">
            <div class="card-top-left">
              <div class="card-year">${I(e.historical_year||t)}</div>
              <div class="card-date">${n}. ${r}</div>
            </div>
            <div class="card-top-right">
              <div class="card-actions">
                <button class="card-action-btn" aria-label="공유">
                  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                    <circle cx="18" cy="5" r="3"/><circle cx="6" cy="12" r="3"/><circle cx="18" cy="19" r="3"/>
                    <line x1="8.59" y1="13.51" x2="15.42" y2="17.49"/><line x1="15.41" y1="6.51" x2="8.59" y2="10.49"/>
                  </svg>
                </button>
                <button class="card-action-btn" aria-label="보관함">
                  <svg viewBox="0 0 24 24" fill="${c?`currentColor`:`none`}" stroke="currentColor" stroke-width="2">
                    <path d="M19 21l-7-5-7 5V5a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2z"/>
                  </svg>
                </button>
              </div>
              <div class="card-meta">
                ${I(e.country||``)}<br>
                ${t} / ${String(n).padStart(2,`0`)} / ${String(r).padStart(2,`0`)}
              </div>
            </div>
          </div>
          <div class="history-card-image-wrap">
            <img ${h} alt="${I(e.figure_name||``)}" loading="eager" decoding="async" width="320" height="400" draggable="false" />
            <div class="card-image-title">${I(e.figure_name||``)}</div>
          </div>
        </div>
        <div class="back history-card-back">
          ${o.showDeleteBtn?`
            <button class="card-delete-btn" type="button" aria-label="${I(l(`bookmarks.remove_btn`))}" title="${I(l(`bookmarks.remove_btn`))}">
              <svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                <polyline points="3 6 5 6 21 6"/>
                <path d="M19 6l-1 14a2 2 0 0 1-2 2H8a2 2 0 0 1-2-2L5 6"/>
                <path d="M10 11v6"/><path d="M14 11v6"/>
                <path d="M9 6V4a2 2 0 0 1 2-2h2a2 2 0 0 1 2 2v2"/>
              </svg>
            </button>`:``}
          <div class="back-title">${I(e.figure_name||``)}</div>
          <hr class="back-divider" />
          <div class="back-body">${s}</div>
          <div class="back-footer">
            <button class="back-editor-btn" type="button" title="에디터 한마디" data-comment="${I(u)}" data-editor-name="${I(f)}" style="${p?`visibility: hidden; pointer-events: none;`:``}">
              ${d?`<img src="${I(d)}" alt="editor" class="back-editor-avatar" loading="lazy" decoding="async" onerror="this.style.display='none';this.nextElementSibling.style.display='flex'" /><span class="back-editor-avatar-fallback" style="display:none">✍️</span>`:`<span class="back-editor-avatar-fallback">✍️</span>`}
            </button>
            <div class="back-date-actions">
              <div class="back-date">${I(e.historical_year||t)}년 ${n}월 ${r}일</div>
              <button class="card-detail-shortcut-btn" type="button">${I(l(`home.detail_button`))}</button>
            </div>
          </div>
        </div>
      </div>
    </div>
  `}function we(e){let t=a(`profile`)||{},n=a(`user`)||{},r=typeof n.email==`string`?n.email.split(`@`)[0]:``;return[e.author_nickname,e.authorNickname,e.author?.nickname,e.author?.displayName,t.nickname,n.displayName,r].map(e=>typeof e==`string`?e.trim():``).find(Boolean)||`사용자`}function Te(e,t,n,r,i=``){let a=(e.body||``).split(/\n|\\n/).map(e=>e.trim()?`<p>${I(e)}</p>`:`<p><br></p>`).join(``),o=e.image_url||``,s=o?`src="${I(o)}"`:``;return`
    <div class="flip-container">
      <div class="flipper mystory-flipper">
        <div class="front history-card-front">
          <div class="history-card-top">
            <div class="card-top-left">
              <div class="card-year mystory-card-year">${t}</div>
              <div class="card-date">${n}. ${r}</div>
            </div>
            <div class="card-top-right">
              <div class="card-actions">
                <button class="card-action-btn share-my-story-btn" data-id="${I(e.id||``)}" aria-label="공유">
                  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                    <circle cx="18" cy="5" r="3"/><circle cx="6" cy="12" r="3"/><circle cx="18" cy="19" r="3"/>
                    <line x1="8.59" y1="13.51" x2="15.42" y2="17.49"/><line x1="15.41" y1="6.51" x2="8.59" y2="10.49"/>
                  </svg>
                </button>
                <button class="card-action-btn edit-my-story-btn" data-id="${I(e.id||``)}" aria-label="수정">
                  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                    <path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"></path>
                    <path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"></path>
                  </svg>
                </button>
              </div>
              <div class="card-meta">${I(i)}</div>
            </div>
          </div>
          <div class="history-card-image-wrap">
            <img ${s} alt="${I(e.title||``)}" loading="eager" decoding="async" width="320" height="400" draggable="false" />
            <div class="card-image-title">${I(e.title||``)}</div>
          </div>
        </div>
        <div class="back history-card-back">
          <div class="back-title">${I(e.title||``)}</div>
          <hr class="back-divider" />
          <div class="back-body">${a}</div>
          <div class="back-footer">
            <div class="back-date">${t}년 ${n}월 ${r}일</div>
          </div>
        </div>
      </div>
    </div>
  `}var Ee=400,De=560,Oe=`<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M2 7v10"/><path d="M6 5v14"/><rect width="12" height="18" x="10" y="3" rx="2"/></svg>`,ke=`<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M8 2v4"/><path d="M16 2v4"/><rect width="18" height="18" x="3" y="4" rx="2"/><path d="M3 10h18"/><path d="M8 14h.01"/><path d="M12 14h.01"/><path d="M16 14h.01"/><path d="M8 18h.01"/><path d="M12 18h.01"/><path d="M16 18h.01"/></svg>`,Ae=0,je=1500;function Me(){let e=document.createElement(`div`);e.className=`editorstory-page page`;let t=sessionStorage.getItem(`ds_session_view`)??(localStorage.getItem(`ds_default_view`)||`card`);return e.innerHTML=`
    <div class="editorstory-header">
      <h1 class="editorstory-title"></h1>
    </div>

    <div class="wheel-pickers-container">
      <div class="wheel-year-label" id="editorstory-year-label">${new Date().getFullYear()}</div>
      <div class="wheel-picker-wrapper">
        <div class="wheel-selection-box"></div>
        <div class="modern-wheel-scroll" id="editorstory-month-scroll"></div>
        <button type="button" class="view-toggle-btn" id="editorstory-view-toggle" aria-label="보기 방식 변경">${t===`calendar`?ke:Oe}</button>
      </div>
      <div class="wheel-picker-wrapper" id="editorstory-day-picker">
        <div class="wheel-selection-box"></div>
        <div class="modern-wheel-scroll" id="editorstory-calendar"></div>
      </div>
    </div>

    <div class="editorstory-card-area" id="editorstory-card-area">
      <div style="display:flex;justify-content:center;padding:var(--space-8);width:100%;">
        <div class="loading-spinner"></div>
      </div>
    </div>

    <div class="page-calendar-view" id="editorstory-cal-view" hidden>
      <div class="calendar-month-nav">
        <button type="button" class="calendar-month-arrow" id="cal-prev-month" aria-label="이전 달">
          <svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" stroke-width="2"><polyline points="15 18 9 12 15 6"/></svg>
        </button>
        <div class="calendar-month-label" id="cal-month-label">—</div>
        <button type="button" class="calendar-month-arrow" id="cal-next-month" aria-label="다음 달">
          <svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" stroke-width="2"><polyline points="9 18 15 12 9 6"/></svg>
        </button>
      </div>
      <div class="calendar-weekdays">
        ${be.map((e,t)=>`<div class="calendar-weekday ${t===0?`sun`:t===6?`sat`:``}">${e}</div>`).join(``)}
      </div>
      <div class="calendar-grid" id="calendar-grid">
        <div class="calendar-grid-loading"><div class="loading-spinner"></div></div>
      </div>
    </div>
  `,t===`calendar`&&(e.querySelector(`#editorstory-day-picker`).hidden=!0,e.querySelector(`#editorstory-card-area`).hidden=!0,e.querySelector(`#editorstory-cal-view`).hidden=!1),Ne(e),e}async function Ne(e){try{let[t,n,r]=await Promise.all([ne(),te(),ie()]),i=new Date(n.publish_date+`T00:00:00`),a=t||[];me([n,...a].map(e=>e?.id).filter(Boolean));let o=e.querySelector(`#editorstory-month-scroll`),s=e.querySelector(`#editorstory-calendar`),c=e.querySelector(`#editorstory-card-area`),l=i.getFullYear(),u=i.getMonth()+1,d=i.getDate(),f=i,p=!0;if(o&&(o.innerHTML=Array.from({length:12},(e,t)=>{let n=t+1;return`<div class="wheel-item${n>u?` disabled`:``}" data-month="${n}">${n}</div>`}).join(``)),s){let e=[];for(let t=1;t<=u;t++){let n=t===u?d:new Date(l,t,0).getDate();for(let r=1;r<=n;r++){let n=String(t).padStart(2,`0`),i=String(r).padStart(2,`0`);e.push(`<div class="wheel-item" data-date="${l}-${n}-${i}" data-month="${t}" data-day="${r}">${r}</div>`)}}s.innerHTML=e.join(``)}function m(e){let t=e.getBoundingClientRect().left+e.offsetWidth/2,n=null,r=1/0;return e.querySelectorAll(`.wheel-item:not(.disabled)`).forEach(e=>{let i=e.getBoundingClientRect().left+e.offsetWidth/2,a=Math.abs(t-i);a<r&&(r=a,n=e)}),n}function h(e){let t=o.querySelector(`.wheel-item.active`);if(t&&parseInt(t.dataset.month,10)===e)return;let n=o.querySelector(`.wheel-item[data-month="${e}"]`);if(!n)return;o.querySelectorAll(`.wheel-item`).forEach(e=>e.classList.remove(`active`)),n.classList.add(`active`);let r=n.offsetLeft-o.offsetWidth/2+n.offsetWidth/2;o.scrollTo({left:r,behavior:`smooth`})}function g(e=!1){let t;if(e?t=s.querySelector(`.wheel-item.active`):(t=m(s),t&&(s.querySelectorAll(`.wheel-item`).forEach(e=>e.classList.remove(`active`)),t.classList.add(`active`))),!t)return;h(parseInt(t.dataset.month,10));let i=t.dataset.date,o=new Date(i+`T00:00:00`);if(f&&f.getTime()===o.getTime()&&!p)return;let l=p?null:o>f?`next`:`prev`;f=o,Pe(c,a.find(e=>e.publish_date===i)||(n.publish_date===i?n:null),o,r,l),p=!1}let _;s.addEventListener(`scroll`,()=>{clearTimeout(_),_=setTimeout(()=>{g(!1)},150)},{passive:!0});let v;o.addEventListener(`scroll`,()=>{T===`card`&&(clearTimeout(v),v=setTimeout(()=>{let e=m(o);if(!e||e.classList.contains(`disabled`))return;let t=s.querySelector(`.wheel-item.active`),n=t?parseInt(t.dataset.month,10):-1;parseInt(e.dataset.month,10)===n?(o.querySelectorAll(`.wheel-item`).forEach(e=>e.classList.remove(`active`)),e.classList.add(`active`)):y(e)},150))},{passive:!0});let y=e=>{if(e.classList.contains(`disabled`))return;let t=parseInt(e.dataset.month,10),n=t===u?String(d).padStart(2,`0`):`01`,r=`${l}-${String(t).padStart(2,`0`)}-${n}`,i=s.querySelector(`.wheel-item[data-date="${r}"]`);if(!i)return;s.querySelectorAll(`.wheel-item`).forEach(e=>e.classList.remove(`active`)),i.classList.add(`active`),o.querySelectorAll(`.wheel-item`).forEach(e=>e.classList.remove(`active`)),e.classList.add(`active`),clearTimeout(_);let a=i.offsetLeft-s.offsetWidth/2+i.offsetWidth/2;s.scrollTo({left:a,behavior:`smooth`});let c=e.offsetLeft-o.offsetWidth/2+e.offsetWidth/2;o.scrollTo({left:c,behavior:`smooth`}),g(!0)},b=e=>{s.querySelectorAll(`.wheel-item`).forEach(e=>e.classList.remove(`active`)),e.classList.add(`active`),clearTimeout(_),g(!0);let t=e.offsetLeft-s.offsetWidth/2+e.offsetWidth/2;s.scrollTo({left:t,behavior:`smooth`})};o.querySelectorAll(`.wheel-item`).forEach(e=>e.addEventListener(`click`,()=>y(e))),s.querySelectorAll(`.wheel-item`).forEach(e=>e.addEventListener(`click`,()=>b(e))),setTimeout(()=>{requestAnimationFrame(()=>{let e=`${l}-${String(u).padStart(2,`0`)}-${String(d).padStart(2,`0`)}`,t=s.querySelector(`.wheel-item[data-date="${e}"]`),n=t?parseInt(t.dataset.month,10):u,r=o.querySelector(`.wheel-item[data-month="${n}"]`);t&&(t.classList.add(`active`),C.hidden||(s.scrollLeft=t.offsetLeft-s.offsetWidth/2+t.offsetWidth/2)),r&&(r.classList.add(`active`),o.scrollLeft=r.offsetLeft-o.offsetWidth/2+r.offsetWidth/2),fe(),C.hidden||g(!0)})},0);let x={mode:`history`,year:l,month:i.getMonth(),historyStories:a,myStories:[],bookmarkedIds:r},S=e.querySelector(`#editorstory-view-toggle`),C=e.querySelector(`#editorstory-day-picker`),w=e.querySelector(`#editorstory-cal-view`),T=sessionStorage.getItem(`ds_session_view`)??(localStorage.getItem(`ds_default_view`)||`card`);T===`calendar`&&Y(e,x,i),S.addEventListener(`click`,()=>{T===`card`?(T=`calendar`,sessionStorage.setItem(`ds_session_view`,`calendar`),S.innerHTML=ke,C.hidden=!0,c.hidden=!0,w.hidden=!1,requestAnimationFrame(()=>{w.classList.add(`view-enter`),Y(e,x,i),setTimeout(()=>w.classList.remove(`view-enter`),250)})):(T=`card`,sessionStorage.setItem(`ds_session_view`,`card`),S.innerHTML=Oe,w.hidden=!0,C.hidden=!1,c.hidden=!1,requestAnimationFrame(()=>{let e=s.querySelector(`.wheel-item.active`);e&&(s.scrollLeft=e.offsetLeft-s.offsetWidth/2+e.offsetWidth/2),g(!0),c.classList.add(`view-enter`),setTimeout(()=>c.classList.remove(`view-enter`),250)}))});let E;o.addEventListener(`scroll`,()=>{T===`calendar`&&(clearTimeout(E),E=setTimeout(()=>{let t=m(o);if(!t)return;let n=parseInt(t.dataset.month,10)-1;n===x.month&&x.year===l||(x.month=n,x.year=l,Y(e,x,i))},150))},{passive:!0}),e.querySelector(`#cal-prev-month`).addEventListener(`click`,()=>{--x.month,x.month<0&&(x.month=11,--x.year);let t=e.querySelector(`#editorstory-year-label`);t&&(t.textContent=x.year),Y(e,x,i),h(x.month+1)}),e.querySelector(`#cal-next-month`).addEventListener(`click`,()=>{if(J(x,i))return;x.month+=1,x.month>11&&(x.month=0,x.year+=1);let t=e.querySelector(`#editorstory-year-label`);t&&(t.textContent=x.year),Y(e,x,i),h(x.month+1)})}catch(t){console.error(`에디터 일화 데이터 로딩 실패:`,t),e.innerHTML=`
      <div class="editorstory-header"><h1 class="editorstory-title">Day Story</h1></div>
      <div class="empty-state">
        <div class="empty-state-title">${l(`common.load_failed_title`)}</div>
        <div class="empty-state-desc" style="color:var(--danger-color);margin-bottom:var(--space-2)">
          ${I(t.message||l(`common.unknown_error`))}
        </div>
        <div class="empty-state-desc">${l(`common.load_failed_desc`)}</div>
        <button class="btn btn-primary" onclick="location.reload()" style="margin-top:var(--space-4)">
          ${l(`common.refresh`)}
        </button>
      </div>
    `}}function Pe(e,t,n,r,i){if(!e)return;t=t?P(t):null;let a=Array.from(e.querySelectorAll(`.flip-container`)),o=a.pop()||null;a.forEach(e=>e.remove());let s=t?new Date(t.publish_date+`T00:00:00`):n,c=s.getMonth()+1,u=s.getDate(),d=n.getFullYear(),f=document.createElement(`div`);if(f.className=`flip-container`,t){let e=t.image_url||``,n=e?`src="${I(e)}"`:``;f.innerHTML=`
      <div class="flipper">
        <div class="front history-card-front">
          <div class="history-card-top">
            <div class="card-top-left">
              <div class="card-year">${I(t.historical_year)}</div>
              <div class="card-date">${c}. ${u}</div>
            </div>
            <div class="card-top-right">
              <div class="card-actions">
                <button class="card-action-btn" aria-label="공유">
                  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                    <circle cx="18" cy="5" r="3"/><circle cx="6" cy="12" r="3"/><circle cx="18" cy="19" r="3"/>
                    <line x1="8.59" y1="13.51" x2="15.42" y2="17.49"/><line x1="15.41" y1="6.51" x2="8.59" y2="10.49"/>
                  </svg>
                </button>
                <button class="card-action-btn" aria-label="보관함">
                  <svg viewBox="0 0 24 24" fill="${t&&r.includes(t.id)?`currentColor`:`none`}" stroke="currentColor" stroke-width="2">
                    <path d="M19 21l-7-5-7 5V5a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2z"/>
                  </svg>
                </button>
              </div>
              <div class="card-meta">
                ${I(t.card_count||``)} ${I(t.country)}<br>
                ${d} / ${String(c).padStart(2,`0`)} / ${String(u).padStart(2,`0`)}
              </div>
            </div>
          </div>
          <div class="history-card-image-wrap">
            <img ${n} alt="${I(t.figure_name)}" loading="eager" decoding="async" width="320" height="400" draggable="false" />
            <div class="card-image-title">${I(t.figure_name)}</div>
          </div>
        </div>
        <div class="back history-card-back">
          <div class="back-title">${I(t.figure_name)}</div>
          <hr class="back-divider" />
          <div class="back-body">
            ${(t.body||``).split(/\n|\\n/).map(e=>e.trim()?`<p>${I(e)}</p>`:`<p><br></p>`).join(``)}
          </div>
          <div class="back-footer">
            <button class="back-editor-btn" type="button" title="에디터 한마디" data-story-id="${I(t.id)}" data-comment="${I(t.editor_comment||``)}" data-editor-name="${I(t.editor&&t.editor.displayName||`DayStory`)}" style="${t.editor_comment&&t.editor_comment.trim()!==``?``:`visibility: hidden; pointer-events: none;`}">
              ${t.editor&&t.editor.photoURL?`<img src="${I(t.editor.photoURL)}" alt="editor" class="back-editor-avatar" loading="lazy" decoding="async" onerror="this.style.display='none';this.nextElementSibling.style.display='flex'" /><span class="back-editor-avatar-fallback" style="display:none">✍️</span>`:`<span class="back-editor-avatar-fallback">✍️</span>`}
            </button>
            <div class="back-date-actions">
              <div class="back-date">${I(t.historical_year)}년 ${c}월 ${u}일</div>
              <button class="card-detail-shortcut-btn" type="button" aria-label="${l(`home.detail_button`)}" title="${l(`home.detail_button`)}">${l(`home.detail_button`)}</button>
            </div>
          </div>
        </div>
      </div>
    `}else{let e=`${[`JAN`,`FEB`,`MAR`,`APR`,`MAY`,`JUN`,`JUL`,`AUG`,`SEP`,`OCT`,`NOV`,`DEC`][s.getMonth()]} ${u}, ${d}`;f.innerHTML=`
      <div class="flipper">
        <div class="front history-card-front empty-story-card">
          <div class="empty-story-day-circle">${u}</div>
          <div class="empty-story-title">${l(`home.empty_card_title`)}</div>
          <div class="empty-story-date">${e}</div>
        </div>
      </div>
    `}if(!i||!o){e.innerHTML=``,e.appendChild(f),Fe(f,t,r);return}o.classList.add(`card-stack-item`,`stack-exit-${i}`),f.classList.add(`card-stack-item`,`stack-enter-${i}`),e.appendChild(f),f.offsetWidth,f.classList.add(`active`);let p=()=>{o.parentNode&&o.remove(),f.classList.remove(`card-stack-item`,`stack-enter-${i}`,`active`),Fe(f,t,r)};f.addEventListener(`transitionend`,p,{once:!0}),setTimeout(()=>{f.classList.contains(`card-stack-item`)&&p()},De)}function Fe(t,n,r){let i=t.querySelector(`.flipper`);if(!i)return;let o=0,s=0,c=!1,u=null,d=!1,f=!1,p=0,m=0,h=0,g=0,_=null,v=(e,t,n=!1)=>{d||i.classList.contains(`is-flipping`)||(o=e,s=t,c=!1,u=null,f=n,m=Date.now(),h=e,g=t)},y=(e,t)=>{if(d)return;let n=e-o,r=t-s;if((Math.abs(n)>15||Math.abs(r)>15)&&(_=null),!u){if(Math.abs(n)<15&&Math.abs(r)<15)return;u=Math.abs(n)>Math.abs(r)?`x`:`y`}if(u===`y`)return;c||=(i.style.transition=`none`,!0);let a=i.classList.contains(`flipped`)?`rotateY(180deg)`:``;i.style.transform=`translateX(${n*.62}px) ${a}`},b=(e,t)=>{if(!c||d)return;d=!0;let n=e-o;if(i.style.transition=`transform 220ms cubic-bezier(0.16, 1, 0.3, 1)`,i.classList.add(`is-flipping`),u===`x`&&Math.abs(n)>64){if(f){i.style.transform=``,setTimeout(()=>{i.style.transition=``,i.classList.remove(`is-flipping`),c=!1,d=!1},220);return}if(Date.now()-Ae>=je){Ae=Date.now();let e=n<0?1:-1,t=document.getElementById(`editorstory-calendar`);if(t){let n=Array.from(t.querySelectorAll(`.wheel-item`)),r=n[n.findIndex(e=>e.classList.contains(`active`))+e];r&&r.click()}}}i.style.transform=``,setTimeout(()=>{i.style.transition=``,i.classList.remove(`is-flipping`),c=!1,d=!1},220)};i.addEventListener(`touchstart`,e=>{p=Date.now();let t=!!e.target.closest(`.back-body`);_=e.target,v(e.touches[0].clientX,e.touches[0].clientY,t)},{passive:!0}),i.addEventListener(`touchmove`,e=>{y(e.touches[0].clientX,e.touches[0].clientY),c&&e.preventDefault()},{passive:!1}),i.addEventListener(`touchend`,e=>{p=Date.now();let t=e.changedTouches[0].clientX,r=e.changedTouches[0].clientY;if(_&&_.closest(`.back-body`)&&!c&&Date.now()-m<=400&&Math.abs(t-h)<=20&&Math.abs(r-g)<=20){if(!n||i.classList.contains(`is-flipping`))return;i.classList.add(`is-flipping`),i.classList.toggle(`flipped`),setTimeout(()=>i.classList.remove(`is-flipping`),400);return}b(t,r)});let x=!1;i.addEventListener(`mousedown`,e=>{Date.now()-p<650||e.target.closest(`button`)||e.target.closest(`.back-body`)||(x=!0,v(e.clientX,e.clientY,!1))}),window._editorStoryMouseMove&&window.removeEventListener(`mousemove`,window._editorStoryMouseMove),window._editorStoryMouseUp&&window.removeEventListener(`mouseup`,window._editorStoryMouseUp),window._editorStoryMouseMove=e=>{x&&y(e.clientX,e.clientY)},window._editorStoryMouseUp=e=>{x&&(x=!1,b(e.clientX,e.clientY))},window.addEventListener(`mousemove`,window._editorStoryMouseMove),window.addEventListener(`mouseup`,window._editorStoryMouseUp);let S=t.querySelector(`.card-detail-shortcut-btn`),C=t.querySelector(`.card-action-btn[aria-label="공유"]`),w=t.querySelector(`.card-action-btn[aria-label="보관함"]`);S&&n&&S.addEventListener(`click`,t=>{t.stopPropagation(),e(`/detail/${n.id}`)}),C&&C.addEventListener(`click`,async t=>{t.stopPropagation();let r=a(`user`);if(r&&r.id===`guest`){F(l(`toast.login_required`),`info`),e(`/login`);return}await M(n,{kind:`history`})}),w&&w.addEventListener(`click`,async t=>{t.stopPropagation();let i=a(`user`);if(i&&i.id===`guest`){F(l(`toast.login_required`),`info`),e(`/login`);return}let o=await N(n.id);if(o.error){F(o.error,`error`);return}if(F(o.bookmarked?l(`toast.bookmark_added`):l(`toast.bookmark_removed`),`success`),w.querySelector(`svg`).style.fill=o.bookmarked?`currentColor`:`none`,o.bookmarked&&!r.includes(n.id))r.push(n.id);else if(!o.bookmarked){let e=r.indexOf(n.id);e>-1&&r.splice(e,1)}}),i.addEventListener(`click`,e=>{if(!n||e.target.closest(`.card-action-btn`)||e.target.closest(`.back-editor-btn`)||e.target.closest(`.card-detail-shortcut-btn`)||c||i.classList.contains(`is-flipping`)||e.pointerType===`touch`&&e.target.closest(`.back-body`))return;let r=t.querySelector(`.editor-comment-bubble`);if(r&&!r.contains(e.target)){r.remove();return}if(n.id&&n.publish_date&&!U(n.id))if(W(n.publish_date)){let e=G(n.id,n.publish_date);e.ok&&!e.alreadyCollected&&F(l(`calendar.collect_success_text`),`success`)}else G(n.id,n.publish_date,{bypass:!0});i.classList.add(`is-flipping`),i.classList.toggle(`flipped`),document.dispatchEvent(new CustomEvent(`ds:card-flipped`)),setTimeout(()=>i.classList.remove(`is-flipping`),Ee)});let T=t.querySelector(`.back-editor-btn`);if(T){let e=null,n=()=>{let n=t.querySelector(`.editor-comment-bubble`);n&&n.remove(),e&&=(e(),null)},r=()=>{e&&e();let r=r=>{let i=t.querySelector(`.editor-comment-bubble`);if(!i){e&&=(e(),null);return}let a=r.target;T.contains(a)||i.contains(a)||n()};document.addEventListener(`click`,r),e=()=>{document.removeEventListener(`click`,r)}};T.addEventListener(`click`,e=>{e&&e.stopPropagation();let i=t.querySelector(`.editor-comment-bubble`);if(i){if(i.contains(e.target))return;n();return}let a=T.dataset.comment,o=T.dataset.editorName||`DayStory`;if(!a)return;let s=document.createElement(`div`);s.className=`editor-comment-bubble`;let c=document.createElement(`span`);c.className=`editor-comment-name`,c.textContent=o,s.appendChild(c),s.appendChild(document.createTextNode(a)),T.appendChild(s),r()})}}c();{let e=document.getElementById(`splash-version`);e&&(e.textContent=`DayStory v${se.version}`)}function Ie(){typeof navigator>`u`||!(`serviceWorker`in navigator)||navigator.serviceWorker.register(`/daystory-image-cache-sw.js`).catch(e=>{console.warn(`Image cache worker registration skipped:`,e)})}Ie(),r(`/login`,()=>k(()=>import(`./login-ClYrVLa-.js`).then(e=>e.renderLogin()),__vite__mapDeps([2,3,4,5,1,6,7,8,9,10]))),r(`/signup`,()=>k(()=>import(`./login-ClYrVLa-.js`).then(e=>e.renderSignup()),__vite__mapDeps([2,3,4,5,1,6,7,8,9,10]))),r(`/editorstory`,()=>Me()),r(`/detail/:id`,e=>k(()=>import(`./detail-DcN1st1f.js`).then(t=>t.renderDetail(e)),__vite__mapDeps([11,12,4,1,7,6,13,9,10,8,14,15]))),r(`/share/:id`,async e=>{let[{recordReceived:t},n]=await Promise.all([k(()=>import(`./receivedCards-wnhZcpR0.js`),__vite__mapDeps([16,14,7,1,6])),k(()=>import(`./detail-DcN1st1f.js`),__vite__mapDeps([11,12,4,1,7,6,13,9,10,8,14,15]))]);return t(e.id),n.renderDetail(e)}),r(`/profile`,()=>k(()=>import(`./profile-CMgOfGhd.js`).then(e=>e.renderProfile()),__vite__mapDeps([17,18,1,19,7,6,20,8,21,12,4,13,9,10,14,15,22]))),r(`/search`,()=>k(()=>import(`./search-BGPtmJYx.js`).then(e=>e.renderSearch()),__vite__mapDeps([23,14,7,1,6,9,15]))),r(`/settings`,()=>k(()=>import(`./settings-C8hWT7px.js`).then(e=>e.renderSettings()),__vite__mapDeps([24,4,3,5,1,6,7,13,9,10,20,8,22]))),r(`/report`,()=>k(()=>import(`./report-pI6Q5s_8.js`).then(e=>e.renderReport()),__vite__mapDeps([25,8,9]))),r(`/editor`,()=>k(()=>import(`./editor-DhIJBcsK.js`).then(e=>e.renderEditor()),__vite__mapDeps([26,18,1,19,7,6,8,14,9,10,15,22]))),r(`/editor/new`,()=>k(()=>import(`./editor-DhIJBcsK.js`).then(e=>e.renderEditorNew()),__vite__mapDeps([26,18,1,19,7,6,8,14,9,10,15,22]))),r(`/mystory`,()=>k(()=>import(`./mystory-vFmZ-LNo.js`).then(e=>e.renderMyStory()),__vite__mapDeps([27,18,1,19,12,4,7,6,13,9,10,20,8,14,15,22]))),r(`/mystory/new`,()=>k(()=>import(`./mystory-vFmZ-LNo.js`).then(e=>e.renderMyStoryNew()),__vite__mapDeps([27,18,1,19,12,4,7,6,13,9,10,20,8,14,15,22]))),r(`/bookmarks`,()=>k(()=>import(`./bookmarks-DuVx0Hi7.js`).then(e=>e.renderBookmarks()),__vite__mapDeps([21,12,4,1,7,6,13,9,10,8,14,15]))),r(`/license`,()=>k(()=>import(`./license-owjVvUdM.js`).then(e=>e.renderLicense()),__vite__mapDeps([28,14,7,1,6]))),r(`/about`,()=>k(()=>import(`./about-CMrlj38O.js`).then(e=>e.renderAbout()),__vite__mapDeps([29,13,9,10,15]))),i(t=>{let n=a(`user`);n||(n={id:`guest`,role:`guest`},o(`user`,n));let r=document.getElementById(`bottom-nav`);if(r){let e=t.startsWith(`/detail/`)||t===`/report`||t===`/login`||t===`/signup`||t===`/license`||t===`/settings`||t===`/about`||t===`/mystory/new`;r.style.display=e?`none`:`flex`}return(t===`/login`||t===`/signup`)&&n&&n.id!==`guest`?(e(`/editorstory`),!1):!0});var X=null;function Le(t){if(!t)return!1;let n;try{n=new URL(t)}catch{return!1}if(n.protocol!==`daystory:`)return!1;let r=[n.hostname,n.pathname.replace(/^\/+/,``)].filter(Boolean).join(`/`);return t===`daystory://letter`||r===`letter`?(e(`/editorstory`),!0):t===`daystory://diary/new`||r===`diary/new`?(e(`/mystory/new?date=${A()}`),!0):!1}function Re(e){if(e){if(!Q){X=e;return}Le(e)}}var Z=!1,ze=!1,Q=!1;function $(){if(Q||!Z||!ze)return;Q=!0;let e=document.getElementById(`splash-screen`),n=document.getElementById(`app-container`);if(n&&(n.style.display=`flex`),e&&(e.classList.add(`hide`),e.addEventListener(`transitionend`,()=>e.remove()),setTimeout(()=>{e.parentNode&&e.remove()},500)),t(),X){let e=X;X=null,Le(e)}}C&&u(C,async t=>{try{if(t){if(o(`user`,{id:t.uid,email:t.email,displayName:t.displayName}),b)try{let e=x(b,`profiles`,t.uid),n=await y(e),r=null,i=[`daystory@test.com`,`dokhubooks@gmail.com`,`ldj729@gmail.com`].includes(t.email);n.exists()?(r=n.data(),i&&r.role!==`editor`&&(r.role=`editor`,await p(e,r,{merge:!0}))):i&&(r={role:`editor`,created_at:new Date().toISOString()},await p(e,r)),r&&(o(`profile`,r),r.theme&&o(`theme`,r.theme),r.font_size&&o(`fontSize`,r.font_size))}catch(e){console.warn(`프로필 로드 (또는 생성) 실패:`,e)}let n=document.getElementById(`bottom-nav`);n&&(n.style.display=`flex`);let r=window.location.hash;(r===`#/login`||r===`#/signup`||!r)&&e(`/editorstory`)}else o(`user`,{id:`guest`,role:`guest`}),o(`profile`,null)}catch(e){console.warn(`인증 상태 변경 중 오류:`,e)}finally{Z=!0,$()}});async function Be(){s(),ze=!0,C||(o(`user`,{id:`guest`,role:`guest`}),Z=!0),$(),setTimeout(()=>{Q||(console.warn(`인증 응답 지연으로 강제 시작합니다.`),Z=!0,$())},5e3)}if(document.readyState===`loading`?document.addEventListener(`DOMContentLoaded`,Be):Be(),O.isNativePlatform()&&(L.addListener(`appUrlOpen`,({url:e})=>{Re(e)}),L.getLaunchUrl().then(e=>Re(e?.url)).catch(e=>console.warn(`위젯 딥링크 확인 실패:`,e)),L.addListener(`appStateChange`,({isActive:e})=>{e&&syncSubscriptionState().catch(()=>{})})),O.isNativePlatform()){let t={"/editorstory":{depth:0,parent:null},"/login":{depth:1,parent:`/editorstory`},"/mystory":{depth:1,parent:`/editorstory`},"/bookmarks":{depth:1,parent:`/editorstory`},"/search":{depth:1,parent:`/editorstory`},"/settings":{depth:1,parent:`/editorstory`},"/detail":{depth:2,parent:null},"/report":{depth:2,parent:null},"/editor":{depth:2,parent:`/settings`},"/editor/new":{depth:3,parent:`/editor`}};function r(e){if(t[e])return t[e];let n=`/`+e.split(`/`).filter(Boolean)[0];return t[n]?t[n]:{depth:1,parent:`/editorstory`}}let i=0;function a(){let e=document.createElement(`div`);e.innerText=`한 번 더 눌러 종료`,Object.assign(e.style,{position:`fixed`,bottom:`100px`,left:`50%`,transform:`translateX(-50%)`,backgroundColor:`rgba(0,0,0,0.7)`,color:`white`,padding:`12px 24px`,borderRadius:`24px`,zIndex:`10000`,fontSize:`var(--text-sm)`,fontFamily:`var(--font-sans)`,pointerEvents:`none`,transition:`opacity 0.3s ease`}),document.body.appendChild(e),setTimeout(()=>{e.style.opacity=`0`,setTimeout(()=>e.remove(),300)},2e3)}L.addListener(`backButton`,()=>{let t=r(n());if(t.depth===0){let e=Date.now();e-i<2e3?L.exitApp():(i=e,a());return}t.parent?e(t.parent):window.history.back()})}export{K as a,he as c,pe as d,L as f,Y as i,ge as l,J as n,_e as o,se as p,Se as r,ye as s,be as t,ve as u};