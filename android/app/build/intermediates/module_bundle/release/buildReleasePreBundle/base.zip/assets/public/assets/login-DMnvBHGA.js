import{a as e}from"./router-7m-s0x-D.js";import{r as t}from"./state-DQ9Huans.js";import{B as n,P as r,R as i,U as a,i as o,m as s,o as c}from"./index.esm-DulCFOgL.js";import{b as l,m as u,n as d,p as f,t as p}from"./firebase-tVkosmAg.js";import{t as m}from"./dist-D9tJEqyA.js";import{t as h}from"./toast-C65VsBgm.js";import{g}from"./index-BvRF4SpI.js";import{t as _}from"./esm-DGgjcM5Q.js";var v=`https://0729.notion.site/336c0180451480a4b0a8c60dba754daf?source=copy_link`,y=new o,b=new c(`apple.com`);b.addScope(`email`),b.addScope(`name`);var x=[`daystory@test.com`,`dokhubooks@gmail.com`,`ldj729@gmail.com`],S=`<svg viewBox="0 0 24 24" width="20" height="20"><path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"/><path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"/><path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z"/><path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z"/></svg>`,C=`<svg viewBox="0 0 24 24" width="20" height="20" fill="currentColor"><path d="M16.365 1.43c0 1.14-.493 2.27-1.177 3.08-.744.9-1.99 1.57-2.987 1.49-.12-1.1.42-2.24 1.054-2.99.724-.85 1.997-1.51 3.11-1.58zM20.5 17.36c-.39.9-.57 1.31-1.07 2.11-.7 1.12-1.69 2.51-2.91 2.52-1.09.01-1.37-.71-2.85-.7-1.48.01-1.79.71-2.88.7-1.22-.01-2.16-1.27-2.86-2.39-1.95-3.12-2.16-6.79-.95-8.74.86-1.39 2.21-2.21 3.48-2.21 1.29 0 2.1.71 3.17.71 1.04 0 1.67-.71 3.16-.71 1.13 0 2.33.62 3.18 1.69-2.79 1.53-2.34 5.51.53 7.02z"/></svg>`;function w(e,t){let n=t?.email||``;return e&&e.nickname||t?.displayName||(n?n.split(`@`)[0]:``)||`사용자`}async function T(n){t(`user`,{id:n.uid,email:n.email});let r=null,i=!1;if(d)try{let e=f(d,`profiles`,n.uid),a=await u(e);i=a.exists(),r=i?a.data():{created_at:new Date().toISOString()},x.includes(n.email)&&r.role!==`editor`?(r.role=`editor`,await l(e,r,{merge:!0})):i||await l(e,r),t(`profile`,r)}catch(e){console.warn(`소셜 로그인 - 프로필 처리 실패:`,e)}return document.getElementById(`bottom-nav`).style.display=`flex`,e(`/editorstory`),{isExisting:i,nickname:w(r,n)}}async function E(e){let t=e?.currentTarget,n=t?.querySelector(`span`),r=n?.textContent;if(t&&(t.disabled=!0,n&&(n.textContent=`로그인 중...`)),!p)return t&&(t.disabled=!1,n&&(n.textContent=r)),h(`Firebase가 설정되지 않았습니다`,`error`);try{let e=null;if(m.isNativePlatform()){let t=await _.signInWithGoogle({skipNativeAuth:!0,useCredentialManager:!1}),n=t.credential?.idToken;if(!n)throw Error(`Google 인증 토큰을 받지 못했습니다.`);e=(await i(p,o.credential(n,t.credential?.accessToken))).user}else e=(await a(p,y)).user;if(!e)throw Error(`사용자 정보를 가져올 수 없습니다.`);let{isExisting:t,nickname:n}=await T(e);h(t?`${n}님으로 로그인`:`구글 로그인 성공!`,`success`)}catch(e){let t=(e.message||``).toLowerCase();console.error(`[GoogleSignIn] 실패:`,e.message,e.code),t.includes(`sign_in_cancelled`)||t.includes(`12501`)||t.includes(`cancelled`)||e.code===`auth/popup-closed-by-user`||(t.includes(`10:`)||t.includes(`developer_error`)||t.includes(`sign_in_failed`)?h(`Google 로그인에 일시적 오류가 발생했습니다. 잠시 후 다시 시도해주세요.`,`error`):t.includes(`no credentials available`)?h(`기기 설정 > 계정에서 Google 계정을 추가한 뒤 다시 시도하세요.`,`error`):h(e.message||`Google 로그인 실패`,`error`))}finally{t&&(t.disabled=!1,n&&(n.textContent=r))}}async function D(){if(!p)return h(`Firebase가 설정되지 않았습니다`,`error`);try{let e=null;if(m.isNativePlatform()){let{idToken:t,nonce:n}=(await _.signInWithApple({skipNativeAuth:!0})).credential||{};if(!t)throw Error(`Apple 인증 토큰을 받지 못했습니다.`);e=(await i(p,new c(`apple.com`).credential({idToken:t,rawNonce:n}))).user}else e=(await a(p,b)).user;if(!e)throw Error(`사용자 정보를 가져올 수 없습니다.`);let{isExisting:t,nickname:n}=await T(e);h(t?`${n}님으로 로그인`:`Apple 로그인 성공!`,`success`)}catch(e){h(e.message||`Apple 로그인 실패`,`error`)}}function O(){let i=document.createElement(`div`);return i.className=`auth-page page`,i.innerHTML=`
    <!-- 로고 영역 -->
    <div class="auth-logo" style="margin-bottom: var(--space-6);">
      <h1 class="auth-logo-title" style="margin: 0;">DayStory</h1>
      <p class="auth-logo-subtitle" style="margin-top: 5px;">매일 만나는 역사 카드</p>
    </div>

    <!-- 로그인 폼 -->
    <form class="auth-form" id="login-form">
      <div class="input-group">
        <label class="input-label" for="login-email">이메일</label>
        <input class="input-field" type="email" id="login-email"
               placeholder="email@example.com" autocomplete="email" required />
      </div>
      <div class="input-group">
        <label class="input-label" for="login-password">비밀번호</label>
        <input class="input-field" type="password" id="login-password"
               placeholder="비밀번호를 입력하세요" autocomplete="current-password" required />
      </div>
      <button type="submit" class="btn btn-primary btn-full btn-large" id="login-submit">
        <span id="login-btn-text">로그인</span>
      </button>
    </form>

    <!-- 구분선 -->
    <div class="auth-divider">또는</div>

    <!-- Apple 소셜 로그인 (App Store 4.8 — Google과 동등 이상 위치) -->
    <button class="auth-social-btn auth-social-btn--apple" id="apple-login-btn">
      ${C}
      <span>Apple로 계속하기</span>
    </button>

    <!-- Google 소셜 로그인 -->
    <button class="auth-social-btn" id="google-login-btn" style="margin-top: var(--space-3);">
      ${S}
      <span>Google로 계속하기</span>
    </button>

    <!-- 하단 링크 -->
    <div class="auth-footer">
      <p>계정이 없으신가요? <button id="goto-signup">회원가입</button></p>
      <p style="margin-top:var(--space-2)">

    <!-- 버전 정보 -->
    <div class="auth-version-block">
      <div class="settings-privacy-link">
        <a href="${v}" target="_blank" rel="noopener noreferrer">개인정보처리방침</a>
      </div>
      <div class="settings-version">DayStory v${g.version}</div>
      <div class="settings-version">2026 DOKHU Team</div>
    </div>
  `,setTimeout(()=>{document.getElementById(`login-form`)?.addEventListener(`submit`,async r=>{r.preventDefault();let i=document.getElementById(`login-email`).value.trim(),a=document.getElementById(`login-password`).value;if(!i||!a)return h(`이메일과 비밀번호를 입력하세요`,`warning`);if(!p)return h(`Firebase가 설정되지 않았습니다`,`error`);let o=document.getElementById(`login-btn-text`);o.textContent=`로그인 중...`;try{let r=(await n(p,i,a)).user;t(`user`,{id:r.uid,email:r.email});let o=[`daystory@test.com`,`dokhubooks@gmail.com`,`ldj729@gmail.com`].includes(r.email),s=null;if(d){let e=f(d,`profiles`,r.uid),n=await u(e);s=n.exists()?n.data():{created_at:new Date().toISOString()},o&&s.role!==`editor`?(s.role=`editor`,await l(e,s,{merge:!0})):n.exists()||await l(e,s),t(`profile`,s)}h(`${w(s,r)}님으로 로그인`,`success`),document.getElementById(`bottom-nav`).style.display=`flex`,e(`/editorstory`)}catch(e){h(e.message||`로그인 실패`,`error`),o.textContent=`로그인`}}),document.getElementById(`apple-login-btn`)?.addEventListener(`click`,D),document.getElementById(`google-login-btn`)?.addEventListener(`click`,E),document.getElementById(`goto-signup`)?.addEventListener(`click`,()=>e(`/signup`)),document.getElementById(`forgot-pw`)?.addEventListener(`click`,async()=>{let e=document.getElementById(`login-email`).value.trim();if(!e)return h(`이메일을 먼저 입력하세요`,`warning`);if(!p)return h(`Firebase가 설정되지 않았습니다`,`error`);try{await r(p,e),h(`비밀번호 재설정 이메일이 발송되었습니다`,`success`)}catch(e){h(e.message||`이메일 발송 실패`,`error`)}})},0),i}function k(){let n=document.createElement(`div`);return n.className=`auth-page page`,n.innerHTML=`
    <!-- 닫기 버튼 -->
    <button id="close-signup-btn" class="close-auth-btn" aria-label="닫기">
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
        <path d="M18 6L6 18M6 6l12 12"/>
      </svg>
    </button>

    <!-- 로고 영역 -->
    <div class="auth-logo" style="margin-bottom: var(--space-6);">
      <h1 class="auth-logo-title" style="margin: 0;">회원가입</h1>
      <p class="auth-logo-subtitle" style="margin-top: 5px;">매일 만나는 역사 카드</p>
    </div>

    <!-- 회원가입 폼 -->
    <form class="auth-form" id="signup-form">
      <div class="input-group">
        <label class="input-label" for="signup-email">이메일</label>
        <input class="input-field" type="email" id="signup-email"
               placeholder="email@example.com" autocomplete="email" required />
      </div>
      <div class="input-group">
        <label class="input-label" for="signup-password">비밀번호</label>
        <input class="input-field" type="password" id="signup-password"
               placeholder="8자 이상" autocomplete="new-password" minlength="8" required />
      </div>
      <div class="input-group">
        <label class="input-label" for="signup-password2">비밀번호 확인</label>
        <input class="input-field" type="password" id="signup-password2"
               placeholder="비밀번호를 한번 더 입력하세요" autocomplete="new-password" required />
      </div>

      <!-- 이용약관 동의 -->
      <label style="display:flex;align-items:flex-start;gap:var(--space-2);font-size:var(--text-sm);color:var(--color-text-secondary);cursor:pointer;">
        <input type="checkbox" id="agree-terms" required style="margin-top:3px;" />
        <span>이용약관 및 개인정보 처리방침에 동의합니다</span>
      </label>

      <button type="submit" class="btn btn-primary btn-full btn-large" id="signup-submit">
        <span id="signup-btn-text">가입하기</span>
      </button>
    </form>

    <!-- 구분선 -->
    <div class="auth-divider">또는 소셜 계정으로 가입</div>

    <!-- Apple 소셜 (App Store 4.8 — 더 상단 위치) -->
    <button class="auth-social-btn auth-social-btn--apple" id="apple-signup-btn">
      ${C}
      <span>Apple로 계속하기</span>
    </button>

    <!-- Google 소셜 -->
    <button class="auth-social-btn" id="google-signup-btn" style="margin-top: var(--space-3);">
      ${S}
      <span>Google로 계속하기</span>
    </button>

    <!-- 하단 링크 -->
    <div class="auth-footer">
      <p>이미 계정이 있으신가요? <button id="goto-login">로그인</button></p>
    </div>

    <!-- 버전 정보 -->
    <div class="auth-version-block">
      <div class="settings-privacy-link">
        <a href="${v}" target="_blank" rel="noopener noreferrer">개인정보처리방침</a>
      </div>
      <div class="settings-version">DayStory v${g.version}</div>
      <div class="settings-version">2026 DOKHU Team</div>
    </div>
  `,setTimeout(()=>{document.getElementById(`close-signup-btn`)?.addEventListener(`click`,()=>{document.getElementById(`bottom-nav`).style.display=`flex`,e(`/editorstory`)}),document.getElementById(`signup-form`)?.addEventListener(`submit`,async n=>{n.preventDefault();let r=document.getElementById(`signup-email`).value.trim(),i=document.getElementById(`signup-password`).value;if(i!==document.getElementById(`signup-password2`).value)return h(`비밀번호가 일치하지 않습니다`,`error`);if(!p)return h(`Firebase가 설정되지 않았습니다`,`error`);let a=document.getElementById(`signup-btn-text`);a.textContent=`가입 중...`;try{let n=(await s(p,r,i)).user;t(`user`,{id:n.uid,email:n.email});let a=[`daystory@test.com`,`dokhubooks@gmail.com`,`ldj729@gmail.com`].includes(n.email);if(d){let e=f(d,`profiles`,n.uid),r=await u(e),i=r.exists()?r.data():{created_at:new Date().toISOString()};a&&i.role!==`editor`?(i.role=`editor`,await l(e,i,{merge:!0})):r.exists()||await l(e,i),t(`profile`,i)}h(`회원가입 완료!`,`success`),document.getElementById(`bottom-nav`).style.display=`flex`,e(`/editorstory`)}catch(e){h(e.message||`회원가입 실패`,`error`),a.textContent=`가입하기`}}),document.getElementById(`goto-login`)?.addEventListener(`click`,()=>e(`/login`)),document.getElementById(`apple-signup-btn`)?.addEventListener(`click`,D),document.getElementById(`google-signup-btn`)?.addEventListener(`click`,E)},0),n}export{O as renderLogin,k as renderSignup};