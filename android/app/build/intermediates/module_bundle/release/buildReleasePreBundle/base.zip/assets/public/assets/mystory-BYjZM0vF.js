import{a as e,n as t,o as n,t as r}from"./cropper-RFou76ed.js";import{a as i,r as a}from"./router-hybKseu2.js";import{n as o}from"./state-8PRbPWwW.js";import{a as s,c,r as l,t as u}from"./firebase-DGvE0Cu9.js";import{t as d}from"./dist-N3LOKtlT.js";import{l as f}from"./stories-DlcbpjXX.js";import{r as p}from"./storyI18n-DjbifhmL.js";import{t as m}from"./toast-C-m3kd2X.js";import{t as h}from"./sanitize-DlMVmTsh.js";import{a as g,c as _,d as v,f as y,i as b,l as x,m as S,n as C,o as w,p as T,s as E,t as D,u as O}from"./index-b529ZtNJ.js";import{n as k,t as A}from"./pageHeader-CzG3S3Fi.js";var j=n(r(),1),M=4/5,N=`<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M2 7v10"/><path d="M6 5v14"/><rect width="12" height="18" x="10" y="3" rx="2"/></svg>`,P=`<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M8 2v4"/><path d="M16 2v4"/><rect width="18" height="18" x="3" y="4" rx="2"/><path d="M3 10h18"/><path d="M8 14h.01"/><path d="M12 14h.01"/><path d="M16 14h.01"/><path d="M8 18h.01"/><path d="M12 18h.01"/><path d="M16 18h.01"/></svg>`,F=0,I=1500,L=560;function R(e={}){let t=o(`profile`)||{},n=o(`user`)||{},r=typeof n.email==`string`?n.email.split(`@`)[0]:``;return[e.author_nickname,e.authorNickname,e.author?.nickname,e.author?.displayName,t.nickname,n.displayName,r].map(e=>typeof e==`string`?e.trim():``).find(Boolean)||`사용자`}function z(){let e=document.createElement(`div`);e.className=`mystory-page page`;let t=sessionStorage.getItem(`ds_session_view`)??(localStorage.getItem(`ds_default_view`)||`card`);return e.innerHTML=`
    <!-- 휠 피커 스타일 날짜 선택기 -->
    <div class="wheel-pickers-container">
      <div class="wheel-year-label" id="mystory-year-label">${new Date().getFullYear()}</div>
      <!-- 월 피커 -->
      <div class="wheel-picker-wrapper">
        <div class="wheel-selection-box"></div>
        <div class="modern-wheel-scroll" id="mystory-month-scroll"></div>
        <button type="button" class="view-toggle-btn" id="mystory-view-toggle" aria-label="보기 방식 변경">${t===`calendar`?P:N}</button>
      </div>
      <!-- 일 피커 -->
      <div class="wheel-picker-wrapper" id="mystory-day-picker">
        <div class="wheel-selection-box"></div>
        <div class="modern-wheel-scroll" id="mystory-calendar"></div>
      </div>
    </div>

    <!-- 카드 렌더링 영역 (editorstory.js와 동일한 구조) -->
    <div class="editorstory-card-area" id="mystory-card-area">
      <div style="display:flex;justify-content:center;padding:var(--space-8);width:100%;">
        <div class="loading-spinner"></div>
      </div>
    </div>

    <div class="page-calendar-view" id="mystory-cal-view" hidden>
      <div class="calendar-month-nav">
        <button type="button" class="calendar-month-arrow" id="cal-prev-month" aria-label="이전 달">
          <svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" stroke-width="2"><polyline points="15 18 9 12 15 6"/></svg>
        </button>
        <div class="calendar-month-label" id="cal-month-label">—</div>
        <button type="button" class="calendar-month-arrow" id="cal-next-month" aria-label="다음 달">
          <svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" stroke-width="2"><polyline points="9 18 15 12 9 6"/></svg>
        </button>
      </div>
      <div class="calendar-weekdays">
        ${D.map((e,t)=>`<div class="calendar-weekday ${t===0?`sun`:t===6?`sat`:``}">${e}</div>`).join(``)}
      </div>
      <div class="calendar-grid" id="calendar-grid">
        <div class="calendar-grid-loading"><div class="loading-spinner"></div></div>
      </div>
    </div>
  `,t===`calendar`&&(e.querySelector(`#mystory-day-picker`).hidden=!0,e.querySelector(`#mystory-card-area`).hidden=!0,e.querySelector(`#mystory-cal-view`).hidden=!1),B(e),e}async function B(e){F=0;try{let t=o(`user`),n=await O(u?.currentUser?.uid||t?.id);T(n);let r=a(),i=new Date,s=new Date(i.getTime()-i.getTimezoneOffset()*6e4).toISOString().split(`T`)[0],[c,l,d]=s.split(`-`),f=new Date(parseInt(c),parseInt(l)-1,parseInt(d)),p=r.date||s,[m,h,g]=p.split(`-`),_=new Date(parseInt(m),parseInt(h)-1,parseInt(g)),v=_,y=e.querySelector(`#mystory-month-scroll`),x=e.querySelector(`#mystory-calendar`),S=e.querySelector(`#mystory-card-area`),w=f.getFullYear(),E=f.getMonth()+1,D=f.getDate();if(y&&(y.innerHTML=Array.from({length:12},(e,t)=>{let n=t+1;return`<div class="wheel-item${n>E?` disabled`:``}" data-month="${n}">${n}</div>`}).join(``)),x){let e=[];for(let t=1;t<=E;t++){let n=t===E?D:new Date(w,t,0).getDate();for(let r=1;r<=n;r++){let n=String(t).padStart(2,`0`),i=String(r).padStart(2,`0`);e.push(`<div class="wheel-item" data-date="${w}-${n}-${i}" data-month="${t}" data-day="${r}">${r}</div>`)}}x.innerHTML=e.join(``)}function k(e){let t=e.getBoundingClientRect().left+e.offsetWidth/2,n=null,r=1/0;return e.querySelectorAll(`.wheel-item:not(.disabled)`).forEach(e=>{let i=e.getBoundingClientRect().left+e.offsetWidth/2,a=Math.abs(t-i);a<r&&(r=a,n=e)}),n}function A(e){let t=y.querySelector(`.wheel-item.active`);if(t&&parseInt(t.dataset.month,10)===e)return;let n=y.querySelector(`.wheel-item[data-month="${e}"]`);if(!n)return;y.querySelectorAll(`.wheel-item`).forEach(e=>e.classList.remove(`active`)),n.classList.add(`active`);let r=n.offsetLeft-y.offsetWidth/2+n.offsetWidth/2;y.scrollTo({left:r,behavior:`smooth`})}function j(e=!1){let t;if(e?t=x.querySelector(`.wheel-item.active`):(t=k(x),t&&(x.querySelectorAll(`.wheel-item`).forEach(e=>e.classList.remove(`active`)),t.classList.add(`active`))),!t)return;A(parseInt(t.dataset.month,10));let r=t.dataset.date,i=new Date(w,parseInt(t.dataset.month,10)-1,parseInt(t.dataset.day,10));if(v&&v.getTime()===i.getTime())return;let a=n.find(e=>e.publish_date===r),o=i>v?`next`:`prev`;v=i,V(S,a||null,i,r,o,n)}let M;x.addEventListener(`scroll`,()=>{clearTimeout(M),M=setTimeout(()=>{j(!1)},150)},{passive:!0});let F;y.addEventListener(`scroll`,()=>{U===`card`&&(clearTimeout(F),F=setTimeout(()=>{let e=k(y);if(!e||e.classList.contains(`disabled`))return;let t=x.querySelector(`.wheel-item.active`),n=t?parseInt(t.dataset.month,10):-1;parseInt(e.dataset.month,10)===n?(y.querySelectorAll(`.wheel-item`).forEach(e=>e.classList.remove(`active`)),e.classList.add(`active`)):I(e)},150))},{passive:!0});let I=e=>{if(e.classList.contains(`disabled`))return;let t=parseInt(e.dataset.month,10),n=t===E?String(D).padStart(2,`0`):`01`,r=`${w}-${String(t).padStart(2,`0`)}-${n}`,i=x.querySelector(`.wheel-item[data-date="${r}"]`);if(!i)return;x.querySelectorAll(`.wheel-item`).forEach(e=>e.classList.remove(`active`)),i.classList.add(`active`),y.querySelectorAll(`.wheel-item`).forEach(e=>e.classList.remove(`active`)),e.classList.add(`active`),clearTimeout(M);let a=i.offsetLeft-x.offsetWidth/2+i.offsetWidth/2;x.scrollTo({left:a,behavior:`smooth`});let o=e.offsetLeft-y.offsetWidth/2+e.offsetWidth/2;y.scrollTo({left:o,behavior:`smooth`}),j(!0)},L=e=>{x.querySelectorAll(`.wheel-item`).forEach(e=>e.classList.remove(`active`)),e.classList.add(`active`),clearTimeout(M),j(!0);let t=e.offsetLeft-x.offsetWidth/2+e.offsetWidth/2;x.scrollTo({left:t,behavior:`smooth`})};y.querySelectorAll(`.wheel-item`).forEach(e=>e.addEventListener(`click`,()=>I(e))),x.querySelectorAll(`.wheel-item`).forEach(e=>e.addEventListener(`click`,()=>L(e))),setTimeout(()=>{requestAnimationFrame(()=>{let e=p,t=x.querySelector(`.wheel-item[data-date="${e}"]`),n=_.getMonth()+1,r=y.querySelector(`.wheel-item[data-month="${n}"]`);t&&(t.classList.add(`active`),B.hidden||(x.scrollLeft=t.offsetLeft-x.offsetWidth/2+t.offsetWidth/2)),r&&(r.classList.add(`active`),y.scrollLeft=r.offsetLeft-y.offsetWidth/2+r.offsetWidth/2)})},0),V(S,n.find(e=>e.publish_date===p)||null,_,p,null,n);let R={mode:`mine`,year:w,month:f.getMonth(),historyStories:[],myStories:n,bookmarkedIds:[]},z=e.querySelector(`#mystory-view-toggle`),B=e.querySelector(`#mystory-day-picker`),H=e.querySelector(`#mystory-cal-view`),U=sessionStorage.getItem(`ds_session_view`)??(localStorage.getItem(`ds_default_view`)||`card`);U===`calendar`&&b(e,R,f),z.addEventListener(`click`,()=>{U===`card`?(U=`calendar`,sessionStorage.setItem(`ds_session_view`,`calendar`),z.innerHTML=P,B.hidden=!0,S.hidden=!0,H.hidden=!1,requestAnimationFrame(()=>{H.classList.add(`view-enter`),b(e,R,f),setTimeout(()=>H.classList.remove(`view-enter`),250)})):(U=`card`,sessionStorage.setItem(`ds_session_view`,`card`),z.innerHTML=N,H.hidden=!0,B.hidden=!1,S.hidden=!1,requestAnimationFrame(()=>{let e=x.querySelector(`.wheel-item.active`);e&&(x.scrollLeft=e.offsetLeft-x.offsetWidth/2+e.offsetWidth/2),j(!0),S.classList.add(`view-enter`),setTimeout(()=>S.classList.remove(`view-enter`),250)}))});let W;y.addEventListener(`scroll`,()=>{U===`calendar`&&(clearTimeout(W),W=setTimeout(()=>{let t=k(y);if(!t)return;let n=parseInt(t.dataset.month,10)-1;n===R.month&&R.year===w||(R.month=n,R.year=w,b(e,R,f))},150))},{passive:!0}),e.querySelector(`#cal-prev-month`).addEventListener(`click`,()=>{--R.month,R.month<0&&(R.month=11,--R.year);let t=e.querySelector(`#mystory-year-label`);t&&(t.textContent=R.year),b(e,R,f),A(R.month+1)}),e.querySelector(`#cal-next-month`).addEventListener(`click`,()=>{if(C(R,f))return;R.month+=1,R.month>11&&(R.month=0,R.year+=1);let t=e.querySelector(`#mystory-year-label`);t&&(t.textContent=R.year),b(e,R,f),A(R.month+1)})}catch(t){console.error(`loadMyStoryData 오류:`,t?.message||t?.code||JSON.stringify(t)),e.innerHTML=`<div class="empty-state"><div class="empty-state-title">오류가 발생했습니다</div></div>`}}function V(e,t,n,r,i=null,a){if(!e)return;let o=Array.from(e.querySelectorAll(`.flip-container`)),s=o.pop()||null;o.forEach(e=>e.remove());let c=n.getMonth()+1,l=n.getDate(),u=n.getFullYear(),d=document.createElement(`div`);if(d.className=`flip-container`,d.id=`card-${Date.now()}`,!t)d.innerHTML=`
      <div class="flipper mystory-flipper">
        <div class="front history-card-front empty-story-card">
          <div class="empty-story-day-circle">${l}</div>
          <div class="empty-story-title">이 날의 기록이 없습니다.</div>
          <div class="empty-story-date">${`${[`JAN`,`FEB`,`MAR`,`APR`,`MAY`,`JUN`,`JUL`,`AUG`,`SEP`,`OCT`,`NOV`,`DEC`][n.getMonth()]} ${l}, ${u}`}</div>
          
          <button class="btn btn-primary mystory-write-btn" data-date="${r}">
            + 나의 일화 쓰기
          </button>
        </div>
      </div>
    `;else{let[e,n,i]=String(t.publish_date||r).split(`-`),a=parseInt(e,10)||u,o=parseInt(n,10)||c,s=parseInt(i,10)||l,f=t.image_url||``,p=f?`src="${h(f)}"`:``,m=(t.body||``).split(/\n|\\n/).map(e=>e.trim()?`<p>${h(e)}</p>`:`<p><br></p>`).join(``),g=R(t);d.innerHTML=`
      <div class="flipper mystory-flipper">
        <!-- 앞면 -->
        <div class="front history-card-front">
          <div class="history-card-top">
            <div class="card-top-left">
              <div class="card-year mystory-card-year">${a}</div>
              <div class="card-date">${o}. ${s}</div>
            </div>
            <div class="card-top-right">
              <div class="card-actions">
                <button class="card-action-btn share-my-story-btn" data-id="${h(t.id)}" aria-label="공유">
                  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                    <circle cx="18" cy="5" r="3"/><circle cx="6" cy="12" r="3"/><circle cx="18" cy="19" r="3"/>
                    <line x1="8.59" y1="13.51" x2="15.42" y2="17.49"/><line x1="15.41" y1="6.51" x2="8.59" y2="10.49"/>
                  </svg>
                </button>
                <button class="card-action-btn edit-my-story-btn" data-id="${h(t.id)}" aria-label="수정">
                  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                    <path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"></path>
                    <path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"></path>
                  </svg>
                </button>
              </div>
              <div class="card-meta">${h(g)}</div>
            </div>
          </div>
          <div class="history-card-image-wrap">
            <img ${p} alt="${h(t.title)}" loading="eager" decoding="async" width="320" height="400" draggable="false" />
            <div class="card-image-title">${h(t.title)}</div>
          </div>
        </div>
        <!-- 뒷면 -->
        <div class="back history-card-back">
          <div class="back-title">${h(t.title)}</div>
          <hr class="back-divider" />
          <div class="back-body">${m}</div>
          <div class="back-footer">
            <div class="back-date">${a}년 ${o}월 ${s}일</div>
          </div>
        </div>
      </div>
    `}if(!i||!s){e.innerHTML=``,e.appendChild(d),H(d,t,n,a);return}s.classList.add(`card-stack-item`,`stack-exit-${i}`),d.classList.add(`card-stack-item`,`stack-enter-${i}`),e.appendChild(d),d.offsetWidth,d.classList.add(`active`);let f=()=>{s.parentNode&&s.remove(),d.classList.remove(`card-stack-item`,`stack-enter-${i}`,`active`),H(d,t,n,a)};d.addEventListener(`transitionend`,f,{once:!0}),setTimeout(()=>{d.classList.contains(`card-stack-item`)&&f()},L)}function H(e,t,n,r){let a=e.querySelector(`.flipper`);if(!a)return;let s=e.querySelector(`.mystory-write-btn`),c=e.querySelector(`.share-my-story-btn`),l=e.querySelector(`.edit-my-story-btn`),d=()=>{let e=o(`user`)||{};return u?.currentUser?.uid||e.id?!0:(m(`로그인이 필요한 서비스입니다.`,`error`),location.hash=`#/login`,!1)};s&&s.addEventListener(`click`,e=>{e.stopPropagation(),d()&&i(`/mystory/new?date=`+s.dataset.date)}),c&&t&&c.addEventListener(`click`,async e=>{e.stopPropagation(),d()&&await p(t,{kind:`mystory`,includeImage:!1})}),l&&l.addEventListener(`click`,e=>{e.stopPropagation(),d()&&i(`/mystory/new?edit=`+l.dataset.id)});let f=0,h=0,g=!1,_=null,v=!1,y=!1,b=0,x=0,S=0,C=0,w=null,T=(e,t,n=!1)=>{v||a.classList.contains(`is-flipping`)||(f=e,h=t,g=!1,_=null,y=n,x=Date.now(),S=e,C=t)},E=async(e,t,n=!1)=>{if(v)return;let r=e-f,i=t-h;if((Math.abs(r)>15||Math.abs(i)>15)&&(w=null),!_){if(Math.abs(r)<15&&Math.abs(i)<15)return;_=Math.abs(r)>Math.abs(i)?`x`:`y`}if(_===`y`)return;g||=(a.style.transition=`none`,!0);let o=a.classList.contains(`flipped`)?`rotateY(180deg)`:``;if(_===`x`){let e=r*.62;a.style.transform=`translateX(${e}px) ${o}`}},D=async(e,t)=>{if(!g||v)return;v=!0;let n=e-f;if(a.style.transition=`transform 220ms cubic-bezier(0.16, 1, 0.3, 1)`,a.classList.add(`is-flipping`),_===`x`&&Math.abs(n)>64){if(y){a.style.transform=``,setTimeout(()=>{a.style.transition=``,a.classList.remove(`is-flipping`),g=!1,v=!1},220);return}if(Date.now()-F>=I){F=Date.now();let e=n<0?1:-1,t=document.getElementById(`mystory-calendar`);if(t){let n=Array.from(t.querySelectorAll(`.wheel-item`)),r=n[n.findIndex(e=>e.classList.contains(`active`))+e];r&&r.click()}}}a.style.transform=``,setTimeout(()=>{a.style.transition=``,a.classList.remove(`is-flipping`),g=!1,v=!1},220)};a.addEventListener(`touchstart`,e=>{b=Date.now();let t=!!e.target.closest(`.back-body`);w=e.target,T(e.touches[0].clientX,e.touches[0].clientY,t)},{passive:!0}),a.addEventListener(`touchmove`,e=>{E(e.touches[0].clientX,e.touches[0].clientY,!0),g&&e.preventDefault()},{passive:!1}),a.addEventListener(`touchend`,async e=>{b=Date.now();let n=e.changedTouches[0].clientX,r=e.changedTouches[0].clientY;if(w&&w.closest(`.back-body`)&&!g){let e=Date.now()-x,i=Math.abs(n-S),o=Math.abs(r-C);if(e<=400&&i<=20&&o<=20){if(!t||a.classList.contains(`is-flipping`))return;a.classList.add(`is-flipping`),a.classList.toggle(`flipped`),setTimeout(()=>{a.classList.remove(`is-flipping`)},400);return}}D(n,r)});let O=!1;a.addEventListener(`mousedown`,e=>{if(Date.now()-b<650||e.target.closest(`button`))return;let t=!!e.target.closest(`.back-body`);t||(O=!0,T(e.clientX,e.clientY,t))}),window._myStoryMouseMove&&window.removeEventListener(`mousemove`,window._myStoryMouseMove),window._myStoryMouseUp&&window.removeEventListener(`mouseup`,window._myStoryMouseUp),window._myStoryMouseMove=e=>{O&&E(e.clientX,e.clientY)},window._myStoryMouseUp=e=>{O&&(O=!1,D(e.clientX,e.clientY))},window.addEventListener(`mousemove`,window._myStoryMouseMove),window.addEventListener(`mouseup`,window._myStoryMouseUp),a.addEventListener(`click`,async e=>{t&&(e.target.closest(`button`)||g||e.pointerType===`touch`&&e.target.closest(`.back-body`)||a.classList.contains(`is-flipping`)||(a.classList.add(`is-flipping`),a.classList.toggle(`flipped`),setTimeout(()=>{a.classList.remove(`is-flipping`)},400)))})}function U(){let n=document.createElement(`div`);n.className=`mystory-new-page page`;let r=o(`user`)||{},p=u?.currentUser?.uid||r.id;if(!p)return n.innerHTML=`
      ${k({title:`권한 없음`,backLabel:`뒤로`})}
      <div class="empty-state" style="padding-top: 100px;">
        <div class="empty-state-title">로그인이 필요합니다</div>
        <div class="empty-state-desc">나의 일화를 작성하려면 로그인해주세요.</div>
        <button class="btn btn-primary" style="margin-top: 16px;" id="ms-no-auth-back">뒤로 가기</button>
      </div>
    `,setTimeout(()=>{A(n,()=>history.back()),document.getElementById(`ms-no-auth-back`)?.addEventListener(`click`,()=>history.back())},0),n;let h=r,b=a(),C=b.edit||null,D=b.date||new Date().toISOString().split(`T`)[0],N=null;return n.innerHTML=`
    ${k({title:C?`나의 일화 수정`:`나의 일화 쓰기`,backLabel:`뒤로`})}

    <div class="editor-form-section section mystory-form-section">
      <form id="mystory-form" class="story-form">
        <!-- 1. 날짜 -->
        <div class="input-group">
          <label class="input-label">날짜 *</label>
          <input class="input-field" type="date" id="ms-date" required style="text-align:left; -webkit-appearance:none; appearance:none;" />
        </div>
        <!-- 2. 카드 이미지 -->
        <div class="input-group">
          <input type="hidden" id="ms-image" />
          <input type="hidden" id="ms-image-thumb" />
          <div id="ms-image-upload-area" class="ms-image-upload-area" role="button" tabindex="0" aria-label="카드 이미지 업로드">
            <div id="ms-image-placeholder" class="ms-image-upload-placeholder">
              <svg viewBox="0 0 24 24" width="52" height="52" fill="none" stroke="currentColor" stroke-width="1.3" stroke-linecap="round" stroke-linejoin="round">
                <rect x="3" y="3" width="18" height="18" rx="2"/>
                <circle cx="8.5" cy="8.5" r="1.5"/>
                <polyline points="21 15 16 10 5 21"/>
                <line x1="12" y1="7" x2="12" y2="12"/>
                <line x1="9.5" y1="9.5" x2="12" y2="7"/>
                <line x1="14.5" y1="9.5" x2="12" y2="7"/>
              </svg>
              <span>카드 이미지 업로드</span>
            </div>
            <img id="ms-image-preview" class="ms-image-upload-preview" style="display:none;" alt="카드 이미지 미리보기" />
          </div>
        </div>
        <!-- 3. 단일 제목 -->
        <div class="input-group">
          <label class="input-label">제목</label>
          <input class="input-field" id="ms-title" placeholder="일화 제목을 입력하세요" />
        </div>
        <!-- 4. 본문 -->
        <div class="input-group">
          <label class="input-label">본문</label>
          <textarea class="input-field" id="ms-body" placeholder="본문을 입력하세요..." style="min-height:250px; resize:vertical; line-height:1.6; font-family:var(--font-body);"></textarea>
        </div>
        ${C?`
          <!-- 편집 모드: 폼 하단 우측에 삭제 버튼 배치 -->
          <div class="mystory-form-inline-actions">
            <button type="button" class="btn btn-secondary mystory-form-delete-btn" id="delete-my-story-edit">삭제</button>
          </div>
        `:``}
      </form>
    </div>

    <!-- 화면 하단 floating 액션 영역 (저장 버튼) -->
    <div class="mystory-form-actions">
      <button type="submit" form="mystory-form" id="ms-save-btn" class="btn btn-primary btn-full">저장하기</button>
    </div>
  `,setTimeout(async()=>{function r(){return C?N?(document.getElementById(`ms-title`)?.value??``)!==N.title||(document.getElementById(`ms-body`)?.value??``)!==N.body||(document.getElementById(`ms-date`)?.value??``)!==N.date||(document.getElementById(`ms-image`)?.value??``)!==N.image_url:!1:!!(document.getElementById(`ms-title`)?.value.trim()||document.getElementById(`ms-body`)?.value.trim()||document.getElementById(`ms-image`)?.value)}async function a(){r()&&!await g({title:`저장하지 않고 나가기`,message:`작성 중인 내용이 저장되지 않습니다.
나가시겠습니까?`,confirmText:`나가기`,cancelText:`취소`})||history.back()}if(A(n,a),d.isNativePlatform()){let e=await S.addListener(`backButton`,a);window.addEventListener(`hashchange`,()=>e.remove(),{once:!0})}let o=document.getElementById(`ms-date`);o&&(o.value=D);let u=[];try{u=await O(p)}catch{}if(o?.addEventListener(`change`,e=>{let t=e.target.value;t&&u.find(e=>e.publish_date===t&&String(e.id)!==String(C))&&(m(`이미 등록된 일화가 있는 날짜입니다.`,`error`),e.target.value=``)}),C){let e=await v(C,h.id);e&&(document.getElementById(`ms-title`).value=e.title||``,document.getElementById(`ms-date`).value=e.publish_date||D,document.getElementById(`ms-body`).value=e.body||``,document.getElementById(`ms-image`).value=e.image_url||``,document.getElementById(`ms-image-thumb`).value=e.image_thumb_url||``,L(e.image_url||``),N={title:e.title||``,body:e.body||``,date:e.publish_date||D,image_url:e.image_url||``})}document.getElementById(`delete-my-story-edit`)?.addEventListener(`click`,async()=>{if(C&&await g({title:`일화 삭제`,message:`이 일화를 삭제하시겠습니까?
삭제한 일화는 복구할 수 없습니다.`,confirmText:`삭제`,cancelText:`취소`,danger:!0}))try{await x(C);let e=document.getElementById(`ms-date`)?.value||D;T(u.filter(e=>String(e.id)!==String(C))),m(`일화가 삭제되었습니다.`,`success`),i(`/mystory`,{date:e})}catch{m(`삭제 중 오류가 발생했습니다.`,`error`)}}),document.getElementById(`mystory-form`);async function b(e,t=!1,n){let r=e;if(t){if(!(e.includes(`firebasestorage.googleapis.com`)||e.includes(`.firebasestorage.app`))){m(`외부 이미지는 편집할 수 없습니다.
[사진 추가]로 새 이미지를 업로드해주세요.`,`error`);return}try{let t=new URL(e).pathname.split(`/o/`)[1]||``,n=await s(c(l,decodeURIComponent(t.split(`?`)[0])));r=URL.createObjectURL(n)}catch(e){console.error(`이미지 fetch 실패:`,e),m(`이미지를 불러올 수 없습니다. 다시 시도해주세요.`,`error`);return}}let i=document.createElement(`div`);i.className=`crop-modal-overlay`,i.innerHTML=`
        <div class="crop-modal-header">
          <button type="button" class="crop-modal-back-btn" id="btn-crop-back" aria-label="닫기">
            <svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
              <line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/>
            </svg>
          </button>
          카드 이미지 편집
        </div>
        <div class="crop-modal-body">
          <img id="cropper-image" src="${r}" style="max-width: 100%; display: block;" />
        </div>
        <div class="crop-modal-footer">
          <button type="button" class="btn-rotate" id="btn-crop-rotate">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
              <path d="M21 2v6h-6"/>
              <path d="M21 8A9 9 0 1 1 5.82 5.82"/>
            </svg>
            회전
          </button>
          <button type="button" class="btn-crop-confirm" id="btn-crop-confirm">완료</button>
        </div>
      `,(document.querySelector(`.mobile-wrapper`)||document.body).appendChild(i),w(),i.querySelector(`#btn-crop-back`).addEventListener(`click`,()=>{i.style.opacity=`0`,E(),setTimeout(()=>{o&&o.destroy(),t&&r.startsWith(`blob:`)&&URL.revokeObjectURL(r),i.remove()},300)}),setTimeout(()=>i.style.opacity=`1`,10);let a=i.querySelector(`#cropper-image`),o;a.onload=()=>{o=new j.default(a,{aspectRatio:M,viewMode:1,dragMode:`move`,autoCropArea:.9,restore:!1,guides:!0,center:!0,highlight:!1,cropBoxMovable:!0,cropBoxResizable:!0,toggleDragModeOnDblclick:!1})},a.onerror=()=>{m(`이미지를 불러올 수 없어 편집이 제한됩니다.`,`error`),t&&r.startsWith(`blob:`)&&URL.revokeObjectURL(r),E(),i.remove()},i.querySelector(`#btn-crop-rotate`).addEventListener(`click`,()=>{o&&o.rotate(90)}),i.querySelector(`#btn-crop-confirm`).addEventListener(`click`,()=>{let e=i.querySelector(`#btn-crop-confirm`);e.textContent=`처리 중...`,e.disabled=!0,o&&o.getCroppedCanvas({maxWidth:1200,maxHeight:1500,imageSmoothingEnabled:!0,imageSmoothingQuality:`high`}).toBlob(async a=>{if(!a){m(`크롭 오류가 발생했습니다.`,`error`),e.textContent=`다음`,e.disabled=!1;return}i.style.opacity=`0`,E(),setTimeout(()=>{o.destroy(),t&&r.startsWith(`blob:`)&&URL.revokeObjectURL(r),i.remove()},300),n(a)},`image/jpeg`,.85)})}function k(){let e=document.getElementById(`ms-save-btn`);e&&(e.disabled=!0,e.style.opacity=`0.5`,e.innerHTML=`<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="animation:ms-spin 1s linear infinite;flex-shrink:0;"><path d="M21 12a9 9 0 1 1-6.219-8.56"/></svg>업로드 중...`)}function P(){let e=document.getElementById(`ms-save-btn`);e&&(e.disabled=!1,e.style.opacity=``,e.innerHTML=`<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="flex-shrink:0;"><path d="M20 6 9 17l-5-5"/></svg>업로드 완료!`,setTimeout(()=>{e&&(e.innerHTML=`저장하기`)},2e3))}function F(){let e=document.getElementById(`ms-save-btn`);e&&(e.disabled=!1,e.style.opacity=``,e.innerHTML=`저장하기`)}async function I(e,t){if(document.getElementById(`ms-image`))try{if(k(),!p){m(`로그인이 필요합니다.`,`error`);return}e.name=t;let{image_url:n}=await f(e,{uid:p,folder:`diary`}),r=document.getElementById(`ms-image`),i=document.getElementById(`ms-image-thumb`);r&&(r.value=n),i&&(i.value=``),P(),L(n)}catch(e){console.error(`이미지 업로드 오류:`,e),F(),m(`이미지 저장에 실패했습니다.`,`error`)}}function L(e){let t=document.getElementById(`ms-image-placeholder`),n=document.getElementById(`ms-image-preview`);!t||!n||(e?(t.style.display=`none`,n.src=e,n.style.display=`block`):(t.style.display=``,n.src=``,n.style.display=`none`))}async function z(){try{let t=await e();if(!t)return;b(t.dataUrl,!1,e=>{I(e,`image.jpeg`)})}catch(e){if(e instanceof t){m(e.message,`warning`);return}m(e?.message||`사진을 불러올 수 없습니다.`,`error`)}}let B=document.getElementById(`ms-image-upload-area`);B?.addEventListener(`click`,z),B?.addEventListener(`keydown`,e=>{(e.key===`Enter`||e.key===` `)&&(e.preventDefault(),z())}),document.getElementById(`mystory-form`)?.addEventListener(`submit`,async e=>{if(e.preventDefault(),document.getElementById(`ms-save-btn`)?.disabled){m(`사진 업로드가 완료될 때까지 기다려주세요`,`warning`);return}let t={uid:p,title:document.getElementById(`ms-title`).value.trim(),publish_date:document.getElementById(`ms-date`).value,body:document.getElementById(`ms-body`).value.trim(),image_url:document.getElementById(`ms-image`).value.trim(),image_thumb_url:document.getElementById(`ms-image-thumb`)?.value.trim()||``,author_nickname:R()};if(!t.publish_date)return m(`날짜를 입력해주세요`,`warning`);if(!t.image_url)return m(`카드 이미지를 추가해주세요`,`warning`);try{C?(await y(C,t),m(`일화가 수정되었습니다`,`success`)):(await _(t),m(`새 일화가 작성되었습니다`,`success`)),T(C?[...u.filter(e=>String(e.id)!==String(C)),{...t,id:C}]:[...u,t]),i(`/mystory`,{date:t.publish_date})}catch{m(`저장 중 오류 발생`,`error`)}})},0),n}export{z as renderMyStory,U as renderMyStoryNew};