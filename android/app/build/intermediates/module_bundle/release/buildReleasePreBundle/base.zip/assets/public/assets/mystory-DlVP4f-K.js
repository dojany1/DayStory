import{a as e,n as t,o as n,t as r}from"./cropper--17xtoOq.js";import{n as i}from"./date-BXCTTgfI.js";import{a,c as o,r as s}from"./router-7m-s0x-D.js";import{n as c,r as l}from"./state-DQ9Huans.js";import{i as u,l as d,n as f,o as p}from"./firebase-DFBK8Wgd.js";import{t as m}from"./dist-DtHwfn-n.js";import{l as h,u as g}from"./stories-DtUSAb1-.js";import{r as _}from"./storyI18n-HHuSAaZ8.js";import{t as v}from"./toast-ejGG2_Wi.js";import{t as y}from"./sanitize-BzcRQ1L1.js";import{_ as b,a as x,c as S,d as C,f as w,g as T,h as E,l as D,m as O,n as k,p as A,r as j,t as M,u as N}from"./index-CSiNOSFm.js";import{n as P,t as F}from"./pageHeader-JuVe_YlV.js";var I=n(r(),1),L=4/5;function R(e){let t=e.querySelector(`#mystory-card-skeleton`);t&&(t.classList.add(`is-hiding`),setTimeout(()=>t.remove(),300))}var z=`/assets/editor_profile.png`,B=`this.onerror=null;this.src='${z}';this.classList.add('img-fallback');`,V=`<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M2 7v10"/><path d="M6 5v14"/><rect width="12" height="18" x="10" y="3" rx="2"/></svg>`,H=`<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M8 2v4"/><path d="M16 2v4"/><rect width="18" height="18" x="3" y="4" rx="2"/><path d="M3 10h18"/><path d="M8 14h.01"/><path d="M12 14h.01"/><path d="M16 14h.01"/><path d="M8 18h.01"/><path d="M12 18h.01"/><path d="M16 18h.01"/></svg>`;function U(e={}){let t=c(`profile`)||{},n=c(`user`)||{},r=typeof n.email==`string`?n.email.split(`@`)[0]:``;return[e.author_nickname,e.authorNickname,e.author?.nickname,e.author?.displayName,t.nickname,n.displayName,r].map(e=>typeof e==`string`?e.trim():``).find(Boolean)||`사용자`}function W(){let e=document.createElement(`div`);e.className=`mystory-page page`;let t=sessionStorage.getItem(`ds_session_view`)??(localStorage.getItem(`ds_default_view`)||`card`);return e.innerHTML=`
    <!-- 휠 피커 스타일 날짜 선택기 -->
    <div class="wheel-pickers-container">
      <div class="wheel-year-label" id="mystory-year-label">${new Date().getFullYear()}</div>
      <!-- 월 피커 -->
      <div class="wheel-picker-wrapper">
        <div class="wheel-selection-box"></div>
        <div class="modern-wheel-scroll" id="mystory-month-scroll"></div>
        <button type="button" class="view-toggle-btn" id="mystory-view-toggle" aria-label="보기 방식 변경">${t===`calendar`?H:V}</button>
      </div>
      <!-- 일 피커 -->
      <div class="wheel-picker-wrapper" id="mystory-day-picker">
        <div class="wheel-selection-box"></div>
        <div class="modern-wheel-scroll" id="mystory-calendar"></div>
      </div>
    </div>

    <!-- 카드 렌더링 영역 (Swiper) -->
    <div class="editorstory-card-area" id="mystory-card-area">
      <div class="swiper card-swiper" id="mystory-card-swiper">
        <div class="swiper-wrapper"></div>
      </div>
      <div class="skeleton-card" id="mystory-card-skeleton" aria-hidden="true"></div>
    </div>

    <div class="page-calendar-view" id="mystory-cal-view" hidden>
      <div class="calendar-month-nav">
        <button type="button" class="calendar-month-arrow" id="cal-prev-month" aria-label="이전 달">
          <svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" stroke-width="2"><polyline points="15 18 9 12 15 6"/></svg>
        </button>
        <div class="calendar-month-label" id="cal-month-label">—</div>
        <button type="button" class="calendar-month-arrow" id="cal-next-month" aria-label="다음 달">
          <svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" stroke-width="2"><polyline points="9 18 15 12 9 6"/></svg>
        </button>
      </div>
      <div class="calendar-weekdays">
        ${k.map((e,t)=>`<div class="calendar-weekday ${t===0?`sun`:t===6?`sat`:``}">${e}</div>`).join(``)}
      </div>
      <div class="calendar-grid" id="calendar-grid">
        <div class="calendar-grid-loading"><div class="loading-spinner"></div></div>
      </div>
    </div>
  `,t===`calendar`&&(e.querySelector(`#mystory-day-picker`).hidden=!0,e.querySelector(`#mystory-card-area`).hidden=!0,e.querySelector(`#mystory-cal-view`).hidden=!1),G(e),e}async function G(e){try{let t=c(`user`),n=await A(f?.currentUser?.uid||t?.id);T(n);let r=s(),a=i(),[u,d,p]=a.split(`-`),m=new Date(parseInt(u),parseInt(d)-1,parseInt(p)),h=c(`lastMyStoryDate`)||r.date||a,g=e.querySelector(`#mystory-month-scroll`),_=e.querySelector(`#mystory-calendar`),v=e.querySelector(`#mystory-card-swiper`),y=m.getFullYear(),b=m.getMonth()+1,S=m.getDate();g&&(g.innerHTML=Array.from({length:12},(e,t)=>{let n=t+1;return`<div class="wheel-item${n>b?` disabled`:``}" data-month="${n}">${n}</div>`}).join(``));let C=[];for(let e=1;e<=b;e++){let t=e===b?S:new Date(y,e,0).getDate();for(let n=1;n<=t;n++){let t=String(e).padStart(2,`0`),r=String(n).padStart(2,`0`);C.push({iso:`${y}-${t}-${r}`,month:e,day:n})}}_&&(_.innerHTML=C.map(({iso:e,month:t,day:n})=>`<div class="wheel-item" data-date="${e}" data-month="${t}" data-day="${n}">${n}</div>`).join(``));let w=new Map;for(let e of n)e?.publish_date&&w.set(e.publish_date,e);let E=C.map(({iso:e})=>({iso:e,story:w.get(e)||null})),D=C.findIndex(e=>e.iso===h);D<0&&(D=C.findIndex(e=>e.iso===a)),D=Math.max(0,D);function O(e){let t=e.getBoundingClientRect().left+e.offsetWidth/2,n=null,r=1/0;return e.querySelectorAll(`.wheel-item:not(.disabled)`).forEach(e=>{let i=e.getBoundingClientRect().left+e.offsetWidth/2,a=Math.abs(t-i);a<r&&(r=a,n=e)}),n}function k(e,t=!1){let n=g.querySelector(`.wheel-item.active`);if(n&&parseInt(n.dataset.month,10)===e)return;let r=g.querySelector(`.wheel-item[data-month="${e}"]`);if(!r)return;g.querySelectorAll(`.wheel-item`).forEach(e=>e.classList.remove(`active`)),r.classList.add(`active`);let i=r.offsetLeft-g.offsetWidth/2+r.offsetWidth/2;t?g.scrollLeft=i:g.scrollTo({left:i,behavior:`smooth`})}function N(e,t=!1){let n=_.querySelectorAll(`.wheel-item`);n.forEach(e=>e.classList.remove(`active`));let r=n[e];if(!r)return;r.classList.add(`active`),k(parseInt(r.dataset.month,10),t);let i=r.offsetLeft-_.offsetWidth/2+r.offsetWidth/2;t?_.scrollLeft=i:_.scrollTo({left:i,behavior:`smooth`})}let P={mode:`mine`,year:y,month:m.getMonth(),historyStories:[],myStories:n,bookmarkedIds:[]},F=e.querySelector(`#mystory-view-toggle`),I=e.querySelector(`#mystory-day-picker`),L=e.querySelector(`#mystory-card-area`),z=e.querySelector(`#mystory-cal-view`),B=sessionStorage.getItem(`ds_session_view`)??(localStorage.getItem(`ds_default_view`)||`card`),U=null,W=()=>U||(v.offsetParent===null?null:(U=M(v,{slides:E,renderSlide:e=>`<div class="swiper-slide">${K(e.story,e.iso)}</div>`,initialSlide:D,onSlideActive:e=>{l(`lastMyStoryDate`,E[e]?.iso??null),N(e)},onSlideReady:e=>{let t=v.querySelector(`.swiper-slide-active`);if(!t)return;let n=t.querySelector(`.flip-container`);if(!n)return;let r=E[e];q(n,r?.story,r?.iso)}}),R(e),U));if(B!==`calendar`){let e=0,t=()=>{N(D,!0);let n=W();if(n){requestAnimationFrame(()=>n.update());return}++e<8&&requestAnimationFrame(t)};requestAnimationFrame(t)}o(()=>{U&&!U.destroyed&&U.destroy(!0,!0)});let G;_.addEventListener(`scroll`,()=>{clearTimeout(G),G=setTimeout(()=>{let e=O(_);if(!e)return;let t=e.dataset.date,n=E.findIndex(e=>e.iso===t),r=W();!r||n<0||n===r.activeIndex||r.slideTo(n,320)},150)},{passive:!0});let J;g.addEventListener(`scroll`,()=>{B===`card`&&(clearTimeout(J),J=setTimeout(()=>{let e=O(g);if(!e||e.classList.contains(`disabled`))return;let t=_.querySelector(`.wheel-item.active`),n=t?parseInt(t.dataset.month,10):-1;parseInt(e.dataset.month,10)===n?(g.querySelectorAll(`.wheel-item`).forEach(e=>e.classList.remove(`active`)),e.classList.add(`active`)):Y(e)},150))},{passive:!0});let Y=e=>{if(e.classList.contains(`disabled`))return;let t=parseInt(e.dataset.month,10),n=t===b?String(S).padStart(2,`0`):`01`,r=`${y}-${String(t).padStart(2,`0`)}-${n}`,i=E.findIndex(e=>e.iso===r);if(i<0)return;g.querySelectorAll(`.wheel-item`).forEach(e=>e.classList.remove(`active`)),e.classList.add(`active`);let a=e.offsetLeft-g.offsetWidth/2+e.offsetWidth/2;g.scrollTo({left:a,behavior:`smooth`});let o=W();o&&o.slideTo(i,320)},X=e=>{let t=e.dataset.date,n=E.findIndex(e=>e.iso===t);if(n<0)return;let r=W();r&&r.slideTo(n,320)};g.querySelectorAll(`.wheel-item`).forEach(e=>e.addEventListener(`click`,()=>Y(e))),_.querySelectorAll(`.wheel-item`).forEach(e=>e.addEventListener(`click`,()=>X(e))),B===`calendar`&&x(e,P,m),F.addEventListener(`click`,()=>{B===`card`?(B=`calendar`,sessionStorage.setItem(`ds_session_view`,`calendar`),F.innerHTML=H,I.hidden=!0,L.hidden=!0,z.hidden=!1,requestAnimationFrame(()=>{z.classList.add(`view-enter`),x(e,P,m),setTimeout(()=>z.classList.remove(`view-enter`),250)})):(B=`card`,sessionStorage.setItem(`ds_session_view`,`card`),F.innerHTML=V,z.hidden=!0,I.hidden=!1,L.hidden=!1,requestAnimationFrame(()=>{let e=_.querySelector(`.wheel-item.active`);e&&(_.scrollLeft=e.offsetLeft-_.offsetWidth/2+e.offsetWidth/2);let t=W();t&&requestAnimationFrame(()=>t.update()),L.classList.add(`view-enter`),setTimeout(()=>L.classList.remove(`view-enter`),250)}))});let Z;g.addEventListener(`scroll`,()=>{B===`calendar`&&(clearTimeout(Z),Z=setTimeout(()=>{let t=O(g);if(!t)return;let n=parseInt(t.dataset.month,10)-1;n===P.month&&P.year===y||(P.month=n,P.year=y,x(e,P,m))},150))},{passive:!0}),e.querySelector(`#cal-prev-month`).addEventListener(`click`,()=>{--P.month,P.month<0&&(P.month=11,--P.year);let t=e.querySelector(`#mystory-year-label`);t&&(t.textContent=P.year),x(e,P,m),k(P.month+1)}),e.querySelector(`#cal-next-month`).addEventListener(`click`,()=>{if(j(P,m))return;P.month+=1,P.month>11&&(P.month=0,P.year+=1);let t=e.querySelector(`#mystory-year-label`);t&&(t.textContent=P.year),x(e,P,m),k(P.month+1)})}catch(t){console.error(`loadMyStoryData 오류:`,t?.message||t?.code||JSON.stringify(t)),e.innerHTML=`<div class="empty-state"><div class="empty-state-title">오류가 발생했습니다</div></div>`}}function K(e,t){let[n,r,i]=t.split(`-`),a=new Date(parseInt(n,10),parseInt(r,10)-1,parseInt(i,10)),o=a.getMonth()+1,s=a.getDate(),c=a.getFullYear();if(!e)return`
      <div class="flip-container">
        <div class="flipper mystory-flipper">
          <div class="front history-card-front empty-story-card">
            <div class="empty-story-day-circle">${s}</div>
            <div class="empty-story-title">이 날의 기록이 없습니다.</div>
            <div class="empty-story-date">${`${[`JAN`,`FEB`,`MAR`,`APR`,`MAY`,`JUN`,`JUL`,`AUG`,`SEP`,`OCT`,`NOV`,`DEC`][a.getMonth()]} ${s}, ${c}`}</div>
            <button class="btn btn-primary mystory-write-btn" data-date="${t}">
              + 나의 일화 쓰기
            </button>
          </div>
        </div>
      </div>
    `;let[l,u,d]=String(e.publish_date||t).split(`-`),f=parseInt(l,10)||c,p=parseInt(u,10)||o,m=parseInt(d,10)||s,h=e.image_url||z,g=(e.body||``).split(/\n|\\n/).map(e=>e.trim()?`<p>${y(e)}</p>`:`<p><br></p>`).join(``),_=U(e);return`
    <div class="flip-container">
      <div class="flipper mystory-flipper">
        <!-- 앞면 -->
        <div class="front history-card-front">
          <div class="history-card-top">
            <div class="card-top-left">
              <div class="card-year mystory-card-year">${f}</div>
              <div class="card-date">${p}. ${m}</div>
            </div>
            <div class="card-top-right">
              <div class="card-actions">
                <button class="card-action-btn share-my-story-btn" data-id="${y(e.id)}" aria-label="공유">
                  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                    <circle cx="18" cy="5" r="3"/><circle cx="6" cy="12" r="3"/><circle cx="18" cy="19" r="3"/>
                    <line x1="8.59" y1="13.51" x2="15.42" y2="17.49"/><line x1="15.41" y1="6.51" x2="8.59" y2="10.49"/>
                  </svg>
                </button>
                <button class="card-action-btn edit-my-story-btn" data-id="${y(e.id)}" aria-label="수정">
                  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                    <path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"></path>
                    <path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"></path>
                  </svg>
                </button>
              </div>
              <div class="card-meta">${y(_)}</div>
            </div>
          </div>
          <div class="history-card-image-wrap">
            <img src="${y(h)}" alt="${y(e.title)}" loading="lazy" decoding="async" width="320" height="400" draggable="false" onerror="${B}" />
            <div class="card-image-title">${y(e.title)}</div>
          </div>
        </div>
        <!-- 뒷면 -->
        <div class="back history-card-back">
          <div class="back-title">${y(e.title)}</div>
          <hr class="back-divider" />
          <div class="back-body">${g}</div>
          <div class="back-footer">
            <div class="back-date">${f}년 ${p}월 ${m}일</div>
          </div>
        </div>
      </div>
    </div>
  `}function q(e,t,n){let r=e.querySelector(`.flipper`);if(!r||e.dataset.bound===`1`)return;e.dataset.bound=`1`,e.querySelectorAll(`.history-card-image-wrap img`).forEach(e=>{e.classList.add(`card-img-fade`),e.complete&&e.naturalWidth>0?e.classList.add(`img-loaded`):(e.addEventListener(`load`,()=>e.classList.add(`img-loaded`),{once:!0}),e.addEventListener(`error`,()=>e.classList.add(`img-loaded`),{once:!0}))});let i=e.querySelector(`.mystory-write-btn`),o=e.querySelector(`.share-my-story-btn`),s=e.querySelector(`.edit-my-story-btn`),l=()=>{let e=c(`user`)||{};return f?.currentUser?.uid||e.id?!0:(v(`로그인이 필요한 서비스입니다.`,`error`),location.hash=`#/login`,!1)};i&&i.addEventListener(`click`,e=>{e.stopPropagation(),l()&&a(`/mystory/new?date=`+i.dataset.date)}),o&&t&&o.addEventListener(`click`,async e=>{e.stopPropagation(),l()&&await _(t,{kind:`mystory`,includeImage:!1})}),s&&s.addEventListener(`click`,e=>{e.stopPropagation(),l()&&a(`/mystory/new?edit=`+s.dataset.id)}),r.addEventListener(`click`,e=>{t&&(e.target.closest(`button`)||r.classList.contains(`is-flipping`)||(r.classList.add(`is-flipping`),r.classList.toggle(`flipped`),setTimeout(()=>r.classList.remove(`is-flipping`),400)))})}function J(){let n=document.createElement(`div`);n.className=`mystory-new-page page`;let r=c(`user`)||{},i=f?.currentUser?.uid||r.id;if(!i)return n.innerHTML=`
      ${P({title:`권한 없음`,backLabel:`뒤로`})}
      <div class="empty-state" style="padding-top: 100px;">
        <div class="empty-state-title">로그인이 필요합니다</div>
        <div class="empty-state-desc">나의 일화를 작성하려면 로그인해주세요.</div>
        <button class="btn btn-primary" style="margin-top: 16px;" id="ms-no-auth-back">뒤로 가기</button>
      </div>
    `,setTimeout(()=>{F(n,()=>history.back()),document.getElementById(`ms-no-auth-back`)?.addEventListener(`click`,()=>history.back())},0),n;let o=r,l=s(),_=l.edit||null,y=l.date||new Date().toISOString().split(`T`)[0],x=null;return n.innerHTML=`
    ${P({title:_?`나의 일화 수정`:`나의 일화 쓰기`,backLabel:`뒤로`})}

    <div class="editor-form-section section mystory-form-section">
      <form id="mystory-form" class="story-form">
        <!-- 1. 날짜 -->
        <div class="input-group">
          <label class="input-label">날짜 *</label>
          <input class="input-field" type="date" id="ms-date" required style="text-align:left; -webkit-appearance:none; appearance:none;" />
        </div>
        <!-- 2. 카드 이미지 -->
        <div class="input-group">
          <input type="hidden" id="ms-image" />
          <input type="hidden" id="ms-image-thumb" />
          <div id="ms-image-upload-area" class="ms-image-upload-area" role="button" tabindex="0" aria-label="카드 이미지 업로드">
            <div id="ms-image-placeholder" class="ms-image-upload-placeholder">
              <svg viewBox="0 0 24 24" width="48" height="48" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round">
                <path d="M21 12v7a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h7"/>
                <line x1="16" x2="22" y1="5" y2="5"/>
                <line x1="19" x2="19" y1="2" y2="8"/>
                <circle cx="9" cy="9" r="2"/>
                <path d="m21 15-3.086-3.086a2 2 0 0 0-2.828 0L6 21"/>
              </svg>
              <span>카드 이미지 업로드</span>
            </div>
            <img id="ms-image-preview" class="ms-image-upload-preview" style="display:none;" alt="카드 이미지 미리보기" />
          </div>
        </div>
        <!-- 3. 단일 제목 -->
        <div class="input-group">
          <label class="input-label">제목</label>
          <input class="input-field" id="ms-title" />
        </div>
        <!-- 4. 본문 -->
        <div class="input-group">
          <label class="input-label">본문</label>
          <textarea class="input-field" id="ms-body" style="min-height:250px; resize:vertical; line-height:1.6; font-family:var(--font-body);"></textarea>
        </div>
        ${_?`
          <!-- 편집 모드: 폼 하단 우측에 삭제 버튼 배치 -->
          <div class="mystory-form-inline-actions">
            <button type="button" class="btn btn-secondary mystory-form-delete-btn" id="delete-my-story-edit">삭제</button>
          </div>
        `:``}
      </form>
    </div>

    <!-- 화면 하단 floating 액션 영역 (저장 버튼) -->
    <div class="mystory-form-actions">
      <button type="submit" form="mystory-form" id="ms-save-btn" class="btn btn-primary btn-full">저장하기</button>
    </div>
  `,setTimeout(async()=>{function r(){return _?x?(document.getElementById(`ms-title`)?.value??``)!==x.title||(document.getElementById(`ms-body`)?.value??``)!==x.body||(document.getElementById(`ms-date`)?.value??``)!==x.date||(document.getElementById(`ms-image`)?.value??``)!==x.image_url:!1:!!(document.getElementById(`ms-title`)?.value.trim()||document.getElementById(`ms-body`)?.value.trim()||document.getElementById(`ms-image`)?.value)}async function s(){r()&&!await S({title:`저장하지 않고 나가기`,message:`작성 중인 내용이 저장되지 않습니다.
나가시겠습니까?`,confirmText:`나가기`,cancelText:`취소`})||history.back()}if(F(n,s),m.isNativePlatform()){let e=await b.addListener(`backButton`,s);window.addEventListener(`hashchange`,()=>e.remove(),{once:!0})}let c=document.getElementById(`ms-date`);c&&(c.value=y);let l=[];try{l=await A(i)}catch{}if(c?.addEventListener(`change`,e=>{let t=e.target.value;t&&l.find(e=>e.publish_date===t&&String(e.id)!==String(_))&&(v(`이미 등록된 일화가 있는 날짜입니다.`,`error`),e.target.value=``)}),_){let e=await O(_,o.id);e&&(document.getElementById(`ms-title`).value=e.title||``,document.getElementById(`ms-date`).value=e.publish_date||y,document.getElementById(`ms-body`).value=e.body||``,document.getElementById(`ms-image`).value=e.image_url||``,document.getElementById(`ms-image-thumb`).value=e.image_thumb_url||``,R(e.image_url||``),x={title:e.title||``,body:e.body||``,date:e.publish_date||y,image_url:e.image_url||``})}document.getElementById(`delete-my-story-edit`)?.addEventListener(`click`,async()=>{if(_&&await S({title:`일화 삭제`,message:`이 일화를 삭제하시겠습니까?
삭제한 일화는 복구할 수 없습니다.`,confirmText:`삭제`,cancelText:`취소`,danger:!0}))try{await w(_);let e=document.getElementById(`ms-date`)?.value||y;T(l.filter(e=>String(e.id)!==String(_))),v(`일화가 삭제되었습니다.`,`success`),a(`/mystory`,{date:e})}catch{v(`삭제 중 오류가 발생했습니다.`,`error`)}}),document.getElementById(`mystory-form`);async function f(e,t=!1,n){let r=e;if(t){if(!g(e)){v(`외부 이미지는 편집할 수 없습니다.
[사진 추가]로 새 이미지를 업로드해주세요.`,`error`);return}try{let t=new URL(e).pathname.split(`/o/`)[1]||``,n=await p(d(u,decodeURIComponent(t.split(`?`)[0])));r=URL.createObjectURL(n)}catch(e){console.error(`이미지 fetch 실패:`,e),v(`이미지를 불러올 수 없습니다. 다시 시도해주세요.`,`error`);return}}let i=document.createElement(`div`);i.className=`crop-modal-overlay`,i.innerHTML=`
        <div class="crop-modal-header">
          <button type="button" class="crop-modal-back-btn" id="btn-crop-back" aria-label="닫기">
            <svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
              <line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/>
            </svg>
          </button>
          카드 이미지 편집
        </div>
        <div class="crop-modal-body">
          <img id="cropper-image" src="${r}" style="max-width: 100%; display: block;" />
        </div>
        <div class="crop-modal-footer">
          <button type="button" class="btn-rotate" id="btn-crop-rotate">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
              <path d="M21 2v6h-6"/>
              <path d="M21 13a9 9 0 1 1-2.63-6.36L21 9"/>
            </svg>
            회전
          </button>
          <button type="button" class="btn-crop-confirm" id="btn-crop-confirm">완료</button>
        </div>
      `,(document.querySelector(`.mobile-wrapper`)||document.body).appendChild(i),D(),i.querySelector(`#btn-crop-back`).addEventListener(`click`,()=>{i.style.opacity=`0`,N(),setTimeout(()=>{o&&o.destroy(),t&&r.startsWith(`blob:`)&&URL.revokeObjectURL(r),i.remove()},300)}),setTimeout(()=>i.style.opacity=`1`,10);let a=i.querySelector(`#cropper-image`),o;a.onload=()=>{o=new I.default(a,{aspectRatio:L,viewMode:1,dragMode:`move`,autoCropArea:.9,restore:!1,guides:!0,center:!0,highlight:!1,cropBoxMovable:!0,cropBoxResizable:!0,toggleDragModeOnDblclick:!1})},a.onerror=()=>{v(`이미지를 불러올 수 없어 편집이 제한됩니다.`,`error`),t&&r.startsWith(`blob:`)&&URL.revokeObjectURL(r),N(),i.remove()},i.querySelector(`#btn-crop-rotate`).addEventListener(`click`,()=>{o&&o.rotate(90)}),i.querySelector(`#btn-crop-confirm`).addEventListener(`click`,()=>{let e=i.querySelector(`#btn-crop-confirm`);e.textContent=`처리 중...`,e.disabled=!0,o&&o.getCroppedCanvas({maxWidth:1200,maxHeight:1500,imageSmoothingEnabled:!0,imageSmoothingQuality:`high`}).toBlob(async a=>{if(!a){v(`크롭 오류가 발생했습니다.`,`error`),e.textContent=`다음`,e.disabled=!1;return}i.style.opacity=`0`,N(),setTimeout(()=>{o.destroy(),t&&r.startsWith(`blob:`)&&URL.revokeObjectURL(r),i.remove()},300),n(a)},`image/jpeg`,.85)})}function k(){let e=document.getElementById(`ms-save-btn`);e&&(e.disabled=!0,e.style.opacity=`0.5`,e.innerHTML=`<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="animation:ms-spin 1s linear infinite;flex-shrink:0;"><path d="M21 12a9 9 0 1 1-6.219-8.56"/></svg>업로드 중...`)}function j(){let e=document.getElementById(`ms-save-btn`);e&&(e.disabled=!1,e.style.opacity=``,e.innerHTML=`<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="flex-shrink:0;"><path d="M20 6 9 17l-5-5"/></svg>업로드 완료!`,setTimeout(()=>{e&&(e.innerHTML=`저장하기`)},2e3))}function M(){let e=document.getElementById(`ms-save-btn`);e&&(e.disabled=!1,e.style.opacity=``,e.innerHTML=`저장하기`)}async function P(e,t){if(document.getElementById(`ms-image`))try{if(k(),!i){v(`로그인이 필요합니다.`,`error`);return}e.name=t;let{image_url:n}=await h(e,{uid:i,folder:`diary`}),r=document.getElementById(`ms-image`),a=document.getElementById(`ms-image-thumb`);r&&(r.value=n),a&&(a.value=``),j(),R(n)}catch(e){console.error(`이미지 업로드 오류:`,e),M(),v(`이미지 저장에 실패했습니다.`,`error`)}}function R(e){let t=document.getElementById(`ms-image-placeholder`),n=document.getElementById(`ms-image-preview`);!t||!n||(e?(t.style.display=`none`,n.src=e,n.style.display=`block`):(t.style.display=``,n.src=``,n.style.display=`none`))}async function z(){try{let t=await e();if(!t)return;f(t.dataUrl,!1,e=>{P(e,`image.jpeg`)})}catch(e){if(e instanceof t){v(e.message,`warning`);return}v(e?.message||`사진을 불러올 수 없습니다.`,`error`)}}let B=document.getElementById(`ms-image-upload-area`);B?.addEventListener(`click`,z),B?.addEventListener(`keydown`,e=>{(e.key===`Enter`||e.key===` `)&&(e.preventDefault(),z())}),document.getElementById(`mystory-form`)?.addEventListener(`submit`,async e=>{if(e.preventDefault(),document.getElementById(`ms-save-btn`)?.disabled){v(`사진 업로드가 완료될 때까지 기다려주세요`,`warning`);return}let t={uid:i,title:document.getElementById(`ms-title`).value.trim(),publish_date:document.getElementById(`ms-date`).value,body:document.getElementById(`ms-body`).value.trim(),image_url:document.getElementById(`ms-image`).value.trim(),image_thumb_url:document.getElementById(`ms-image-thumb`)?.value.trim()||``,author_nickname:U()};if(!t.publish_date)return v(`날짜를 입력해주세요`,`warning`);if(!t.image_url)return v(`카드 이미지를 추가해주세요`,`warning`);try{_?(await E(_,t),v(`일화가 수정되었습니다`,`success`)):(await C(t),v(`새 일화가 작성되었습니다`,`success`)),T(_?[...l.filter(e=>String(e.id)!==String(_)),{...t,id:_}]:[...l,t]),a(`/mystory`,{date:t.publish_date})}catch{v(`저장 중 오류 발생`,`error`)}})},0),n}export{W as renderMyStory,J as renderMyStoryNew};