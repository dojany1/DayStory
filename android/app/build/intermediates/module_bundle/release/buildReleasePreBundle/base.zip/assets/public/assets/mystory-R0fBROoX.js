import{a as e,n as t,o as n,t as r}from"./cropper-Q-pmSV8F.js";import{a as i,c as a,r as o}from"./router-7m-s0x-D.js";import{n as s}from"./state-DQ9Huans.js";import{a as c,c as l,r as u,t as d}from"./firebase-tVkosmAg.js";import{t as f}from"./dist-D9tJEqyA.js";import{l as p,u as m}from"./stories-BJOWrBKk.js";import{r as h}from"./storyI18n-CidmYVJi.js";import{t as g}from"./toast-C65VsBgm.js";import{t as _}from"./sanitize-rT1jjWTx.js";import{a as v,c as y,d as b,f as x,h as S,l as C,m as w,n as T,o as E,p as D,r as O,s as k,t as A,u as j}from"./index-BvRF4SpI.js";import{n as M,t as N}from"./pageHeader-C1YuwkAJ.js";var P=n(r(),1),F=4/5,I=`<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M2 7v10"/><path d="M6 5v14"/><rect width="12" height="18" x="10" y="3" rx="2"/></svg>`,L=`<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M8 2v4"/><path d="M16 2v4"/><rect width="18" height="18" x="3" y="4" rx="2"/><path d="M3 10h18"/><path d="M8 14h.01"/><path d="M12 14h.01"/><path d="M16 14h.01"/><path d="M8 18h.01"/><path d="M12 18h.01"/><path d="M16 18h.01"/></svg>`;function R(e={}){let t=s(`profile`)||{},n=s(`user`)||{},r=typeof n.email==`string`?n.email.split(`@`)[0]:``;return[e.author_nickname,e.authorNickname,e.author?.nickname,e.author?.displayName,t.nickname,n.displayName,r].map(e=>typeof e==`string`?e.trim():``).find(Boolean)||`사용자`}function z(){let e=document.createElement(`div`);e.className=`mystory-page page`;let t=sessionStorage.getItem(`ds_session_view`)??(localStorage.getItem(`ds_default_view`)||`card`);return e.innerHTML=`
    <!-- 휠 피커 스타일 날짜 선택기 -->
    <div class="wheel-pickers-container">
      <div class="wheel-year-label" id="mystory-year-label">${new Date().getFullYear()}</div>
      <!-- 월 피커 -->
      <div class="wheel-picker-wrapper">
        <div class="wheel-selection-box"></div>
        <div class="modern-wheel-scroll" id="mystory-month-scroll"></div>
        <button type="button" class="view-toggle-btn" id="mystory-view-toggle" aria-label="보기 방식 변경">${t===`calendar`?L:I}</button>
      </div>
      <!-- 일 피커 -->
      <div class="wheel-picker-wrapper" id="mystory-day-picker">
        <div class="wheel-selection-box"></div>
        <div class="modern-wheel-scroll" id="mystory-calendar"></div>
      </div>
    </div>

    <!-- 카드 렌더링 영역 (Swiper) -->
    <div class="editorstory-card-area" id="mystory-card-area">
      <div class="swiper card-swiper" id="mystory-card-swiper">
        <div class="swiper-wrapper"></div>
      </div>
    </div>

    <div class="page-calendar-view" id="mystory-cal-view" hidden>
      <div class="calendar-month-nav">
        <button type="button" class="calendar-month-arrow" id="cal-prev-month" aria-label="이전 달">
          <svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" stroke-width="2"><polyline points="15 18 9 12 15 6"/></svg>
        </button>
        <div class="calendar-month-label" id="cal-month-label">—</div>
        <button type="button" class="calendar-month-arrow" id="cal-next-month" aria-label="다음 달">
          <svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" stroke-width="2"><polyline points="9 18 15 12 9 6"/></svg>
        </button>
      </div>
      <div class="calendar-weekdays">
        ${T.map((e,t)=>`<div class="calendar-weekday ${t===0?`sun`:t===6?`sat`:``}">${e}</div>`).join(``)}
      </div>
      <div class="calendar-grid" id="calendar-grid">
        <div class="calendar-grid-loading"><div class="loading-spinner"></div></div>
      </div>
    </div>
  `,t===`calendar`&&(e.querySelector(`#mystory-day-picker`).hidden=!0,e.querySelector(`#mystory-card-area`).hidden=!0,e.querySelector(`#mystory-cal-view`).hidden=!1),B(e),e}async function B(e){try{let t=s(`user`),n=await b(d?.currentUser?.uid||t?.id);w(n);let r=o(),i=new Date,c=new Date(i.getTime()-i.getTimezoneOffset()*6e4).toISOString().split(`T`)[0],[l,u,f]=c.split(`-`),p=new Date(parseInt(l),parseInt(u)-1,parseInt(f)),m=r.date||c,h=e.querySelector(`#mystory-month-scroll`),g=e.querySelector(`#mystory-calendar`),_=e.querySelector(`#mystory-card-swiper`),y=p.getFullYear(),x=p.getMonth()+1,S=p.getDate();h&&(h.innerHTML=Array.from({length:12},(e,t)=>{let n=t+1;return`<div class="wheel-item${n>x?` disabled`:``}" data-month="${n}">${n}</div>`}).join(``));let C=[];for(let e=1;e<=x;e++){let t=e===x?S:new Date(y,e,0).getDate();for(let n=1;n<=t;n++){let t=String(e).padStart(2,`0`),r=String(n).padStart(2,`0`);C.push({iso:`${y}-${t}-${r}`,month:e,day:n})}}g&&(g.innerHTML=C.map(({iso:e,month:t,day:n})=>`<div class="wheel-item" data-date="${e}" data-month="${t}" data-day="${n}">${n}</div>`).join(``));let T=new Map;for(let e of n)e?.publish_date&&T.set(e.publish_date,e);let E=C.map(({iso:e})=>({iso:e,story:T.get(e)||null})),D=Math.max(0,C.findIndex(e=>e.iso===m));function k(e){let t=e.getBoundingClientRect().left+e.offsetWidth/2,n=null,r=1/0;return e.querySelectorAll(`.wheel-item:not(.disabled)`).forEach(e=>{let i=e.getBoundingClientRect().left+e.offsetWidth/2,a=Math.abs(t-i);a<r&&(r=a,n=e)}),n}function j(e){let t=h.querySelector(`.wheel-item.active`);if(t&&parseInt(t.dataset.month,10)===e)return;let n=h.querySelector(`.wheel-item[data-month="${e}"]`);if(!n)return;h.querySelectorAll(`.wheel-item`).forEach(e=>e.classList.remove(`active`)),n.classList.add(`active`);let r=n.offsetLeft-h.offsetWidth/2+n.offsetWidth/2;h.scrollTo({left:r,behavior:`smooth`})}function M(e){let t=g.querySelectorAll(`.wheel-item`);t.forEach(e=>e.classList.remove(`active`));let n=t[e];if(!n)return;n.classList.add(`active`),j(parseInt(n.dataset.month,10));let r=n.offsetLeft-g.offsetWidth/2+n.offsetWidth/2;g.scrollTo({left:r,behavior:`smooth`})}let N=_.querySelector(`.swiper-wrapper`);N&&(N.innerHTML=E.map(e=>`<div class="swiper-slide">${V(e.story,e.iso)}</div>`).join(``));let P=null;P=A(_,{slideCount:E.length,initialSlide:D,onSlideActive:e=>{M(e)},onSlideReady:e=>{let t=_.querySelector(`.swiper-slide-active`);if(!t)return;let n=t.querySelector(`.flip-container`);if(!n)return;let r=E[e];H(n,r?.story,r?.iso)}}),a(()=>{P&&!P.destroyed&&P.destroy(!0,!0)});let F;g.addEventListener(`scroll`,()=>{clearTimeout(F),F=setTimeout(()=>{let e=k(g);if(!e)return;let t=e.dataset.date,n=E.findIndex(e=>e.iso===t);n<0||n===P.activeIndex||P.slideTo(n,320)},150)},{passive:!0});let R;h.addEventListener(`scroll`,()=>{J===`card`&&(clearTimeout(R),R=setTimeout(()=>{let e=k(h);if(!e||e.classList.contains(`disabled`))return;let t=g.querySelector(`.wheel-item.active`),n=t?parseInt(t.dataset.month,10):-1;parseInt(e.dataset.month,10)===n?(h.querySelectorAll(`.wheel-item`).forEach(e=>e.classList.remove(`active`)),e.classList.add(`active`)):z(e)},150))},{passive:!0});let z=e=>{if(e.classList.contains(`disabled`))return;let t=parseInt(e.dataset.month,10),n=t===x?String(S).padStart(2,`0`):`01`,r=`${y}-${String(t).padStart(2,`0`)}-${n}`,i=E.findIndex(e=>e.iso===r);if(i<0)return;h.querySelectorAll(`.wheel-item`).forEach(e=>e.classList.remove(`active`)),e.classList.add(`active`);let a=e.offsetLeft-h.offsetWidth/2+e.offsetWidth/2;h.scrollTo({left:a,behavior:`smooth`}),P.slideTo(i,320)},B=e=>{let t=e.dataset.date,n=E.findIndex(e=>e.iso===t);n<0||P.slideTo(n,320)};h.querySelectorAll(`.wheel-item`).forEach(e=>e.addEventListener(`click`,()=>z(e))),g.querySelectorAll(`.wheel-item`).forEach(e=>e.addEventListener(`click`,()=>B(e)));let U={mode:`mine`,year:y,month:p.getMonth(),historyStories:[],myStories:n,bookmarkedIds:[]},W=e.querySelector(`#mystory-view-toggle`),G=e.querySelector(`#mystory-day-picker`),K=e.querySelector(`#mystory-card-area`),q=e.querySelector(`#mystory-cal-view`),J=sessionStorage.getItem(`ds_session_view`)??(localStorage.getItem(`ds_default_view`)||`card`);J===`calendar`&&v(e,U,p),W.addEventListener(`click`,()=>{J===`card`?(J=`calendar`,sessionStorage.setItem(`ds_session_view`,`calendar`),W.innerHTML=L,G.hidden=!0,K.hidden=!0,q.hidden=!1,requestAnimationFrame(()=>{q.classList.add(`view-enter`),v(e,U,p),setTimeout(()=>q.classList.remove(`view-enter`),250)})):(J=`card`,sessionStorage.setItem(`ds_session_view`,`card`),W.innerHTML=I,q.hidden=!0,G.hidden=!1,K.hidden=!1,requestAnimationFrame(()=>{let e=g.querySelector(`.wheel-item.active`);e&&(g.scrollLeft=e.offsetLeft-g.offsetWidth/2+e.offsetWidth/2),P?.update(),K.classList.add(`view-enter`),setTimeout(()=>K.classList.remove(`view-enter`),250)}))});let Y;h.addEventListener(`scroll`,()=>{J===`calendar`&&(clearTimeout(Y),Y=setTimeout(()=>{let t=k(h);if(!t)return;let n=parseInt(t.dataset.month,10)-1;n===U.month&&U.year===y||(U.month=n,U.year=y,v(e,U,p))},150))},{passive:!0}),e.querySelector(`#cal-prev-month`).addEventListener(`click`,()=>{--U.month,U.month<0&&(U.month=11,--U.year);let t=e.querySelector(`#mystory-year-label`);t&&(t.textContent=U.year),v(e,U,p),j(U.month+1)}),e.querySelector(`#cal-next-month`).addEventListener(`click`,()=>{if(O(U,p))return;U.month+=1,U.month>11&&(U.month=0,U.year+=1);let t=e.querySelector(`#mystory-year-label`);t&&(t.textContent=U.year),v(e,U,p),j(U.month+1)})}catch(t){console.error(`loadMyStoryData 오류:`,t?.message||t?.code||JSON.stringify(t)),e.innerHTML=`<div class="empty-state"><div class="empty-state-title">오류가 발생했습니다</div></div>`}}function V(e,t){let[n,r,i]=t.split(`-`),a=new Date(parseInt(n,10),parseInt(r,10)-1,parseInt(i,10)),o=a.getMonth()+1,s=a.getDate(),c=a.getFullYear();if(!e)return`
      <div class="flip-container">
        <div class="flipper mystory-flipper">
          <div class="front history-card-front empty-story-card">
            <div class="empty-story-day-circle">${s}</div>
            <div class="empty-story-title">이 날의 기록이 없습니다.</div>
            <div class="empty-story-date">${`${[`JAN`,`FEB`,`MAR`,`APR`,`MAY`,`JUN`,`JUL`,`AUG`,`SEP`,`OCT`,`NOV`,`DEC`][a.getMonth()]} ${s}, ${c}`}</div>
            <button class="btn btn-primary mystory-write-btn" data-date="${t}">
              + 나의 일화 쓰기
            </button>
          </div>
        </div>
      </div>
    `;let[l,u,d]=String(e.publish_date||t).split(`-`),f=parseInt(l,10)||c,p=parseInt(u,10)||o,m=parseInt(d,10)||s,h=e.image_url||``,g=h?`src="${_(h)}"`:``,v=(e.body||``).split(/\n|\\n/).map(e=>e.trim()?`<p>${_(e)}</p>`:`<p><br></p>`).join(``),y=R(e);return`
    <div class="flip-container">
      <div class="flipper mystory-flipper">
        <!-- 앞면 -->
        <div class="front history-card-front">
          <div class="history-card-top">
            <div class="card-top-left">
              <div class="card-year mystory-card-year">${f}</div>
              <div class="card-date">${p}. ${m}</div>
            </div>
            <div class="card-top-right">
              <div class="card-actions">
                <button class="card-action-btn share-my-story-btn" data-id="${_(e.id)}" aria-label="공유">
                  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                    <circle cx="18" cy="5" r="3"/><circle cx="6" cy="12" r="3"/><circle cx="18" cy="19" r="3"/>
                    <line x1="8.59" y1="13.51" x2="15.42" y2="17.49"/><line x1="15.41" y1="6.51" x2="8.59" y2="10.49"/>
                  </svg>
                </button>
                <button class="card-action-btn edit-my-story-btn" data-id="${_(e.id)}" aria-label="수정">
                  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                    <path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"></path>
                    <path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"></path>
                  </svg>
                </button>
              </div>
              <div class="card-meta">${_(y)}</div>
            </div>
          </div>
          <div class="history-card-image-wrap">
            <img ${g} alt="${_(e.title)}" loading="lazy" decoding="async" width="320" height="400" draggable="false" />
            <div class="card-image-title">${_(e.title)}</div>
          </div>
        </div>
        <!-- 뒷면 -->
        <div class="back history-card-back">
          <div class="back-title">${_(e.title)}</div>
          <hr class="back-divider" />
          <div class="back-body">${v}</div>
          <div class="back-footer">
            <div class="back-date">${f}년 ${p}월 ${m}일</div>
          </div>
        </div>
      </div>
    </div>
  `}function H(e,t,n){let r=e.querySelector(`.flipper`);if(!r||e.dataset.bound===`1`)return;e.dataset.bound=`1`,e.querySelectorAll(`.history-card-image-wrap img`).forEach(e=>{e.classList.add(`card-img-fade`),e.complete&&e.naturalWidth>0?e.classList.add(`img-loaded`):(e.addEventListener(`load`,()=>e.classList.add(`img-loaded`),{once:!0}),e.addEventListener(`error`,()=>e.classList.add(`img-loaded`),{once:!0}))});let a=e.querySelector(`.mystory-write-btn`),o=e.querySelector(`.share-my-story-btn`),c=e.querySelector(`.edit-my-story-btn`),l=()=>{let e=s(`user`)||{};return d?.currentUser?.uid||e.id?!0:(g(`로그인이 필요한 서비스입니다.`,`error`),location.hash=`#/login`,!1)};a&&a.addEventListener(`click`,e=>{e.stopPropagation(),l()&&i(`/mystory/new?date=`+a.dataset.date)}),o&&t&&o.addEventListener(`click`,async e=>{e.stopPropagation(),l()&&await h(t,{kind:`mystory`,includeImage:!1})}),c&&c.addEventListener(`click`,e=>{e.stopPropagation(),l()&&i(`/mystory/new?edit=`+c.dataset.id)}),r.addEventListener(`click`,e=>{t&&(e.target.closest(`button`)||r.classList.contains(`is-flipping`)||(r.classList.add(`is-flipping`),r.classList.toggle(`flipped`),setTimeout(()=>r.classList.remove(`is-flipping`),400)))})}function U(){let n=document.createElement(`div`);n.className=`mystory-new-page page`;let r=s(`user`)||{},a=d?.currentUser?.uid||r.id;if(!a)return n.innerHTML=`
      ${M({title:`권한 없음`,backLabel:`뒤로`})}
      <div class="empty-state" style="padding-top: 100px;">
        <div class="empty-state-title">로그인이 필요합니다</div>
        <div class="empty-state-desc">나의 일화를 작성하려면 로그인해주세요.</div>
        <button class="btn btn-primary" style="margin-top: 16px;" id="ms-no-auth-back">뒤로 가기</button>
      </div>
    `,setTimeout(()=>{N(n,()=>history.back()),document.getElementById(`ms-no-auth-back`)?.addEventListener(`click`,()=>history.back())},0),n;let h=r,_=o(),v=_.edit||null,T=_.date||new Date().toISOString().split(`T`)[0],O=null;return n.innerHTML=`
    ${M({title:v?`나의 일화 수정`:`나의 일화 쓰기`,backLabel:`뒤로`})}

    <div class="editor-form-section section mystory-form-section">
      <form id="mystory-form" class="story-form">
        <!-- 1. 날짜 -->
        <div class="input-group">
          <label class="input-label">날짜 *</label>
          <input class="input-field" type="date" id="ms-date" required style="text-align:left; -webkit-appearance:none; appearance:none;" />
        </div>
        <!-- 2. 카드 이미지 -->
        <div class="input-group">
          <input type="hidden" id="ms-image" />
          <input type="hidden" id="ms-image-thumb" />
          <div id="ms-image-upload-area" class="ms-image-upload-area" role="button" tabindex="0" aria-label="카드 이미지 업로드">
            <div id="ms-image-placeholder" class="ms-image-upload-placeholder">
              <svg viewBox="0 0 24 24" width="52" height="52" fill="none" stroke="currentColor" stroke-width="1.3" stroke-linecap="round" stroke-linejoin="round">
                <rect x="3" y="3" width="18" height="18" rx="2"/>
                <circle cx="8.5" cy="8.5" r="1.5"/>
                <polyline points="21 15 16 10 5 21"/>
                <line x1="12" y1="7" x2="12" y2="12"/>
                <line x1="9.5" y1="9.5" x2="12" y2="7"/>
                <line x1="14.5" y1="9.5" x2="12" y2="7"/>
              </svg>
              <span>카드 이미지 업로드</span>
            </div>
            <img id="ms-image-preview" class="ms-image-upload-preview" style="display:none;" alt="카드 이미지 미리보기" />
          </div>
        </div>
        <!-- 3. 단일 제목 -->
        <div class="input-group">
          <label class="input-label">제목</label>
          <input class="input-field" id="ms-title" placeholder="일화 제목을 입력하세요" />
        </div>
        <!-- 4. 본문 -->
        <div class="input-group">
          <label class="input-label">본문</label>
          <textarea class="input-field" id="ms-body" placeholder="본문을 입력하세요..." style="min-height:250px; resize:vertical; line-height:1.6; font-family:var(--font-body);"></textarea>
        </div>
        ${v?`
          <!-- 편집 모드: 폼 하단 우측에 삭제 버튼 배치 -->
          <div class="mystory-form-inline-actions">
            <button type="button" class="btn btn-secondary mystory-form-delete-btn" id="delete-my-story-edit">삭제</button>
          </div>
        `:``}
      </form>
    </div>

    <!-- 화면 하단 floating 액션 영역 (저장 버튼) -->
    <div class="mystory-form-actions">
      <button type="submit" form="mystory-form" id="ms-save-btn" class="btn btn-primary btn-full">저장하기</button>
    </div>
  `,setTimeout(async()=>{function r(){return v?O?(document.getElementById(`ms-title`)?.value??``)!==O.title||(document.getElementById(`ms-body`)?.value??``)!==O.body||(document.getElementById(`ms-date`)?.value??``)!==O.date||(document.getElementById(`ms-image`)?.value??``)!==O.image_url:!1:!!(document.getElementById(`ms-title`)?.value.trim()||document.getElementById(`ms-body`)?.value.trim()||document.getElementById(`ms-image`)?.value)}async function o(){r()&&!await E({title:`저장하지 않고 나가기`,message:`작성 중인 내용이 저장되지 않습니다.
나가시겠습니까?`,confirmText:`나가기`,cancelText:`취소`})||history.back()}if(N(n,o),f.isNativePlatform()){let e=await S.addListener(`backButton`,o);window.addEventListener(`hashchange`,()=>e.remove(),{once:!0})}let s=document.getElementById(`ms-date`);s&&(s.value=T);let d=[];try{d=await b(a)}catch{}if(s?.addEventListener(`change`,e=>{let t=e.target.value;t&&d.find(e=>e.publish_date===t&&String(e.id)!==String(v))&&(g(`이미 등록된 일화가 있는 날짜입니다.`,`error`),e.target.value=``)}),v){let e=await x(v,h.id);e&&(document.getElementById(`ms-title`).value=e.title||``,document.getElementById(`ms-date`).value=e.publish_date||T,document.getElementById(`ms-body`).value=e.body||``,document.getElementById(`ms-image`).value=e.image_url||``,document.getElementById(`ms-image-thumb`).value=e.image_thumb_url||``,z(e.image_url||``),O={title:e.title||``,body:e.body||``,date:e.publish_date||T,image_url:e.image_url||``})}document.getElementById(`delete-my-story-edit`)?.addEventListener(`click`,async()=>{if(v&&await E({title:`일화 삭제`,message:`이 일화를 삭제하시겠습니까?
삭제한 일화는 복구할 수 없습니다.`,confirmText:`삭제`,cancelText:`취소`,danger:!0}))try{await j(v);let e=document.getElementById(`ms-date`)?.value||T;w(d.filter(e=>String(e.id)!==String(v))),g(`일화가 삭제되었습니다.`,`success`),i(`/mystory`,{date:e})}catch{g(`삭제 중 오류가 발생했습니다.`,`error`)}}),document.getElementById(`mystory-form`);async function _(e,t=!1,n){let r=e;if(t){if(!m(e)){g(`외부 이미지는 편집할 수 없습니다.
[사진 추가]로 새 이미지를 업로드해주세요.`,`error`);return}try{let t=new URL(e).pathname.split(`/o/`)[1]||``,n=await c(l(u,decodeURIComponent(t.split(`?`)[0])));r=URL.createObjectURL(n)}catch(e){console.error(`이미지 fetch 실패:`,e),g(`이미지를 불러올 수 없습니다. 다시 시도해주세요.`,`error`);return}}let i=document.createElement(`div`);i.className=`crop-modal-overlay`,i.innerHTML=`
        <div class="crop-modal-header">
          <button type="button" class="crop-modal-back-btn" id="btn-crop-back" aria-label="닫기">
            <svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
              <line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/>
            </svg>
          </button>
          카드 이미지 편집
        </div>
        <div class="crop-modal-body">
          <img id="cropper-image" src="${r}" style="max-width: 100%; display: block;" />
        </div>
        <div class="crop-modal-footer">
          <button type="button" class="btn-rotate" id="btn-crop-rotate">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
              <path d="M21 2v6h-6"/>
              <path d="M21 8A9 9 0 1 1 5.82 5.82"/>
            </svg>
            회전
          </button>
          <button type="button" class="btn-crop-confirm" id="btn-crop-confirm">완료</button>
        </div>
      `,(document.querySelector(`.mobile-wrapper`)||document.body).appendChild(i),k(),i.querySelector(`#btn-crop-back`).addEventListener(`click`,()=>{i.style.opacity=`0`,y(),setTimeout(()=>{o&&o.destroy(),t&&r.startsWith(`blob:`)&&URL.revokeObjectURL(r),i.remove()},300)}),setTimeout(()=>i.style.opacity=`1`,10);let a=i.querySelector(`#cropper-image`),o;a.onload=()=>{o=new P.default(a,{aspectRatio:F,viewMode:1,dragMode:`move`,autoCropArea:.9,restore:!1,guides:!0,center:!0,highlight:!1,cropBoxMovable:!0,cropBoxResizable:!0,toggleDragModeOnDblclick:!1})},a.onerror=()=>{g(`이미지를 불러올 수 없어 편집이 제한됩니다.`,`error`),t&&r.startsWith(`blob:`)&&URL.revokeObjectURL(r),y(),i.remove()},i.querySelector(`#btn-crop-rotate`).addEventListener(`click`,()=>{o&&o.rotate(90)}),i.querySelector(`#btn-crop-confirm`).addEventListener(`click`,()=>{let e=i.querySelector(`#btn-crop-confirm`);e.textContent=`처리 중...`,e.disabled=!0,o&&o.getCroppedCanvas({maxWidth:1200,maxHeight:1500,imageSmoothingEnabled:!0,imageSmoothingQuality:`high`}).toBlob(async a=>{if(!a){g(`크롭 오류가 발생했습니다.`,`error`),e.textContent=`다음`,e.disabled=!1;return}i.style.opacity=`0`,y(),setTimeout(()=>{o.destroy(),t&&r.startsWith(`blob:`)&&URL.revokeObjectURL(r),i.remove()},300),n(a)},`image/jpeg`,.85)})}function A(){let e=document.getElementById(`ms-save-btn`);e&&(e.disabled=!0,e.style.opacity=`0.5`,e.innerHTML=`<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="animation:ms-spin 1s linear infinite;flex-shrink:0;"><path d="M21 12a9 9 0 1 1-6.219-8.56"/></svg>업로드 중...`)}function M(){let e=document.getElementById(`ms-save-btn`);e&&(e.disabled=!1,e.style.opacity=``,e.innerHTML=`<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="flex-shrink:0;"><path d="M20 6 9 17l-5-5"/></svg>업로드 완료!`,setTimeout(()=>{e&&(e.innerHTML=`저장하기`)},2e3))}function I(){let e=document.getElementById(`ms-save-btn`);e&&(e.disabled=!1,e.style.opacity=``,e.innerHTML=`저장하기`)}async function L(e,t){if(document.getElementById(`ms-image`))try{if(A(),!a){g(`로그인이 필요합니다.`,`error`);return}e.name=t;let{image_url:n}=await p(e,{uid:a,folder:`diary`}),r=document.getElementById(`ms-image`),i=document.getElementById(`ms-image-thumb`);r&&(r.value=n),i&&(i.value=``),M(),z(n)}catch(e){console.error(`이미지 업로드 오류:`,e),I(),g(`이미지 저장에 실패했습니다.`,`error`)}}function z(e){let t=document.getElementById(`ms-image-placeholder`),n=document.getElementById(`ms-image-preview`);!t||!n||(e?(t.style.display=`none`,n.src=e,n.style.display=`block`):(t.style.display=``,n.src=``,n.style.display=`none`))}async function B(){try{let t=await e();if(!t)return;_(t.dataUrl,!1,e=>{L(e,`image.jpeg`)})}catch(e){if(e instanceof t){g(e.message,`warning`);return}g(e?.message||`사진을 불러올 수 없습니다.`,`error`)}}let V=document.getElementById(`ms-image-upload-area`);V?.addEventListener(`click`,B),V?.addEventListener(`keydown`,e=>{(e.key===`Enter`||e.key===` `)&&(e.preventDefault(),B())}),document.getElementById(`mystory-form`)?.addEventListener(`submit`,async e=>{if(e.preventDefault(),document.getElementById(`ms-save-btn`)?.disabled){g(`사진 업로드가 완료될 때까지 기다려주세요`,`warning`);return}let t={uid:a,title:document.getElementById(`ms-title`).value.trim(),publish_date:document.getElementById(`ms-date`).value,body:document.getElementById(`ms-body`).value.trim(),image_url:document.getElementById(`ms-image`).value.trim(),image_thumb_url:document.getElementById(`ms-image-thumb`)?.value.trim()||``,author_nickname:R()};if(!t.publish_date)return g(`날짜를 입력해주세요`,`warning`);if(!t.image_url)return g(`카드 이미지를 추가해주세요`,`warning`);try{v?(await D(v,t),g(`일화가 수정되었습니다`,`success`)):(await C(t),g(`새 일화가 작성되었습니다`,`success`)),w(v?[...d.filter(e=>String(e.id)!==String(v)),{...t,id:v}]:[...d,t]),i(`/mystory`,{date:t.publish_date})}catch{g(`저장 중 오류 발생`,`error`)}})},0),n}export{z as renderMyStory,U as renderMyStoryNew};