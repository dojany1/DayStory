import{a as e,i as t,n,r,t as i}from"./cropper-DfNRxLcH.js";import{a,r as o}from"./router-hybKseu2.js";import{n as s}from"./state-8PRbPWwW.js";import{a as c,r as l,s as u,t as d}from"./firebase-CMykNrkF.js";import{t as f}from"./dist-N3LOKtlT.js";import{l as p}from"./stories-DjoDJ8Ga.js";import{r as m}from"./storyI18n-D4h3I9Tp.js";import{t as h}from"./toast-DL5HJnQ3.js";import{t as g}from"./sanitize-DlMVmTsh.js";import{n as _,t as v}from"./scrollLock-ByagqdMz.js";import{a as y,c as b,d as x,f as S,i as C,l as w,n as T,o as E,s as D,t as O,u as k}from"./index-DD1nP3bp.js";import{n as A,t as j}from"./pageHeader-CzG3S3Fi.js";var M=e(i(),1),N=4/5,P=`<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M2 7v10"/><path d="M6 5v14"/><rect width="12" height="18" x="10" y="3" rx="2"/></svg>`,F=`<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M8 2v4"/><path d="M16 2v4"/><rect width="18" height="18" x="3" y="4" rx="2"/><path d="M3 10h18"/><path d="M8 14h.01"/><path d="M12 14h.01"/><path d="M16 14h.01"/><path d="M8 18h.01"/><path d="M12 18h.01"/><path d="M16 18h.01"/></svg>`,I=0,L=1500,R=560;function z(e={}){let t=s(`profile`)||{},n=s(`user`)||{},r=typeof n.email==`string`?n.email.split(`@`)[0]:``;return[e.author_nickname,e.authorNickname,e.author?.nickname,e.author?.displayName,t.nickname,n.displayName,r].map(e=>typeof e==`string`?e.trim():``).find(Boolean)||`사용자`}function B(){let e=document.createElement(`div`);e.className=`mystory-page page`;let t=sessionStorage.getItem(`ds_session_view`)??(localStorage.getItem(`ds_default_view`)||`card`);return e.innerHTML=`
    <!-- 휠 피커 스타일 날짜 선택기 -->
    <div class="wheel-pickers-container">
      <div class="wheel-year-label" id="mystory-year-label">${new Date().getFullYear()}</div>
      <!-- 월 피커 -->
      <div class="wheel-picker-wrapper">
        <div class="wheel-selection-box"></div>
        <div class="modern-wheel-scroll" id="mystory-month-scroll"></div>
        <button type="button" class="view-toggle-btn" id="mystory-view-toggle" aria-label="보기 방식 변경">${t===`calendar`?F:P}</button>
      </div>
      <!-- 일 피커 -->
      <div class="wheel-picker-wrapper" id="mystory-day-picker">
        <div class="wheel-selection-box"></div>
        <div class="modern-wheel-scroll" id="mystory-calendar"></div>
      </div>
    </div>

    <!-- 카드 렌더링 영역 (editorstory.js와 동일한 구조) -->
    <div class="editorstory-card-area" id="mystory-card-area">
      <div style="display:flex;justify-content:center;padding:var(--space-8);width:100%;">
        <div class="loading-spinner"></div>
      </div>
    </div>

    <div class="page-calendar-view" id="mystory-cal-view" hidden>
      <div class="calendar-month-nav">
        <button type="button" class="calendar-month-arrow" id="cal-prev-month" aria-label="이전 달">
          <svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" stroke-width="2"><polyline points="15 18 9 12 15 6"/></svg>
        </button>
        <div class="calendar-month-label" id="cal-month-label">—</div>
        <button type="button" class="calendar-month-arrow" id="cal-next-month" aria-label="다음 달">
          <svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" stroke-width="2"><polyline points="9 18 15 12 9 6"/></svg>
        </button>
      </div>
      <div class="calendar-weekdays">
        ${O.map((e,t)=>`<div class="calendar-weekday ${t===0?`sun`:t===6?`sat`:``}">${e}</div>`).join(``)}
      </div>
      <div class="calendar-grid" id="calendar-grid">
        <div class="calendar-grid-loading"><div class="loading-spinner"></div></div>
      </div>
    </div>
  `,t===`calendar`&&(e.querySelector(`#mystory-day-picker`).hidden=!0,e.querySelector(`#mystory-card-area`).hidden=!0,e.querySelector(`#mystory-cal-view`).hidden=!1),V(e),e}async function V(e){I=0;try{let t=s(`user`)||{id:`guest`},n=await b(d?.currentUser?.uid||t.id);x(n);let r=o(),i=new Date,a=new Date(i.getTime()-i.getTimezoneOffset()*6e4).toISOString().split(`T`)[0],[c,l,u]=a.split(`-`),f=new Date(parseInt(c),parseInt(l)-1,parseInt(u)),p=r.date||a,[m,h,g]=p.split(`-`),_=new Date(parseInt(m),parseInt(h)-1,parseInt(g)),v=_,y=e.querySelector(`#mystory-month-scroll`),S=e.querySelector(`#mystory-calendar`),w=e.querySelector(`#mystory-card-area`),E=f.getFullYear(),D=f.getMonth()+1,O=f.getDate();if(y&&(y.innerHTML=Array.from({length:12},(e,t)=>{let n=t+1;return`<div class="wheel-item${n>D?` disabled`:``}" data-month="${n}">${n}</div>`}).join(``)),S){let e=[];for(let t=1;t<=D;t++){let n=t===D?O:new Date(E,t,0).getDate();for(let r=1;r<=n;r++){let n=String(t).padStart(2,`0`),i=String(r).padStart(2,`0`);e.push(`<div class="wheel-item" data-date="${E}-${n}-${i}" data-month="${t}" data-day="${r}">${r}</div>`)}}S.innerHTML=e.join(``)}function k(e){let t=e.getBoundingClientRect().left+e.offsetWidth/2,n=null,r=1/0;return e.querySelectorAll(`.wheel-item:not(.disabled)`).forEach(e=>{let i=e.getBoundingClientRect().left+e.offsetWidth/2,a=Math.abs(t-i);a<r&&(r=a,n=e)}),n}function A(e){let t=y.querySelector(`.wheel-item.active`);if(t&&parseInt(t.dataset.month,10)===e)return;let n=y.querySelector(`.wheel-item[data-month="${e}"]`);if(!n)return;y.querySelectorAll(`.wheel-item`).forEach(e=>e.classList.remove(`active`)),n.classList.add(`active`);let r=n.offsetLeft-y.offsetWidth/2+n.offsetWidth/2;y.scrollTo({left:r,behavior:`smooth`})}function j(e=!1){let t;if(e?t=S.querySelector(`.wheel-item.active`):(t=k(S),t&&(S.querySelectorAll(`.wheel-item`).forEach(e=>e.classList.remove(`active`)),t.classList.add(`active`))),!t)return;A(parseInt(t.dataset.month,10));let r=t.dataset.date,i=new Date(E,parseInt(t.dataset.month,10)-1,parseInt(t.dataset.day,10));if(v&&v.getTime()===i.getTime())return;let a=n.find(e=>e.publish_date===r),o=i>v?`next`:`prev`;v=i,H(w,a||null,i,r,o,n)}let M;S.addEventListener(`scroll`,()=>{clearTimeout(M),M=setTimeout(()=>{j(!1)},150)},{passive:!0});let N;y.addEventListener(`scroll`,()=>{U===`card`&&(clearTimeout(N),N=setTimeout(()=>{let e=k(y);if(!e||e.classList.contains(`disabled`))return;let t=S.querySelector(`.wheel-item.active`),n=t?parseInt(t.dataset.month,10):-1;parseInt(e.dataset.month,10)===n?(y.querySelectorAll(`.wheel-item`).forEach(e=>e.classList.remove(`active`)),e.classList.add(`active`)):I(e)},150))},{passive:!0});let I=e=>{if(e.classList.contains(`disabled`))return;let t=parseInt(e.dataset.month,10),n=t===D?String(O).padStart(2,`0`):`01`,r=`${E}-${String(t).padStart(2,`0`)}-${n}`,i=S.querySelector(`.wheel-item[data-date="${r}"]`);if(!i)return;S.querySelectorAll(`.wheel-item`).forEach(e=>e.classList.remove(`active`)),i.classList.add(`active`),y.querySelectorAll(`.wheel-item`).forEach(e=>e.classList.remove(`active`)),e.classList.add(`active`),clearTimeout(M);let a=i.offsetLeft-S.offsetWidth/2+i.offsetWidth/2;S.scrollTo({left:a,behavior:`smooth`});let o=e.offsetLeft-y.offsetWidth/2+e.offsetWidth/2;y.scrollTo({left:o,behavior:`smooth`}),j(!0)},L=e=>{S.querySelectorAll(`.wheel-item`).forEach(e=>e.classList.remove(`active`)),e.classList.add(`active`),clearTimeout(M),j(!0);let t=e.offsetLeft-S.offsetWidth/2+e.offsetWidth/2;S.scrollTo({left:t,behavior:`smooth`})};y.querySelectorAll(`.wheel-item`).forEach(e=>e.addEventListener(`click`,()=>I(e))),S.querySelectorAll(`.wheel-item`).forEach(e=>e.addEventListener(`click`,()=>L(e))),setTimeout(()=>{requestAnimationFrame(()=>{let e=p,t=S.querySelector(`.wheel-item[data-date="${e}"]`),n=_.getMonth()+1,r=y.querySelector(`.wheel-item[data-month="${n}"]`);t&&(t.classList.add(`active`),B.hidden||(S.scrollLeft=t.offsetLeft-S.offsetWidth/2+t.offsetWidth/2)),r&&(r.classList.add(`active`),y.scrollLeft=r.offsetLeft-y.offsetWidth/2+r.offsetWidth/2)})},0),H(w,n.find(e=>e.publish_date===p)||null,_,p,null,n);let R={mode:`mine`,year:E,month:f.getMonth(),historyStories:[],myStories:n,bookmarkedIds:[]},z=e.querySelector(`#mystory-view-toggle`),B=e.querySelector(`#mystory-day-picker`),V=e.querySelector(`#mystory-cal-view`),U=sessionStorage.getItem(`ds_session_view`)??(localStorage.getItem(`ds_default_view`)||`card`);U===`calendar`&&C(e,R,f),z.addEventListener(`click`,()=>{U===`card`?(U=`calendar`,sessionStorage.setItem(`ds_session_view`,`calendar`),z.innerHTML=F,B.hidden=!0,w.hidden=!0,V.hidden=!1,requestAnimationFrame(()=>{V.classList.add(`view-enter`),C(e,R,f),setTimeout(()=>V.classList.remove(`view-enter`),250)})):(U=`card`,sessionStorage.setItem(`ds_session_view`,`card`),z.innerHTML=P,V.hidden=!0,B.hidden=!1,w.hidden=!1,requestAnimationFrame(()=>{let e=S.querySelector(`.wheel-item.active`);e&&(S.scrollLeft=e.offsetLeft-S.offsetWidth/2+e.offsetWidth/2),j(!0),w.classList.add(`view-enter`),setTimeout(()=>w.classList.remove(`view-enter`),250)}))});let W;y.addEventListener(`scroll`,()=>{U===`calendar`&&(clearTimeout(W),W=setTimeout(()=>{let t=k(y);if(!t)return;let n=parseInt(t.dataset.month,10)-1;n===R.month&&R.year===E||(R.month=n,R.year=E,C(e,R,f))},150))},{passive:!0}),e.querySelector(`#cal-prev-month`).addEventListener(`click`,()=>{--R.month,R.month<0&&(R.month=11,--R.year);let t=e.querySelector(`#mystory-year-label`);t&&(t.textContent=R.year),C(e,R,f),A(R.month+1)}),e.querySelector(`#cal-next-month`).addEventListener(`click`,()=>{if(T(R,f))return;R.month+=1,R.month>11&&(R.month=0,R.year+=1);let t=e.querySelector(`#mystory-year-label`);t&&(t.textContent=R.year),C(e,R,f),A(R.month+1)})}catch(t){console.error(`loadMyStoryData 오류:`,t?.message||t?.code||JSON.stringify(t)),e.innerHTML=`<div class="empty-state"><div class="empty-state-title">오류가 발생했습니다</div></div>`}}function H(e,t,n,r,i=null,a){if(!e)return;let o=Array.from(e.querySelectorAll(`.flip-container`)),s=o.pop()||null;o.forEach(e=>e.remove());let c=n.getMonth()+1,l=n.getDate(),u=n.getFullYear(),d=document.createElement(`div`);if(d.className=`flip-container`,d.id=`card-${Date.now()}`,!t)d.innerHTML=`
      <div class="flipper mystory-flipper">
        <div class="front history-card-front empty-story-card">
          <div class="empty-story-day-circle">${l}</div>
          <div class="empty-story-title">이 날의 기록이 없습니다.</div>
          <div class="empty-story-date">${`${[`JAN`,`FEB`,`MAR`,`APR`,`MAY`,`JUN`,`JUL`,`AUG`,`SEP`,`OCT`,`NOV`,`DEC`][n.getMonth()]} ${l}, ${u}`}</div>
          
          <button class="btn btn-primary mystory-write-btn" data-date="${r}">
            + 나의 일화 쓰기
          </button>
        </div>
      </div>
    `;else{let[e,n,i]=String(t.publish_date||r).split(`-`),a=parseInt(e,10)||u,o=parseInt(n,10)||c,s=parseInt(i,10)||l,f=t.image_url||``,p=f?`src="${g(f)}"`:``,m=(t.body||``).split(/\n|\\n/).map(e=>e.trim()?`<p>${g(e)}</p>`:`<p><br></p>`).join(``),h=z(t);d.innerHTML=`
      <div class="flipper mystory-flipper">
        <!-- 앞면 -->
        <div class="front history-card-front">
          <div class="history-card-top">
            <div class="card-top-left">
              <div class="card-year mystory-card-year">${a}</div>
              <div class="card-date">${o}. ${s}</div>
            </div>
            <div class="card-top-right">
              <div class="card-actions">
                <button class="card-action-btn share-my-story-btn" data-id="${g(t.id)}" aria-label="공유">
                  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                    <circle cx="18" cy="5" r="3"/><circle cx="6" cy="12" r="3"/><circle cx="18" cy="19" r="3"/>
                    <line x1="8.59" y1="13.51" x2="15.42" y2="17.49"/><line x1="15.41" y1="6.51" x2="8.59" y2="10.49"/>
                  </svg>
                </button>
                <button class="card-action-btn edit-my-story-btn" data-id="${g(t.id)}" aria-label="수정">
                  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                    <path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"></path>
                    <path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"></path>
                  </svg>
                </button>
              </div>
              <div class="card-meta">${g(h)}</div>
            </div>
          </div>
          <div class="history-card-image-wrap">
            <img ${p} alt="${g(t.title)}" loading="eager" decoding="async" width="320" height="400" draggable="false" />
            <div class="card-image-title">${g(t.title)}</div>
          </div>
        </div>
        <!-- 뒷면 -->
        <div class="back history-card-back">
          <div class="back-title">${g(t.title)}</div>
          <hr class="back-divider" />
          <div class="back-body">${m}</div>
          <div class="back-footer">
            <div class="back-date">${a}년 ${o}월 ${s}일</div>
          </div>
        </div>
      </div>
    `}if(!i||!s){e.innerHTML=``,e.appendChild(d),U(d,t,n,a);return}s.classList.add(`card-stack-item`,`stack-exit-${i}`),d.classList.add(`card-stack-item`,`stack-enter-${i}`),e.appendChild(d),d.offsetWidth,d.classList.add(`active`);let f=()=>{s.parentNode&&s.remove(),d.classList.remove(`card-stack-item`,`stack-enter-${i}`,`active`),U(d,t,n,a)};d.addEventListener(`transitionend`,f,{once:!0}),setTimeout(()=>{d.classList.contains(`card-stack-item`)&&f()},R)}function U(e,t,n,r){let i=e.querySelector(`.flipper`);if(!i)return;let o=e.querySelector(`.mystory-write-btn`),c=e.querySelector(`.share-my-story-btn`),l=e.querySelector(`.edit-my-story-btn`),u=()=>{let e=s(`user`)||{},t=d?.currentUser?.uid||e.id;return!t||t===`guest`?(h(`로그인이 필요한 서비스입니다.`,`error`),location.hash=`#/login`,!1):!0};o&&o.addEventListener(`click`,e=>{e.stopPropagation(),u()&&a(`/mystory/new?date=`+o.dataset.date)}),c&&t&&c.addEventListener(`click`,async e=>{e.stopPropagation(),u()&&await m(t,{kind:`mystory`,includeImage:!1})}),l&&l.addEventListener(`click`,e=>{e.stopPropagation(),u()&&a(`/mystory/new?edit=`+l.dataset.id)});let f=0,p=0,g=!1,_=null,v=!1,y=!1,b=0,x=0,S=0,C=0,w=null,T=(e,t,n=!1)=>{v||i.classList.contains(`is-flipping`)||(f=e,p=t,g=!1,_=null,y=n,x=Date.now(),S=e,C=t)},E=async(e,t,n=!1)=>{if(v)return;let r=e-f,a=t-p;if((Math.abs(r)>15||Math.abs(a)>15)&&(w=null),!_){if(Math.abs(r)<15&&Math.abs(a)<15)return;_=Math.abs(r)>Math.abs(a)?`x`:`y`}if(_===`y`)return;g||=(i.style.transition=`none`,!0);let o=i.classList.contains(`flipped`)?`rotateY(180deg)`:``;if(_===`x`){let e=r*.62;i.style.transform=`translateX(${e}px) ${o}`}},D=async(e,t)=>{if(!g||v)return;v=!0;let n=e-f;if(i.style.transition=`transform 220ms cubic-bezier(0.16, 1, 0.3, 1)`,i.classList.add(`is-flipping`),_===`x`&&Math.abs(n)>64){if(y){i.style.transform=``,setTimeout(()=>{i.style.transition=``,i.classList.remove(`is-flipping`),g=!1,v=!1},220);return}if(Date.now()-I>=L){I=Date.now();let e=n<0?1:-1,t=document.getElementById(`mystory-calendar`);if(t){let n=Array.from(t.querySelectorAll(`.wheel-item`)),r=n[n.findIndex(e=>e.classList.contains(`active`))+e];r&&r.click()}}}i.style.transform=``,setTimeout(()=>{i.style.transition=``,i.classList.remove(`is-flipping`),g=!1,v=!1},220)};i.addEventListener(`touchstart`,e=>{b=Date.now();let t=!!e.target.closest(`.back-body`);w=e.target,T(e.touches[0].clientX,e.touches[0].clientY,t)},{passive:!0}),i.addEventListener(`touchmove`,e=>{E(e.touches[0].clientX,e.touches[0].clientY,!0),g&&e.preventDefault()},{passive:!1}),i.addEventListener(`touchend`,async e=>{b=Date.now();let n=e.changedTouches[0].clientX,r=e.changedTouches[0].clientY;if(w&&w.closest(`.back-body`)&&!g){let e=Date.now()-x,a=Math.abs(n-S),o=Math.abs(r-C);if(e<=400&&a<=20&&o<=20){if(!t||i.classList.contains(`is-flipping`))return;i.classList.add(`is-flipping`),i.classList.toggle(`flipped`),setTimeout(()=>{i.classList.remove(`is-flipping`)},400);return}}D(n,r)});let O=!1;i.addEventListener(`mousedown`,e=>{if(Date.now()-b<650||e.target.closest(`button`))return;let t=!!e.target.closest(`.back-body`);t||(O=!0,T(e.clientX,e.clientY,t))}),window._myStoryMouseMove&&window.removeEventListener(`mousemove`,window._myStoryMouseMove),window._myStoryMouseUp&&window.removeEventListener(`mouseup`,window._myStoryMouseUp),window._myStoryMouseMove=e=>{O&&E(e.clientX,e.clientY)},window._myStoryMouseUp=e=>{O&&(O=!1,D(e.clientX,e.clientY))},window.addEventListener(`mousemove`,window._myStoryMouseMove),window.addEventListener(`mouseup`,window._myStoryMouseUp),i.addEventListener(`click`,async e=>{t&&(e.target.closest(`button`)||g||e.pointerType===`touch`&&e.target.closest(`.back-body`)||i.classList.contains(`is-flipping`)||(i.classList.add(`is-flipping`),i.classList.toggle(`flipped`),setTimeout(()=>{i.classList.remove(`is-flipping`)},400)))})}function W(){let e=document.createElement(`div`);e.className=`mystory-new-page page`;let i=s(`user`)||{},m=d?.currentUser?.uid||i.id;if(!m||m===`guest`)return e.innerHTML=`
      ${A({title:`권한 없음`,backLabel:`뒤로`})}
      <div class="empty-state" style="padding-top: 100px;">
        <div class="empty-state-title">로그인이 필요합니다</div>
        <div class="empty-state-desc">나의 일화를 작성하려면 로그인해주세요.</div>
        <button class="btn btn-primary" style="margin-top: 16px;" id="ms-no-auth-back">뒤로 가기</button>
      </div>
    `,setTimeout(()=>{j(e,()=>history.back()),document.getElementById(`ms-no-auth-back`)?.addEventListener(`click`,()=>history.back())},0),e;let g=i,C=o(),T=C.edit||null,O=C.date||new Date().toISOString().split(`T`)[0],P=null;return e.innerHTML=`
    ${A({title:T?`나의 일화 수정`:`나의 일화 쓰기`,backLabel:`뒤로`})}

    <div class="editor-form-section section mystory-form-section">
      <form id="mystory-form" class="story-form">
        <!-- 1. 날짜 -->
        <div class="input-group">
          <label class="input-label">날짜 *</label>
          <input class="input-field" type="date" id="ms-date" required style="text-align:left; -webkit-appearance:none; appearance:none;" />
        </div>
        <!-- 2. 카드 이미지 -->
        <div class="input-group">
          <label class="input-label">카드 이미지 *</label>
          <input type="hidden" id="ms-image" />
          <input type="hidden" id="ms-image-thumb" />
          <div style="display:flex; gap:var(--space-2);">
            <button type="button" id="ms-image-gallery-btn" class="btn btn-secondary" style="cursor:pointer; flex:1; justify-content:center; margin:0; padding:var(--space-2) var(--space-3); font-size:var(--text-sm);">파일</button>
            <button type="button" id="ms-image-camera-btn" class="btn btn-secondary" style="cursor:pointer; flex:1; justify-content:center; margin:0; padding:var(--space-2) var(--space-3); font-size:var(--text-sm);">카메라</button>
          </div>
        </div>
        <!-- 3. 단일 제목 -->
        <div class="input-group">
          <label class="input-label">제목</label>
          <input class="input-field" id="ms-title" placeholder="일화 제목을 입력하세요" />
        </div>
        <!-- 4. 본문 -->
        <div class="input-group">
          <label class="input-label">본문</label>
          <textarea class="input-field" id="ms-body" placeholder="본문을 입력하세요..." style="min-height:250px; resize:vertical; line-height:1.6; font-family:var(--font-body);"></textarea>
        </div>
        ${T?`
          <!-- 편집 모드: 폼 하단 우측에 삭제 버튼 배치 -->
          <div class="mystory-form-inline-actions">
            <button type="button" class="btn btn-secondary mystory-form-delete-btn" id="delete-my-story-edit">삭제</button>
          </div>
        `:``}
      </form>
    </div>

    <!-- 화면 하단 floating 액션 영역 (저장 버튼) -->
    <div class="mystory-form-actions">
      <button type="submit" form="mystory-form" id="ms-save-btn" class="btn btn-primary btn-full">저장하기</button>
    </div>
  `,setTimeout(async()=>{function i(){return T?P?(document.getElementById(`ms-title`)?.value??``)!==P.title||(document.getElementById(`ms-body`)?.value??``)!==P.body||(document.getElementById(`ms-date`)?.value??``)!==P.date||(document.getElementById(`ms-image`)?.value??``)!==P.image_url:!1:!!(document.getElementById(`ms-title`)?.value.trim()||document.getElementById(`ms-body`)?.value.trim()||document.getElementById(`ms-image`)?.value)}async function o(){i()&&!await y({title:`저장하지 않고 나가기`,message:`작성 중인 내용이 저장되지 않습니다.
나가시겠습니까?`,confirmText:`나가기`,cancelText:`취소`})||history.back()}if(j(e,o),f.isNativePlatform()){let e=await S.addListener(`backButton`,o);window.addEventListener(`hashchange`,()=>e.remove(),{once:!0})}let s=document.getElementById(`ms-date`);s&&(s.value=O);let d=[];try{d=await b(m)}catch{}if(s?.addEventListener(`change`,e=>{let t=e.target.value;t&&d.find(e=>e.publish_date===t&&String(e.id)!==String(T))&&(h(`이미 등록된 일화가 있는 날짜입니다.`,`error`),e.target.value=``)}),T){let e=await w(T,g.id);e&&(document.getElementById(`ms-title`).value=e.title||``,document.getElementById(`ms-date`).value=e.publish_date||O,document.getElementById(`ms-body`).value=e.body||``,document.getElementById(`ms-image`).value=e.image_url||``,document.getElementById(`ms-image-thumb`).value=e.image_thumb_url||``,P={title:e.title||``,body:e.body||``,date:e.publish_date||O,image_url:e.image_url||``})}document.getElementById(`delete-my-story-edit`)?.addEventListener(`click`,async()=>{if(T&&await y({title:`일화 삭제`,message:`이 일화를 삭제하시겠습니까?
삭제한 일화는 복구할 수 없습니다.`,confirmText:`삭제`,cancelText:`취소`,danger:!0}))try{await D(T);let e=document.getElementById(`ms-date`)?.value||O;x(d.filter(e=>String(e.id)!==String(T))),h(`일화가 삭제되었습니다.`,`success`),a(`/mystory`,{date:e})}catch{h(`삭제 중 오류가 발생했습니다.`,`error`)}}),document.getElementById(`mystory-form`);async function C(e,t=!1,n){let r=e;if(t){if(!(e.includes(`firebasestorage.googleapis.com`)||e.includes(`.firebasestorage.app`))){h(`외부 이미지는 편집할 수 없습니다.
[사진 추가]로 새 이미지를 업로드해주세요.`,`error`);return}try{let t=new URL(e).pathname.split(`/o/`)[1]||``,n=await c(u(l,decodeURIComponent(t.split(`?`)[0])));r=URL.createObjectURL(n)}catch(e){console.error(`이미지 fetch 실패:`,e),h(`이미지를 불러올 수 없습니다. 다시 시도해주세요.`,`error`);return}}let i=document.createElement(`div`);i.className=`crop-modal-overlay`,i.innerHTML=`
        <div class="crop-modal-header">
          <button type="button" class="crop-modal-back-btn" id="btn-crop-back" aria-label="닫기">
            <svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
              <line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/>
            </svg>
          </button>
          카드 이미지 편집
        </div>
        <div class="crop-modal-body">
          <img id="cropper-image" src="${r}" style="max-width: 100%; display: block;" />
        </div>
        <div class="crop-modal-footer">
          <button type="button" class="btn-rotate" id="btn-crop-rotate">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
              <path d="M21 2v6h-6"/>
              <path d="M21 8A9 9 0 1 1 5.82 5.82"/>
            </svg>
            회전
          </button>
          <button type="button" class="btn-crop-confirm" id="btn-crop-confirm">완료</button>
        </div>
      `,(document.querySelector(`.mobile-wrapper`)||document.body).appendChild(i),v(),i.querySelector(`#btn-crop-back`).addEventListener(`click`,()=>{i.style.opacity=`0`,_(),setTimeout(()=>{o&&o.destroy(),t&&r.startsWith(`blob:`)&&URL.revokeObjectURL(r),i.remove()},300)}),setTimeout(()=>i.style.opacity=`1`,10);let a=i.querySelector(`#cropper-image`),o;a.onload=()=>{o=new M.default(a,{aspectRatio:N,viewMode:1,dragMode:`move`,autoCropArea:.9,restore:!1,guides:!0,center:!0,highlight:!1,cropBoxMovable:!0,cropBoxResizable:!0,toggleDragModeOnDblclick:!1})},a.onerror=()=>{h(`이미지를 불러올 수 없어 편집이 제한됩니다.`,`error`),t&&r.startsWith(`blob:`)&&URL.revokeObjectURL(r),_(),i.remove()},i.querySelector(`#btn-crop-rotate`).addEventListener(`click`,()=>{o&&o.rotate(90)}),i.querySelector(`#btn-crop-confirm`).addEventListener(`click`,()=>{let e=i.querySelector(`#btn-crop-confirm`);e.textContent=`처리 중...`,e.disabled=!0,o&&o.getCroppedCanvas({maxWidth:1200,maxHeight:1500,imageSmoothingEnabled:!0,imageSmoothingQuality:`high`}).toBlob(async a=>{if(!a){h(`크롭 오류가 발생했습니다.`,`error`),e.textContent=`다음`,e.disabled=!1;return}i.style.opacity=`0`,_(),setTimeout(()=>{o.destroy(),t&&r.startsWith(`blob:`)&&URL.revokeObjectURL(r),i.remove()},300),n(a)},`image/jpeg`,.85)})}function A(){let e=document.getElementById(`ms-save-btn`);e&&(e.disabled=!0,e.style.opacity=`0.5`,e.innerHTML=`<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="animation:ms-spin 1s linear infinite;flex-shrink:0;"><path d="M21 12a9 9 0 1 1-6.219-8.56"/></svg>업로드 중...`)}function F(){let e=document.getElementById(`ms-save-btn`);e&&(e.disabled=!1,e.style.opacity=``,e.innerHTML=`<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="flex-shrink:0;"><path d="M20 6 9 17l-5-5"/></svg>업로드 완료!`,setTimeout(()=>{e&&(e.innerHTML=`저장하기`)},2e3))}function I(){let e=document.getElementById(`ms-save-btn`);e&&(e.disabled=!1,e.style.opacity=``,e.innerHTML=`저장하기`)}async function L(e,t){if(document.getElementById(`ms-image`))try{A();let n=m||`guest`;e.name=t;let{image_url:r}=await p(e,{uid:n,folder:`diary`}),i=document.getElementById(`ms-image`),a=document.getElementById(`ms-image-thumb`);i&&(i.value=r),a&&(a.value=``),F()}catch(e){console.error(`이미지 업로드 오류:`,e),I(),h(`이미지 저장에 실패했습니다.`,`error`)}}async function R(e){try{let n=e===`camera`?await r():await t();if(!n)return;C(n.dataUrl,!1,t=>{L(t,e===`camera`?`camera_image.jpeg`:`gallery_image.jpeg`)})}catch(e){let t=e instanceof n;h(e?.message||`사진을 불러올 수 없습니다.`,t?`warning`:`error`)}}document.getElementById(`ms-image-gallery-btn`)?.addEventListener(`click`,()=>R(`gallery`)),document.getElementById(`ms-image-camera-btn`)?.addEventListener(`click`,()=>R(`camera`)),document.getElementById(`mystory-form`)?.addEventListener(`submit`,async e=>{if(e.preventDefault(),document.getElementById(`ms-save-btn`)?.disabled){h(`사진 업로드가 완료될 때까지 기다려주세요`,`warning`);return}let t={uid:m,title:document.getElementById(`ms-title`).value.trim(),publish_date:document.getElementById(`ms-date`).value,body:document.getElementById(`ms-body`).value.trim(),image_url:document.getElementById(`ms-image`).value.trim(),image_thumb_url:document.getElementById(`ms-image-thumb`)?.value.trim()||``,author_nickname:z()};if(!t.publish_date)return h(`날짜를 입력해주세요`,`warning`);if(!t.image_url)return h(`카드 이미지를 추가해주세요`,`warning`);try{T?(await k(T,t),h(`일화가 수정되었습니다`,`success`)):(await E(t),h(`새 일화가 작성되었습니다`,`success`)),x(T?[...d.filter(e=>String(e.id)!==String(T)),{...t,id:T}]:[...d,t]),a(`/mystory`,{date:t.publish_date})}catch{h(`저장 중 오류 발생`,`error`)}})},0),e}export{B as renderMyStory,W as renderMyStoryNew};