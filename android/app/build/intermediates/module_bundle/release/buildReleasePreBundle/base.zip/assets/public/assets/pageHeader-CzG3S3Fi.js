var e=`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="15 18 9 12 15 6"/></svg>`,t=`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M18 6L6 18M6 6l12 12"/></svg>`,n=`<div class="page-header-spacer" aria-hidden="true"></div>`;function r({title:r,titleId:i=``,backLabel:a=`뒤로`,icon:o=`back`,rightAction:s=n}){let c=i?` id="${i}"`:``,l;return l=o===`none`?n:`<button type="button" class="page-header-back" aria-label="${a}">${o===`close`?t:e}</button>`,`
    <div class="page-header page-header-with-back">
      ${l}
      <h1 class="page-header-title"${c}>${r}</h1>
      ${s}
    </div>
  `}function i(e,t){e.querySelector(`.page-header-back`)?.addEventListener(`click`,t)}export{r as n,i as t};