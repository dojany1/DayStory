import{i as e,n as t,o as n,r,t as i}from"./cropper--17xtoOq.js";import{a}from"./router-7m-s0x-D.js";import{n as o,r as s}from"./state-DQ9Huans.js";import{i as c,l,m as u,n as d,r as f,s as p,u as m,x as h}from"./firebase-DFBK8Wgd.js";import{d as g}from"./stories-DtUSAb1-.js";import{t as _}from"./toast-ejGG2_Wi.js";import{t as v}from"./sanitize-BzcRQ1L1.js";import{l as y,u as b}from"./index-CSiNOSFm.js";import{initArchiveSection as x,renderArchiveSection as S}from"./bookmarks-DN2BBi8K.js";import{n as C}from"./pageHeader-JuVe_YlV.js";var w=n(i(),1);function T(){let e=document.createElement(`div`);e.className=`settings-page page`;let t=o(`user`),n=o(`profile`),r=n&&n.role===`editor`,i=r?`<button type="button" id="goto-editor-btn" class="page-header-back" aria-label="콘텐츠 관리"><svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M14.364 13.634a2 2 0 0 0-.506.854l-.837 2.87a.5.5 0 0 0 .62.62l2.87-.837a2 2 0 0 0 .854-.506l4.013-4.009a1 1 0 0 0-3.004-3.004z"/><path d="M14.487 7.858A1 1 0 0 1 14 7V2"/><path d="M20 19.645V20a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h8a2.4 2.4 0 0 1 1.704.706l2.516 2.516"/><path d="M8 18h1"/></svg></button>`:``,s=`<button type="button" id="goto-settings-btn" class="page-header-back" aria-label="설정"><svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12.22 2h-.44a2 2 0 0 0-2 2v.18a2 2 0 0 1-1 1.73l-.43.25a2 2 0 0 1-2 0l-.15-.08a2 2 0 0 0-2.73.73l-.22.38a2 2 0 0 0 .73 2.73l.15.1a2 2 0 0 1 1 1.72v.51a2 2 0 0 1-1 1.74l-.15.09a2 2 0 0 0-.73 2.73l.22.38a2 2 0 0 0 2.73.73l.15-.08a2 2 0 0 1 2 0l.43.25a2 2 0 0 1 1 1.73V20a2 2 0 0 0 2 2h.44a2 2 0 0 0 2-2v-.18a2 2 0 0 1 1-1.73l.43-.25a2 2 0 0 1 2 0l.15.08a2 2 0 0 0 2.73-.73l.22-.39a2 2 0 0 0-.73-2.73l-.15-.08a2 2 0 0 1-1-1.74v-.5a2 2 0 0 1 1-1.74l.15-.09a2 2 0 0 0 .73-2.73l-.22-.38a2 2 0 0 0-2.73-.73l-.15.08a2 2 0 0 1-2 0l-.43-.25a2 2 0 0 1-1-1.73V4a2 2 0 0 0-2-2z"/><circle cx="12" cy="12" r="3"/></svg></button>`;return e.innerHTML=`
    ${C({title:`마이 페이지`,icon:`none`,rightAction:r?`<div class="page-header-actions" style="display:flex;align-items:center;">${i}${s}</div>`:s})}

    <!-- 사용자 정보 카드 (로그인 강제 이후 user 는 항상 존재) -->
    <div class="settings-user-info">
      ${t?`
        <div class="settings-user-row">
          <div class="profile-avatar-wrap">
            ${(()=>{let e=n&&n.photoURL||t.photoURL,r=e&&!g(e)?e:``;return r?`<img src="${v(r)}" alt="" onerror="this.style.display='none';this.parentNode.innerHTML='<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"></path><circle cx="12" cy="7" r="4"></circle></svg>'" />`:`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"></path><circle cx="12" cy="7" r="4"></circle></svg>`})()}
          </div>
          <div class="settings-user-meta">
            <div class="settings-user-name">
              ${n&&n.nickname||t.displayName||(t.email?t.email.split(`@`)[0]:`사용자`)}
              ${n&&n.role===`editor`?`<span class="settings-user-badge">관리자</span>`:``}
            </div>
            <div class="settings-user-email">${t.email||`이메일 정보 없음`}</div>
          </div>
          <button id="profile-edit-btn" class="profile-edit-btn" aria-label="프로필 편집">
            <svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
              <path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"></path>
              <path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"></path>
            </svg>
          </button>
        </div>
      `:``}
    </div>

    ${S()}
  `,setTimeout(()=>{e.querySelector(`#profile-edit-btn`)?.addEventListener(`click`,()=>E()),e.querySelector(`#goto-settings-btn`)?.addEventListener(`click`,()=>a(`/settings`)),e.querySelector(`#goto-editor-btn`)?.addEventListener(`click`,()=>a(`/editor`))},0),x(e,{myStoryClickMode:`popup`}),e}function E(){let n=o(`user`),i=o(`profile`)||{};if(!n||!n.id||document.querySelector(`.profile-edit-overlay`))return;let g=i.photoURL||n.photoURL||``,x=i.nickname||n.displayName||(n.email?n.email.split(`@`)[0]:``),S=document.createElement(`div`);S.className=`profile-edit-overlay`,S.innerHTML=`
    <div class="profile-edit-modal" role="dialog" aria-modal="true" aria-labelledby="profile-edit-title">
      <div class="profile-edit-header">
        <span class="profile-edit-title" id="profile-edit-title">프로필 편집</span>
        <button class="profile-edit-close" id="profile-edit-close" aria-label="닫기">
          <svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2">
            <path d="M18 6L6 18M6 6l12 12"/>
          </svg>
        </button>
      </div>

      <div class="profile-edit-body">
        <div class="profile-edit-avatar-section">
          <div class="profile-edit-avatar-wrap">
            <div class="profile-edit-avatar" id="profile-edit-avatar">
              ${g?`<img src="${g}" />`:`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"></path><circle cx="12" cy="7" r="4"></circle></svg>`}
            </div>
            <button type="button" class="profile-edit-photo-icon" id="profile-edit-photo-btn" aria-label="프로필 사진 변경">
              <svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
                <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/>
                <polyline points="17 8 12 3 7 8"/>
                <line x1="12" y1="3" x2="12" y2="15"/>
              </svg>
            </button>
          </div>
        </div>

        <div class="profile-edit-field">
          <label class="profile-edit-label" for="profile-nickname-input">닉네임</label>
          <input type="text" class="profile-edit-input" id="profile-nickname-input"
                 value="${v(x)}" maxlength="20" placeholder="닉네임을 입력하세요" />
          <div class="profile-edit-hint">최대 20자</div>
        </div>
      </div>

      <div class="profile-edit-actions">
        <button class="profile-edit-cancel" id="profile-edit-cancel" type="button">취소</button>
        <button class="profile-edit-save" id="profile-edit-save" type="button">저장</button>
      </div>
    </div>
  `,(document.querySelector(`.mobile-wrapper`)||document.body).appendChild(S),y(),requestAnimationFrame(()=>S.classList.add(`visible`)),S.addEventListener(`touchmove`,e=>{e.target.closest(`.profile-edit-modal`)||e.preventDefault()},{passive:!1}),S.addEventListener(`wheel`,e=>{e.target.closest(`.profile-edit-modal`)||e.preventDefault()},{passive:!1});let C=null,w=()=>{S.classList.remove(`visible`),document.removeEventListener(`keydown`,T),b(),setTimeout(()=>S.remove(),200)},T=e=>{e.key===`Escape`&&w()};document.addEventListener(`keydown`,T),S.querySelector(`#profile-edit-close`).addEventListener(`click`,w),S.querySelector(`#profile-edit-cancel`).addEventListener(`click`,w),S.addEventListener(`click`,e=>{e.target===S&&w()});async function E(n){try{let t=n===`camera`?await r():await e();if(!t)return;D(t.dataUrl,e=>{C=e;let t=S.querySelector(`#profile-edit-avatar`);t.innerHTML=`<img src="${URL.createObjectURL(e)}" />`})}catch(e){if(e instanceof t){_(e.message,`warning`);return}_(e?.message||`사진을 불러올 수 없습니다.`,`error`)}}S.querySelector(`#profile-edit-photo-btn`)?.addEventListener(`click`,()=>E(`gallery`)),S.querySelector(`#profile-edit-save`).addEventListener(`click`,async()=>{let e=S.querySelector(`#profile-edit-save`),t=S.querySelector(`#profile-nickname-input`).value.trim();if(!t){_(`닉네임을 입력해주세요.`,`warning`);return}e.textContent=`저장 중...`,e.disabled=!0;try{let e=d?.currentUser?.uid||n.id,r=u(f,`profiles`,e),o={nickname:t};if(C){let t=l(c,`users/${e}/diary/profile_avatar_${Date.now()}.jpg`);await m(t,C,{contentType:`image/jpeg`}),o.photoURL=await p(t)}await h(r,o,{merge:!0}),s(`profile`,{...i,...o});let g={...n};g.displayName=t,o.photoURL&&(g.photoURL=o.photoURL),s(`user`,g),_(`프로필이 수정되었습니다.`,`success`),w(),a(`/profile`)}catch(t){console.error(`프로필 저장 실패:`,t),_(`프로필 저장에 실패했습니다.`,`error`),e.textContent=`저장`,e.disabled=!1}})}function D(e,t){let n=document.createElement(`div`);n.className=`crop-modal-overlay`,n.innerHTML=`
    <div class="crop-modal-header">프로필 사진 자르기</div>
    <div class="crop-modal-body">
      <img id="profile-cropper-image" src="${e}" style="max-width: 100%; display: block;" />
    </div>
    <div class="crop-modal-footer">
      <button type="button" class="btn-rotate" id="btn-profile-crop-rotate">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
          <path d="M21 2v6h-6"/>
          <path d="M21 13a9 9 0 1 1-2.63-6.36L21 9"/>
        </svg>
        회전
      </button>
      <button type="button" class="btn-crop-confirm" id="btn-profile-crop-confirm">확인</button>
    </div>
  `,(document.querySelector(`.mobile-wrapper`)||document.body).appendChild(n),setTimeout(()=>n.style.opacity=`1`,10);let r=n.querySelector(`#profile-cropper-image`),i;r.onload=()=>{i=new w.default(r,{aspectRatio:1,viewMode:1,dragMode:`move`,autoCropArea:.9,restore:!1,guides:!1,center:!0,highlight:!1,cropBoxMovable:!0,cropBoxResizable:!0,toggleDragModeOnDblclick:!1})},r.onerror=()=>{_(`이미지를 불러올 수 없습니다.`,`error`),n.remove()},n.querySelector(`#btn-profile-crop-rotate`).addEventListener(`click`,()=>{i&&i.rotate(90)}),n.querySelector(`#btn-profile-crop-confirm`).addEventListener(`click`,()=>{let e=n.querySelector(`#btn-profile-crop-confirm`);e.textContent=`처리 중...`,e.disabled=!0,i&&i.getCroppedCanvas({maxWidth:512,maxHeight:512,imageSmoothingEnabled:!0,imageSmoothingQuality:`high`}).toBlob(r=>{if(!r){_(`크롭 오류가 발생했습니다.`,`error`),e.textContent=`확인`,e.disabled=!1;return}t(r),i.destroy(),n.style.opacity=`0`,setTimeout(()=>n.remove(),300)},`image/jpeg`,.85)})}export{T as renderProfile};