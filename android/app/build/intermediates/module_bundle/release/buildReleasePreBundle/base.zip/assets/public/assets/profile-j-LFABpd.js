import{a as e,i as t,n,r,t as i}from"./cropper-DfNRxLcH.js";import{a}from"./router-hybKseu2.js";import{n as o,r as s}from"./state-8PRbPWwW.js";import{c,f as l,n as u,o as d,r as f,s as p,t as m,y as h}from"./firebase-CMykNrkF.js";import{t as g}from"./toast-DL5HJnQ3.js";import{t as _}from"./sanitize-DlMVmTsh.js";import{n as v,t as y}from"./scrollLock-ByagqdMz.js";import{initArchiveSection as b,renderArchiveSection as x}from"./bookmarks-CHgGixuw.js";import{n as S}from"./pageHeader-CzG3S3Fi.js";var C=e(i(),1);function w(){let e=document.createElement(`div`);e.className=`settings-page page`;let t=o(`user`),n=o(`profile`);return e.innerHTML=`
    ${S({title:`프로필`,icon:`none`,rightAction:`<button type="button" id="goto-settings-btn" class="page-header-back" aria-label="설정"><svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12.22 2h-.44a2 2 0 0 0-2 2v.18a2 2 0 0 1-1 1.73l-.43.25a2 2 0 0 1-2 0l-.15-.08a2 2 0 0 0-2.73.73l-.22.38a2 2 0 0 0 .73 2.73l.15.1a2 2 0 0 1 1 1.72v.51a2 2 0 0 1-1 1.74l-.15.09a2 2 0 0 0-.73 2.73l.22.38a2 2 0 0 0 2.73.73l.15-.08a2 2 0 0 1 2 0l.43.25a2 2 0 0 1 1 1.73V20a2 2 0 0 0 2 2h.44a2 2 0 0 0 2-2v-.18a2 2 0 0 1 1-1.73l.43-.25a2 2 0 0 1 2 0l.15.08a2 2 0 0 0 2.73-.73l.22-.39a2 2 0 0 0-.73-2.73l-.15-.08a2 2 0 0 1-1-1.74v-.5a2 2 0 0 1 1-1.74l.15-.09a2 2 0 0 0 .73-2.73l-.22-.38a2 2 0 0 0-2.73-.73l-.15.08a2 2 0 0 1-2 0l-.43-.25a2 2 0 0 1-1-1.73V4a2 2 0 0 0-2-2z"/><circle cx="12" cy="12" r="3"/></svg></button>`})}

    <!-- 사용자 정보 카드 -->
    <div class="settings-user-info">
      ${t&&t.id!==`guest`?`
        <div class="settings-user-row">
          <div class="profile-avatar-wrap">
            ${n&&n.photoURL||t.photoURL?`<img src="${n&&n.photoURL||t.photoURL}" alt="" />`:`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"></path><circle cx="12" cy="7" r="4"></circle></svg>`}
          </div>
          <div class="settings-user-meta">
            <div class="settings-user-name">
              ${n&&n.nickname||t.displayName||(t.email?t.email.split(`@`)[0]:`사용자`)}
              ${n&&n.role===`editor`?`<span class="settings-user-badge">관리자</span>`:``}
            </div>
            <div class="settings-user-email">${t.email||`이메일 정보 없음`}</div>
          </div>
          <button id="profile-edit-btn" class="profile-edit-btn" aria-label="프로필 편집">
            <svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
              <path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"></path>
              <path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"></path>
            </svg>
          </button>
        </div>
      `:`
        <div class="settings-user-row">
          <div class="profile-avatar-wrap">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"></path><circle cx="12" cy="7" r="4"></circle></svg>
          </div>
          <div class="settings-user-meta">
            <div class="settings-user-name">게스트 모드</div>
            <div class="settings-user-email">로그인하고 기록을 저장하세요</div>
          </div>
        </div>
        <button id="goto-login-btn" class="btn btn-primary settings-user-cta">
          로그인 / 회원가입 하러 가기
        </button>
      `}
    </div>

    ${x()}
  `,setTimeout(()=>{e.querySelector(`#goto-login-btn`)?.addEventListener(`click`,()=>a(`/login`)),e.querySelector(`#profile-edit-btn`)?.addEventListener(`click`,()=>T()),e.querySelector(`#goto-settings-btn`)?.addEventListener(`click`,()=>a(`/settings`))},0),b(e),e}function T(){let e=o(`user`),i=o(`profile`)||{};if(!e||e.id===`guest`||document.querySelector(`.profile-edit-overlay`))return;let b=i.photoURL||e.photoURL||``,x=i.nickname||e.displayName||(e.email?e.email.split(`@`)[0]:``),S=document.createElement(`div`);S.className=`profile-edit-overlay`,S.innerHTML=`
    <div class="profile-edit-modal">
      <div class="profile-edit-header">
        <button class="profile-edit-close" id="profile-edit-close" aria-label="닫기">
          <svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2">
            <path d="M18 6L6 18M6 6l12 12"/>
          </svg>
        </button>
        <span class="profile-edit-title">프로필 편집</span>
        <button class="profile-edit-save" id="profile-edit-save">저장</button>
      </div>

      <div class="profile-edit-avatar-section">
        <div class="profile-edit-avatar" id="profile-edit-avatar">
          ${b?`<img src="${b}" />`:`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"></path><circle cx="12" cy="7" r="4"></circle></svg>`}
        </div>
        <div style="display:flex; gap:var(--space-2); justify-content:center;">
          <button class="profile-edit-photo-btn" id="profile-edit-photo-gallery">보관함</button>
          <button class="profile-edit-photo-btn" id="profile-edit-photo-camera">촬영</button>
        </div>
      </div>

      <div class="profile-edit-field">
        <label class="profile-edit-label" for="profile-nickname-input">닉네임</label>
        <input type="text" class="profile-edit-input" id="profile-nickname-input"
               value="${_(x)}" maxlength="20" placeholder="닉네임을 입력하세요" />
        <div class="profile-edit-hint">최대 20자</div>
      </div>
    </div>
  `,(document.querySelector(`.mobile-wrapper`)||document.body).appendChild(S),y(),requestAnimationFrame(()=>S.classList.add(`visible`)),S.addEventListener(`touchmove`,e=>{e.target.closest(`.profile-edit-modal`)||e.preventDefault()},{passive:!1});let C=null,w=()=>{S.classList.remove(`visible`),v(),setTimeout(()=>S.remove(),200)};S.querySelector(`#profile-edit-close`).addEventListener(`click`,w),S.addEventListener(`click`,e=>{e.target===S&&w()});async function T(e){try{let n=e===`camera`?await r():await t();if(!n)return;E(n.dataUrl,e=>{C=e;let t=S.querySelector(`#profile-edit-avatar`);t.innerHTML=`<img src="${URL.createObjectURL(e)}" />`})}catch(e){if(e instanceof n){g(e.message,`warning`);return}g(e?.message||`사진을 불러올 수 없습니다.`,`error`)}}S.querySelector(`#profile-edit-photo-gallery`)?.addEventListener(`click`,()=>T(`gallery`)),S.querySelector(`#profile-edit-photo-camera`)?.addEventListener(`click`,()=>T(`camera`)),S.querySelector(`#profile-edit-save`).addEventListener(`click`,async()=>{let t=S.querySelector(`#profile-edit-save`),n=S.querySelector(`#profile-nickname-input`).value.trim();if(!n){g(`닉네임을 입력해주세요.`,`warning`);return}t.textContent=`저장 중...`,t.disabled=!0;try{let t=m?.currentUser?.uid||e.id,r=l(u,`profiles`,t),o={nickname:n};if(C){let e=p(f,`users/${t}/diary/profile_avatar_${Date.now()}.webp`);await c(e,C),o.photoURL=await d(e)}await h(r,o,{merge:!0}),s(`profile`,{...i,...o});let _={...e};_.displayName=n,o.photoURL&&(_.photoURL=o.photoURL),s(`user`,_),g(`프로필이 수정되었습니다.`,`success`),w(),a(`/profile`)}catch(e){console.error(`프로필 저장 실패:`,e),g(`프로필 저장에 실패했습니다.`,`error`),t.textContent=`저장`,t.disabled=!1}})}function E(e,t){let n=document.createElement(`div`);n.className=`crop-modal-overlay`,n.innerHTML=`
    <div class="crop-modal-header">프로필 사진 자르기</div>
    <div class="crop-modal-body">
      <img id="profile-cropper-image" src="${e}" style="max-width: 100%; display: block;" />
    </div>
    <div class="crop-modal-footer">
      <button type="button" class="btn-rotate" id="btn-profile-crop-rotate">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
          <path d="M21.5 2v6h-6M21.34 15.57a10 10 0 1 1-.53-11.23l5.67 5.66" />
        </svg>
        회전
      </button>
      <button type="button" class="btn-crop-confirm" id="btn-profile-crop-confirm">확인</button>
    </div>
  `,(document.querySelector(`.mobile-wrapper`)||document.body).appendChild(n),setTimeout(()=>n.style.opacity=`1`,10);let r=n.querySelector(`#profile-cropper-image`),i;r.onload=()=>{i=new C.default(r,{aspectRatio:1,viewMode:1,dragMode:`move`,autoCropArea:.9,restore:!1,guides:!1,center:!0,highlight:!1,cropBoxMovable:!0,cropBoxResizable:!0,toggleDragModeOnDblclick:!1})},r.onerror=()=>{g(`이미지를 불러올 수 없습니다.`,`error`),n.remove()},n.querySelector(`#btn-profile-crop-rotate`).addEventListener(`click`,()=>{i&&i.rotate(90)}),n.querySelector(`#btn-profile-crop-confirm`).addEventListener(`click`,()=>{let e=n.querySelector(`#btn-profile-crop-confirm`);e.textContent=`처리 중...`,e.disabled=!0,i&&i.getCroppedCanvas({maxWidth:512,maxHeight:512,imageSmoothingEnabled:!0,imageSmoothingQuality:`high`}).toBlob(r=>{if(!r){g(`크롭 오류가 발생했습니다.`,`error`),e.textContent=`확인`,e.disabled=!1;return}t(r),i.destroy(),n.style.opacity=`0`,setTimeout(()=>n.remove(),300)},`image/webp`,.85)})}export{w as renderProfile};