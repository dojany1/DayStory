import{a as e}from"./router-7m-s0x-D.js";import{r as t,s as n}from"./stories-DtUSAb1-.js";import{t as r}from"./sanitize-BzcRQ1L1.js";function i(){let e=document.createElement(`div`);return e.className=`search-page page`,e.innerHTML=`
    <!-- 페이지 제목 -->
    <div class="page-header" style="height: 60px; padding: 0 16px; align-items:center; display:flex;">
      <h1 class="page-header-title" style="margin:0; line-height:1;">검색</h1>
    </div>

    <!-- 검색창 -->
    <div class="search-bar" id="search-bar">
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
        <circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/>
      </svg>
      <input type="text" id="search-input" placeholder="인물, 사건, 국가로 검색..." autocomplete="off" />
    </div>

    <!-- 검색 결과 목록 -->
    <div id="search-results" class="search-results">
      <div style="display:flex;justify-content:center;padding:var(--space-6);">
        <div class="loading-spinner"></div>
      </div>
    </div>

    <!-- 검색 결과 없음 상태 -->
    <div id="search-empty" class="empty-state" style="display:none;">
      <div class="empty-state-title">검색 결과가 없습니다</div>
      <div class="empty-state-desc">다른 키워드로 검색해보세요</div>
    </div>
  `,(async()=>{let e=await t(),n=document.getElementById(`search-results`),r=document.getElementById(`search-empty`);if(n){if(e.length===0){n.style.display=`none`,r&&(r.querySelector(`.empty-state-title`).textContent=`아직 발행된 카드가 없어요`,r.querySelector(`.empty-state-desc`).textContent=`곧 첫 카드가 도착할 거예요`,r.style.display=`flex`);return}n.innerHTML=e.map(e=>o(e)).join(``),a()}})(),setTimeout(()=>{let e=document.getElementById(`search-input`),r;e?.addEventListener(`input`,()=>{clearTimeout(r),r=setTimeout(async()=>{let r=e.value.trim(),i=document.getElementById(`search-results`),s=document.getElementById(`search-empty`);if(!r){i.innerHTML=(await t()).map(e=>o(e)).join(``),s.style.display=`none`,i.style.display=`flex`,a();return}let c=await n(r);c.length?(i.innerHTML=c.map(e=>o(e)).join(``),s.style.display=`none`,i.style.display=`flex`):(i.style.display=`none`,s.style.display=`flex`),a()},300)})},0),e}function a(){document.querySelectorAll(`.search-result-item`).forEach(t=>{t.addEventListener(`click`,()=>{e(`/detail/`+t.dataset.storyId)})})}function o(e){let t=new Date(e.publish_date),n=`${t.getFullYear()}.${t.getMonth()+1}.${t.getDate()}`,i=e.image_url||``,a=i?`src="${r(i)}"`:``;return`
    <div class="search-result-item" data-story-id="${r(e.id)}">
      <div class="search-result-thumb">
        <img ${a} alt="${r(e.figure_name)}" loading="lazy" decoding="async" />
      </div>
      <div class="search-result-info">
        <div class="search-result-date">${n} · ${r(e.country)}</div>
        <div class="search-result-title">${r(e.figure_name)}</div>
        <div class="search-result-summary">${r(e.summary)}</div>
      </div>
    </div>
  `}export{i as renderSearch};