const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/web-yTxtHSgT.js","assets/dist-N3LOKtlT.js"])))=>i.map(i=>d[i]);
import{a as e}from"./router-hybKseu2.js";import{n as t,r as n}from"./state-8PRbPWwW.js";import{r,t as i}from"./i18n-B_-hulXt.js";import{A as a,G as o,h as s,i as c,k as ee}from"./index.esm-Bc1dmMJH.js";import{C as te,S as ne,c as re,d as ie,f as ae,h as oe,i as se,n as l,p as ce,r as u,s as le,t as d,v as ue}from"./firebase-DGvE0Cu9.js";import{i as de,t as f}from"./dist-N3LOKtlT.js";import{t as fe}from"./preload-helper-Dd-HcVz_.js";import{t as p}from"./toast-C-m3kd2X.js";import{a as pe,h as me,o as m,s as h}from"./index-b529ZtNJ.js";import{t as he}from"./esm-BSoiV1KJ.js";import{n as g,t as _}from"./pageHeader-CzG3S3Fi.js";var ge;(function(e){e[e.Sunday=1]=`Sunday`,e[e.Monday=2]=`Monday`,e[e.Tuesday=3]=`Tuesday`,e[e.Wednesday=4]=`Wednesday`,e[e.Thursday=5]=`Thursday`,e[e.Friday=6]=`Friday`,e[e.Saturday=7]=`Saturday`})(ge||={});var v=de(`LocalNotifications`,{web:()=>fe(()=>import(`./web-yTxtHSgT.js`).then(e=>new e.LocalNotificationsWeb),__vite__mapDeps([0,1]))}),y=`ds_notification_settings_v1`,b={diary:{enabled:!0,time:`12:00`},editor:{enabled:!1,time:`12:00`}},x={diary:{id:1001,route:`/mystory`,title:`일기 쓸 시간이에요`,body:`오늘의 기록을 남겨보세요.`},editor:{id:1002,route:`/editorstory`,title:`오늘의 일화가 도착했어요`,body:`DayStory에서 오늘의 이야기를 확인해보세요.`}},S=null,C=!1,w=null,T=new Map;function E(){let e=Ee();return{diary:P(e.diary,b.diary),editor:P(e.editor,b.editor)}}async function D(e,t){if(!x[e])return E();let n=E(),r=n[e],i=P({...r,...t},b[e]);return t?.enabled===!0&&(await _e()||(i.enabled=!1,p(`알림 권한이 필요합니다`,`warning`))),n[e]=i,De(n),await ve(e),E()}async function _e(){return w||=(A()?be():xe()).finally(()=>{w=null}),w}async function ve(e=null){let t=E(),n=e&&x[e]?[e]:Object.keys(x);if(!A()){Se(t,n);return}await k();let r=n.map(e=>({id:x[e].id}));try{await v.cancel({notifications:r})}catch(e){console.warn(`알림 예약 취소 실패:`,e)}let i=n.filter(e=>t[e]?.enabled).map(e=>ye(e,t[e]));if(i.length)try{await v.schedule({notifications:i})}catch(e){console.warn(`알림 예약 실패:`,e),p(`알림 예약에 실패했습니다`,`error`)}}function ye(e,t){let n=x[e],{hour:r,minute:i}=F(t.time);return{id:n.id,title:n.title,body:n.body,schedule:{on:{hour:r,minute:i},allowWhileIdle:!0},autoCancel:!0,channelId:`daystory_default`,extra:{type:e,route:n.route}}}var O=!1;async function k(){if(!O&&f.isNativePlatform()&&!(f.getPlatform&&f.getPlatform()!==`android`))try{await v.createChannel({id:`daystory_default`,name:`DayStory 알림`,description:`일기와 카드 알림`,importance:4,visibility:1,vibration:!0}),O=!0}catch(e){console.warn(`알림 채널 생성 실패:`,e)}}async function be(){try{return await k(),(await v.checkPermissions()).display===`granted`?!0:(await v.requestPermissions()).display===`granted`}catch(e){return console.warn(`알림 권한 확인 실패:`,e),!1}}async function xe(){if(!j())return!1;if(Notification.permission===`granted`||C)return!0;if(Notification.permission===`denied`)return!1;try{return C=await Notification.requestPermission()===`granted`,C}catch(e){return console.warn(`웹 알림 권한 확인 실패:`,e),!1}}function A(){return f.isNativePlatform()}function j(){return typeof Notification<`u`}function M(){return j()&&(Notification.permission===`granted`||C)}function Se(e,t){t.forEach(Ce),M()&&t.filter(t=>e[t]?.enabled).forEach(t=>{N(t,e[t])})}function Ce(e){let t=T.get(e);t&&clearTimeout(t),T.delete(e)}function N(e,t){let n=Te(t.time),r=setTimeout(()=>{we(e);let t=E()[e];t?.enabled&&N(e,t)},n);T.set(e,r)}function we(e){if(!M())return;let t=x[e],n=new Notification(t.title,{body:t.body,tag:`daystory-${e}`,data:{type:e,route:t.route}});n.onclick=()=>{S?.(t.route)}}function Te(e){let{hour:t,minute:n}=F(e),r=new Date,i=new Date(r);return i.setHours(t,n,0,0),i<=r&&i.setDate(i.getDate()+1),i.getTime()-r.getTime()}function Ee(){try{return JSON.parse(localStorage.getItem(y)||`{}`)||{}}catch{return{}}}function De(e){localStorage.setItem(y,JSON.stringify({diary:P(e.diary,b.diary),editor:P(e.editor,b.editor)}))}function P(e,t){return e==null?{enabled:!!t.enabled,time:t.time}:{enabled:!!e?.enabled,time:I(e?.time)?e.time:t.time}}function F(e){let[t,n]=(I(e)?e:`12:00`).split(`:`).map(Number);return{hour:t,minute:n}}function I(e){return typeof e==`string`&&/^([01]\d|2[0-3]):[0-5]\d$/.test(e)}var Oe={diary:{title:`일기 알림`,subtitle:`나의 일기 쓰기`},editor:{title:`에디터 알림`,subtitle:`오늘의 일화 확인`}},L=[{value:`AM`,label:`오전`},{value:`PM`,label:`오후`}];function ke(){return`
    <div class="list-item" id="setting-notifications" role="button" tabindex="0">
      <div class="list-item-icon notification-settings-icon">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
          <path d="M6 8a6 6 0 0 1 12 0c0 7 3 9 3 9H3s3-2 3-9"/>
          <path d="M10.3 21a1.94 1.94 0 0 0 3.4 0"/>
          <path d="M4 2C2.8 3.7 2 5.7 2 8"/>
          <path d="M20 2c1.2 1.7 2 3.7 2 8"/>
        </svg>
      </div>
      <div class="list-item-content">
        <div class="list-item-title">알림</div>
        <div class="list-item-subtitle notification-settings-summary">${V()}</div>
      </div>
      <div class="list-item-action">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" style="width:16px;height:16px">
          <polyline points="9 18 15 12 9 6"/>
        </svg>
      </div>
    </div>
  `}function Ae(e){let t=e.querySelector(`#setting-notifications`);if(t){if(t.dataset.notificationSettingsBound===`true`)return;t.dataset.notificationSettingsBound=`true`;let n=()=>je(()=>B(e));t.addEventListener(`click`,n),t.addEventListener(`keydown`,e=>{(e.key===`Enter`||e.key===` `)&&(e.preventDefault(),n())})}}function je(e=()=>{}){let t=document.querySelector(`.notification-settings-overlay`);if(t)return t;let n=document.createElement(`div`);n.className=`notification-settings-overlay`,n.setAttribute(`role`,`dialog`),n.setAttribute(`aria-modal`,`true`),n.setAttribute(`aria-labelledby`,`notification-settings-title`),n.innerHTML=`
    <div class="notification-settings-sheet">
      ${g({title:`알림`,titleId:`notification-settings-title`,icon:`close`,backLabel:`닫기`})}
      <div class="notification-settings-list">
        ${R(`diary`)}
        ${R(`editor`)}
      </div>
    </div>
  `,(document.querySelector(`.mobile-wrapper`)||document.body).appendChild(n),m(),requestAnimationFrame(()=>n.classList.add(`visible`)),n.addEventListener(`touchmove`,e=>{e.target.closest(`.notification-settings-sheet`)||e.preventDefault()},{passive:!1});let r=!1;return _(n,()=>{r||(r=!0,h(),n.classList.remove(`visible`),n.addEventListener(`transitionend`,()=>n.remove(),{once:!0}),setTimeout(()=>{n.parentNode&&n.remove()},450))}),n.querySelectorAll(`[data-notification-toggle]`).forEach(t=>{t.addEventListener(`click`,async()=>{let r=t.dataset.notificationToggle,i=E()[r];t.setAttribute(`aria-busy`,`true`),t.disabled=!0,z(n,r,(await D(r,{enabled:!i.enabled}))[r]),B(document),e(),t.disabled=!1,t.removeAttribute(`aria-busy`)})}),n.querySelectorAll(`.notification-settings-time-select`).forEach(t=>{t.addEventListener(`change`,async()=>{let r=t.dataset.notificationType;z(n,r,(await D(r,{time:Me(n,r)}))[r]),B(document),e()})}),n}function R(e){let t=E()[e],n=Oe[e],r=H(t.time);return`
    <div class="notification-settings-row" data-notification-row="${e}">
      <div class="notification-settings-copy">
        <div class="notification-settings-row-title">${n.title}</div>
        <div class="notification-settings-row-subtitle">${n.subtitle}</div>
      </div>
      <div class="notification-settings-time-control" data-notification-time-control="${e}" aria-label="${n.title} 시간">
        <select class="notification-settings-time-select" data-notification-period="${e}" data-notification-type="${e}" aria-label="${n.title} 오전 오후">
          ${L.map(e=>`<option value="${e.value}" ${r.period===e.value?`selected`:``}>${e.label}</option>`).join(``)}
        </select>
        <select class="notification-settings-time-select" data-notification-hour="${e}" data-notification-type="${e}" aria-label="${n.title} 시">
          ${Array.from({length:12},(e,t)=>t+1).map(e=>`<option value="${String(e).padStart(2,`0`)}" ${r.hour===e?`selected`:``}>${e}시</option>`).join(``)}
        </select>
        <select class="notification-settings-time-select" data-notification-minute="${e}" data-notification-type="${e}" aria-label="${n.title} 분">
          ${Array.from({length:60},(e,t)=>`<option value="${String(t).padStart(2,`0`)}" ${r.minute===t?`selected`:``}>${String(t).padStart(2,`0`)}분</option>`).join(``)}
        </select>
      </div>
      <button type="button" class="toggle ${t.enabled?`active`:``}" data-notification-toggle="${e}" aria-label="${n.title}" aria-pressed="${t.enabled?`true`:`false`}"></button>
    </div>
  `}function z(e,t,n){let r=e.querySelector(`[data-notification-row="${t}"]`),i=r?.querySelector(`[data-notification-period="${t}"]`),a=r?.querySelector(`[data-notification-hour="${t}"]`),o=r?.querySelector(`[data-notification-minute="${t}"]`),s=r?.querySelector(`[data-notification-toggle="${t}"]`);if(!r||!i||!a||!o||!s)return;let c=H(n.time);i.value=c.period,a.value=String(c.hour).padStart(2,`0`),o.value=String(c.minute).padStart(2,`0`),s.classList.toggle(`active`,n.enabled),s.setAttribute(`aria-pressed`,n.enabled?`true`:`false`)}function B(e){e.querySelectorAll(`.notification-settings-summary`).forEach(e=>{e.textContent=V()})}function V(){let e=E();return`${e.diary.enabled?`일기 ${U(e.diary.time)}`:`일기 꺼짐`} · ${e.editor.enabled?`에디터 ${U(e.editor.time)}`:`에디터 꺼짐`}`}function Me(e,t){let n=e.querySelector(`[data-notification-period="${t}"]`)?.value||`PM`,r=e.querySelector(`[data-notification-hour="${t}"]`)?.value||`12`,i=e.querySelector(`[data-notification-minute="${t}"]`)?.value||`00`;return W(n,Number(r),i)}function H(e){let[t,n]=String(e||`12:00`).split(`:`).map(Number),r=Number.isInteger(t)?t:12,i=Number.isInteger(n)?n:0;return{period:r<12?`AM`:`PM`,hour:r%12||12,minute:i}}function U(e){let t=H(e);return`${L.find(e=>e.value===t.period)?.label||`오후`} ${t.hour}:${String(t.minute).padStart(2,`0`)}`}function W(e,t,n){let r=Math.min(Math.max(Number(t)||12,1),12)%12;return e===`PM`&&(r+=12),`${String(r).padStart(2,`0`)}:${String(n).padStart(2,`0`)}`}var Ne=[`bookmarks`,`userStories`],G=400;async function Pe(e){!u||!e||await K(re(u,`users/${e}`))}async function K(e){let t;try{t=await le(e)}catch(t){console.warn(`[userCleanup] Storage listAll 실패 (무시):`,e.fullPath,t);return}await Promise.allSettled(t.items.map(e=>se(e)));for(let e of t.prefixes)await K(e)}async function Fe(e){if(!(!l||!e)){try{await ae(ce(l,`profiles`,e))}catch(e){console.warn(`[userCleanup] profiles 삭제 실패 (무시):`,e)}for(let t of Ne){let n=t===`userStories`?`uid`:`user_id`;try{let r=await oe(ue(ie(l,t),ne(n,`==`,e)));if(r.empty)continue;let i=r.docs;for(let e=0;e<i.length;e+=G){let t=te(l);i.slice(e,e+G).forEach(e=>t.delete(e.ref)),await t.commit()}}catch(e){console.warn(`[userCleanup] ${t} 삭제 실패 (무시):`,e)}}}}async function Ie(e){if(!e||(e.providerData?.[0]?.providerId||``)!==`google.com`)return!1;try{if(f.isNativePlatform()){let t=await he.signInWithGoogle({skipNativeAuth:!0,useCredentialManager:!1}),n=t.credential?.idToken;return n?(await ee(e,c.credential(n,t.credential?.accessToken)),!0):!1}return await a(e,new c),!0}catch(e){return console.warn(`[userCleanup] 재인증 실패:`,e),!1}}var q=`daystory:auth-session-active`,Le=`https://0729.notion.site/336c0180451480a4b0a8c60dba754daf?source=copy_link`;function Re(){let e=t(`user`),n=t(`profile`),a=t(`theme`);i();let o=Math.max(0,[`light`,`dark`,`system`].indexOf(a));return`
    ${n&&n.role===`editor`?`
    <div class="settings-section">
      <div class="settings-section-title">관리자 도구</div>
      ${Y({id:`setting-editor`,title:r(`settings.row_editor`),subtitle:r(`settings.row_editor_subtitle`),icon:Ye()})}
    </div>
    `:``}

    <div class="settings-section">
      <div class="settings-section-title">앱 설정</div>
      <div class="theme-option-group" role="group" aria-label="${r(`settings.section_display`)}" data-active="${o}">
        ${J(`light`,r(`settings.theme_light`),a,Ke())}
        ${J(`dark`,r(`settings.theme_dark`),a,qe())}
        ${J(`system`,r(`settings.theme_system`),a,Je())}
        <span class="theme-option-thumb" aria-hidden="true"></span>
      </div>
      ${ke()}
      ${Ve()}
    </div>

    <div class="settings-section">
      <div class="settings-section-title">지원</div>
      ${Y({id:`setting-about`,title:r(`settings.row_about`),subtitle:r(`settings.row_about_subtitle`),icon:Qe()})}
      ${Y({id:`setting-contact`,title:`문의`,icon:$e()})}
    </div>

    ${e?`
    <div class="settings-section">
      ${Y({id:`setting-logout`,title:r(`settings.row_logout`),icon:Xe(),titleClass:`settings-row-danger`,showChevron:!1})}
      ${Y({id:`setting-withdraw`,title:r(`settings.row_withdraw`),icon:Ze(),titleClass:`settings-row-danger`,showChevron:!1})}
    </div>
    `:``}

    <div class="settings-privacy-link">
      <a href="${Le}" target="_blank" rel="noopener noreferrer">
        ${r(`settings.privacy_link`)}
      </a>
    </div>

    <div class="settings-version">
      DayStory v${me.version}
    </div>
    <div class="settings-version">
      2026 DOKHU Team
    </div>
  `}function ze(t){Ae(t),Be(t),He(t),Z(t,`#setting-editor`,()=>e(`/editor`)),Z(t,`#setting-about`,()=>e(`/about`)),Z(t,`#setting-contact`,()=>p(`준비중인 기능입니다. 업데이트를 기다려주세요!`,`info`)),Z(t,`#setting-logout`,We),Z(t,`#setting-withdraw`,Ge)}function J(e,t,n,r){return`
    <button type="button" class="theme-option ${n===e?`active`:``}" data-theme="${e}" aria-pressed="${n===e?`true`:`false`}">
      ${r}
      <span class="theme-option-label">${t}</span>
    </button>
  `}function Y({id:e,title:t,subtitle:n=``,icon:r,titleClass:i=``,showChevron:a=!0}){return`
    <div class="list-item" id="${e}" role="button" tabindex="0">
      <div class="list-item-icon">${r}</div>
      <div class="list-item-content">
        <div class="list-item-title ${i}">${t}</div>
        ${n?`<div class="list-item-subtitle">${n}</div>`:``}
      </div>
      <div class="list-item-action">
        ${a?$():``}
      </div>
    </div>
  `}function Be(e){e.querySelectorAll(`.theme-option[data-theme]`).forEach(e=>{e.addEventListener(`click`,()=>{let t=e.dataset.theme;n(`theme`,t);let r=e.closest(`.theme-option-group`),i=[...r.querySelectorAll(`.theme-option[data-theme]`)];i.forEach(e=>{e.classList.remove(`active`),e.setAttribute(`aria-pressed`,`false`)}),e.classList.add(`active`),e.setAttribute(`aria-pressed`,`true`),r.dataset.active=i.indexOf(e)})})}function Ve(){let e=(localStorage.getItem(`ds_default_view`)||`card`)===`calendar`?r(`settings.view_calendar`):r(`settings.view_card`);return`
    <div class="list-item" id="setting-view-mode" role="button" tabindex="0">
      <div class="list-item-icon">${et()}</div>
      <div class="list-item-content">
        <div class="list-item-title">${r(`settings.section_view_mode`)}</div>
        <div class="list-item-subtitle" id="view-mode-summary">${e}</div>
      </div>
      <div class="list-item-action">${$()}</div>
    </div>
  `}function He(e){let t=e.querySelector(`#setting-view-mode`);if(!t)return;let n=()=>Ue(()=>X(e));t.addEventListener(`click`,n),t.addEventListener(`keydown`,e=>{(e.key===`Enter`||e.key===` `)&&(e.preventDefault(),n())})}function Ue(e=()=>{}){if(document.querySelector(`.view-mode-settings-overlay`))return;let t=localStorage.getItem(`ds_default_view`)||`card`,n=document.createElement(`div`);n.className=`notification-settings-overlay view-mode-settings-overlay`,n.setAttribute(`role`,`dialog`),n.setAttribute(`aria-modal`,`true`),n.innerHTML=`
    <div class="notification-settings-sheet">
      ${g({title:r(`settings.section_view_mode`),icon:`close`,backLabel:`닫기`})}
      <div class="notification-settings-list" role="radiogroup">
        <button type="button" class="list-item view-mode-option ${t===`card`?`active`:``}" data-view="card" role="radio" aria-checked="${t===`card`}">
          <div class="list-item-icon">
            <svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M2 7v10"/><path d="M6 5v14"/><rect width="12" height="18" x="10" y="3" rx="2"/></svg>
          </div>
          <div class="list-item-content">
            <div class="list-item-title">${r(`settings.view_card_action`)}</div>
          </div>
          <div class="list-item-action">
            <svg class="view-mode-check" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"/></svg>
          </div>
        </button>
        <button type="button" class="list-item view-mode-option ${t===`calendar`?`active`:``}" data-view="calendar" role="radio" aria-checked="${t===`calendar`}">
          <div class="list-item-icon">
            <svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M8 2v4"/><path d="M16 2v4"/><rect width="18" height="18" x="3" y="4" rx="2"/><path d="M3 10h18"/><path d="M8 14h.01"/><path d="M12 14h.01"/><path d="M16 14h.01"/><path d="M8 18h.01"/><path d="M12 18h.01"/><path d="M16 18h.01"/></svg>
          </div>
          <div class="list-item-content">
            <div class="list-item-title">${r(`settings.view_calendar_action`)}</div>
          </div>
          <div class="list-item-action">
            <svg class="view-mode-check" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"/></svg>
          </div>
        </button>
      </div>
    </div>
  `,(document.querySelector(`.mobile-wrapper`)||document.body).appendChild(n),m(),requestAnimationFrame(()=>n.classList.add(`visible`));let i=!1;_(n,()=>{i||(i=!0,h(),n.classList.remove(`visible`),n.addEventListener(`transitionend`,()=>n.remove(),{once:!0}),setTimeout(()=>{n.parentNode&&n.remove()},450))}),n.querySelectorAll(`.view-mode-option[data-view]`).forEach(t=>{t.addEventListener(`click`,()=>{let r=t.dataset.view;localStorage.getItem(`ds_default_view`)!==r&&(localStorage.setItem(`ds_default_view`,r),n.querySelectorAll(`.view-mode-option`).forEach(e=>{e.classList.remove(`active`),e.setAttribute(`aria-checked`,`false`)}),t.classList.add(`active`),t.setAttribute(`aria-checked`,`true`),X(document),e())})})}function X(e){let t=e.querySelector(`#view-mode-summary`);t&&(t.textContent=(localStorage.getItem(`ds_default_view`)||`card`)===`calendar`?r(`settings.view_calendar`):r(`settings.view_card`))}function Z(e,t,n){let r=e.querySelector(t);r&&(r.addEventListener(`click`,n),r.addEventListener(`keydown`,e=>{e.key!==`Enter`&&e.key!==` `||(e.preventDefault(),n(e))}))}async function We(){try{d&&await Promise.race([o(d),new Promise(e=>setTimeout(e,2e3))])}catch(e){console.warn(`로그아웃 오류 (무시됨):`,e)}localStorage.removeItem(q),n(`user`,null),n(`profile`,null);let e=document.getElementById(`bottom-nav`);e&&(e.style.display=`none`),window.location.hash=`#/login`,p(r(`toast.logged_out`),`success`)}async function Ge(){if(!(!d||!d.currentUser)&&await pe({title:`회원 탈퇴`,message:`정말로 회원을 탈퇴하시겠습니까?
계정과 모든 데이터(일화, 보관함, 업로드 사진 등)가 영구적으로 삭제되며 복구할 수 없습니다.`,confirmText:`탈퇴`,cancelText:`취소`,danger:!0,holdDuration:5e3,holdMessage:e=>e>0?`탈퇴까지 ${e}초간 누르고 계세요...`:`탈퇴를 진행합니다...`}))try{await Q(d.currentUser)}catch(t){if(t?.code===`auth/requires-recent-login`||t?.code===`auth/user-token-expired`){if(await Ie(d.currentUser))try{await Q(d.currentUser);return}catch(e){console.error(`재인증 후 탈퇴 재시도 실패:`,e)}p(`보안 정책에 따라 다시 로그인한 뒤 탈퇴하실 수 있습니다.`,`error`),localStorage.removeItem(q),n(`user`,null);let t=document.getElementById(`bottom-nav`);t&&(t.style.display=`none`),e(`/login`);return}console.error(`회원 탈퇴 실패:`,t),p(t?.message||`회원 탈퇴 처리 중 오류가 발생했습니다.`,`error`)}}async function Q(t){let i=t.uid;await Pe(i),await Fe(i),await s(t),localStorage.removeItem(q),n(`user`,null),n(`profile`,null);let a=document.getElementById(`bottom-nav`);a&&(a.style.display=`none`),p(r(`toast.withdraw_done`),`success`),e(`/login`)}function $(){return`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" style="width:16px;height:16px"><polyline points="9 18 15 12 9 6"/></svg>`}function Ke(){return`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="5"/><line x1="12" y1="1" x2="12" y2="3"/><line x1="12" y1="21" x2="12" y2="23"/><line x1="4.22" y1="4.22" x2="5.64" y2="5.64"/><line x1="18.36" y1="18.36" x2="19.78" y2="19.78"/><line x1="1" y1="12" x2="3" y2="12"/><line x1="21" y1="12" x2="23" y2="12"/><line x1="4.22" y1="19.78" x2="5.64" y2="18.36"/><line x1="18.36" y1="5.64" x2="19.78" y2="4.22"/></svg>`}function qe(){return`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z"/></svg>`}function Je(){return`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="2" y="3" width="20" height="14" rx="2" ry="2"/><line x1="8" y1="21" x2="16" y2="21"/><line x1="12" y1="17" x2="12" y2="21"/></svg>`}function Ye(){return`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 20h9"/><path d="M16.5 3.5a2.12 2.12 0 0 1 3 3L7 19l-4 1 1-4 12.5-12.5z"/></svg>`}function Xe(){return`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/><polyline points="16 17 21 12 16 7"/><line x1="21" y1="12" x2="9" y2="12"/></svg>`}function Ze(){return`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><line x1="17" y1="8" x2="22" y2="13"/><line x1="22" y1="8" x2="17" y2="13"/></svg>`}function Qe(){return`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M4 19.5A2.5 2.5 0 0 1 6.5 17H20"/><path d="M6.5 2H20v20H6.5A2.5 2.5 0 0 1 4 19.5v-15A2.5 2.5 0 0 1 6.5 2z"/></svg>`}function $e(){return`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><path d="M9.09 9a3 3 0 0 1 5.83 1c0 2-3 3-3 3"/><path d="M12 17h.01"/></svg>`}function et(){return`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 7V5a2 2 0 0 1 2-2h2"/><path d="M17 3h2a2 2 0 0 1 2 2v2"/><path d="M21 17v2a2 2 0 0 1-2 2h-2"/><path d="M7 21H5a2 2 0 0 1-2-2v-2"/><circle cx="12" cy="12" r="1"/><path d="M5 12s2.5-5 7-5 7 5 7 5-2.5 5-7 5-7-5-7-5"/></svg>`}function tt(){let e=document.createElement(`div`);return e.className=`settings-page page`,e.innerHTML=`
    ${g({title:r(`nav.settings`),backLabel:r(`common.back`)})}
    ${Re()}
  `,ze(e),_(e,()=>history.back()),e}export{tt as renderSettings};