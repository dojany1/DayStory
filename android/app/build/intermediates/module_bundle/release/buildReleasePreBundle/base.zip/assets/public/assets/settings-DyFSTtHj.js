const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/web-BLNdxmZF.js","assets/dist-N3LOKtlT.js"])))=>i.map(i=>d[i]);
import{a as e}from"./router-hybKseu2.js";import{n as t,r as n}from"./state-8PRbPWwW.js";import{r,t as i}from"./i18n-CAgB5cGO.js";import{U as a}from"./index.esm-D5wgknfe.js";import{t as o}from"./firebase-CMykNrkF.js";import{i as s,t as c}from"./dist-N3LOKtlT.js";import{t as ee}from"./preload-helper-Dd-HcVz_.js";import{t as l}from"./toast-DL5HJnQ3.js";import{n as u,t as d}from"./scrollLock-ByagqdMz.js";import{n as f,t as p}from"./pageHeader-CzG3S3Fi.js";var te;(function(e){e[e.Sunday=1]=`Sunday`,e[e.Monday=2]=`Monday`,e[e.Tuesday=3]=`Tuesday`,e[e.Wednesday=4]=`Wednesday`,e[e.Thursday=5]=`Thursday`,e[e.Friday=6]=`Friday`,e[e.Saturday=7]=`Saturday`})(te||={});var m=s(`LocalNotifications`,{web:()=>ee(()=>import(`./web-BLNdxmZF.js`).then(e=>new e.LocalNotificationsWeb),__vite__mapDeps([0,1]))}),h=`ds_notification_settings_v1`,g={diary:{enabled:!1,time:`12:00`},editor:{enabled:!1,time:`12:00`}},_={diary:{id:1001,route:`/mystory`,title:`일기 쓸 시간이에요`,body:`오늘의 기록을 남겨보세요.`},editor:{id:1002,route:`/editorstory`,title:`오늘의 일화가 도착했어요`,body:`DayStory에서 오늘의 이야기를 확인해보세요.`}},v=null,y=!1,b=null,x=new Map;function S(){let e=se();return{diary:P(e.diary,g.diary),editor:P(e.editor,g.editor)}}async function C(e,t){if(!_[e])return S();let n=S(),r=n[e],i=P({...r,...t},g[e]);return t?.enabled===!0&&(await ne()||(i.enabled=!1,l(`알림 권한이 필요합니다`,`warning`))),n[e]=i,ce(n),await re(e),S()}async function ne(){return b||=(D()?ie():ae()).finally(()=>{b=null}),b}async function re(e=null){let t=S(),n=e&&_[e]?[e]:Object.keys(_);if(!D()){oe(t,n);return}await E();let r=n.map(e=>({id:_[e].id}));try{await m.cancel({notifications:r})}catch(e){console.warn(`알림 예약 취소 실패:`,e)}let i=n.filter(e=>t[e]?.enabled).map(e=>w(e,t[e]));if(i.length)try{await m.schedule({notifications:i})}catch(e){console.warn(`알림 예약 실패:`,e),l(`알림 예약에 실패했습니다`,`error`)}}function w(e,t){let n=_[e],{hour:r,minute:i}=F(t.time);return{id:n.id,title:n.title,body:n.body,schedule:{on:{hour:r,minute:i},allowWhileIdle:!0},autoCancel:!0,channelId:`daystory_default`,extra:{type:e,route:n.route}}}var T=!1;async function E(){if(!T&&c.isNativePlatform()&&!(c.getPlatform&&c.getPlatform()!==`android`))try{await m.createChannel({id:`daystory_default`,name:`DayStory 알림`,description:`일기와 카드 알림`,importance:4,visibility:1,vibration:!0}),T=!0}catch(e){console.warn(`알림 채널 생성 실패:`,e)}}async function ie(){try{return await E(),(await m.checkPermissions()).display===`granted`?!0:(await m.requestPermissions()).display===`granted`}catch(e){return console.warn(`알림 권한 확인 실패:`,e),!1}}async function ae(){if(!O())return!1;if(Notification.permission===`granted`||y)return!0;if(Notification.permission===`denied`)return!1;try{return y=await Notification.requestPermission()===`granted`,y}catch(e){return console.warn(`웹 알림 권한 확인 실패:`,e),!1}}function D(){return c.isNativePlatform()}function O(){return typeof Notification<`u`}function k(){return O()&&(Notification.permission===`granted`||y)}function oe(e,t){t.forEach(A),k()&&t.filter(t=>e[t]?.enabled).forEach(t=>{j(t,e[t])})}function A(e){let t=x.get(e);t&&clearTimeout(t),x.delete(e)}function j(e,t){let n=N(t.time),r=setTimeout(()=>{M(e);let t=S()[e];t?.enabled&&j(e,t)},n);x.set(e,r)}function M(e){if(!k())return;let t=_[e],n=new Notification(t.title,{body:t.body,tag:`daystory-${e}`,data:{type:e,route:t.route}});n.onclick=()=>{v?.(t.route)}}function N(e){let{hour:t,minute:n}=F(e),r=new Date,i=new Date(r);return i.setHours(t,n,0,0),i<=r&&i.setDate(i.getDate()+1),i.getTime()-r.getTime()}function se(){try{return JSON.parse(localStorage.getItem(h)||`{}`)||{}}catch{return{}}}function ce(e){localStorage.setItem(h,JSON.stringify({diary:P(e.diary,g.diary),editor:P(e.editor,g.editor)}))}function P(e,t){return{enabled:!!e?.enabled,time:I(e?.time)?e.time:t.time}}function F(e){let[t,n]=(I(e)?e:`12:00`).split(`:`).map(Number);return{hour:t,minute:n}}function I(e){return typeof e==`string`&&/^([01]\d|2[0-3]):[0-5]\d$/.test(e)}var L={diary:{title:`일기 알림`,subtitle:`나의 일기 쓰기`},editor:{title:`에디터 알림`,subtitle:`오늘의 일화 확인`}},R=[{value:`AM`,label:`오전`},{value:`PM`,label:`오후`}];function z(){return`
    <div class="list-item" id="setting-notifications" role="button" tabindex="0">
      <div class="list-item-icon notification-settings-icon">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
          <path d="M6 8a6 6 0 0 1 12 0c0 7 3 9 3 9H3s3-2 3-9"/>
          <path d="M10.3 21a1.94 1.94 0 0 0 3.4 0"/>
          <path d="M4 2C2.8 3.7 2 5.7 2 8"/>
          <path d="M20 2c1.2 1.7 2 3.7 2 8"/>
        </svg>
      </div>
      <div class="list-item-content">
        <div class="list-item-title">알림</div>
        <div class="list-item-subtitle notification-settings-summary">${G()}</div>
      </div>
      <div class="list-item-action">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" style="width:16px;height:16px">
          <polyline points="9 18 15 12 9 6"/>
        </svg>
      </div>
    </div>
  `}function B(e){let t=e.querySelector(`#setting-notifications`);if(t){if(t.dataset.notificationSettingsBound===`true`)return;t.dataset.notificationSettingsBound=`true`;let n=()=>V(()=>W(e));t.addEventListener(`click`,n),t.addEventListener(`keydown`,e=>{(e.key===`Enter`||e.key===` `)&&(e.preventDefault(),n())})}}function V(e=()=>{}){let t=document.querySelector(`.notification-settings-overlay`);if(t)return t;let n=document.createElement(`div`);n.className=`notification-settings-overlay`,n.setAttribute(`role`,`dialog`),n.setAttribute(`aria-modal`,`true`),n.setAttribute(`aria-labelledby`,`notification-settings-title`),n.innerHTML=`
    <div class="notification-settings-sheet">
      ${f({title:`알림`,titleId:`notification-settings-title`,icon:`close`,backLabel:`닫기`})}
      <div class="notification-settings-list">
        ${H(`diary`)}
        ${H(`editor`)}
      </div>
    </div>
  `,(document.querySelector(`.mobile-wrapper`)||document.body).appendChild(n),d(),requestAnimationFrame(()=>n.classList.add(`visible`)),n.addEventListener(`touchmove`,e=>{e.target.closest(`.notification-settings-sheet`)||e.preventDefault()},{passive:!1});let i=!1;return p(n,()=>{i||(i=!0,u(),n.classList.remove(`visible`),n.addEventListener(`transitionend`,()=>n.remove(),{once:!0}),setTimeout(()=>{n.parentNode&&n.remove()},450))}),n.querySelectorAll(`[data-notification-toggle]`).forEach(t=>{t.addEventListener(`click`,async()=>{let i=t.dataset.notificationToggle,a=S()[i];t.setAttribute(`aria-busy`,`true`),t.disabled=!0,U(n,i,(await C(i,{enabled:!a.enabled}))[i]),W(document),l(r(`settings.notification_saved`),`success`),e(),t.disabled=!1,t.removeAttribute(`aria-busy`)})}),n.querySelectorAll(`.notification-settings-time-select`).forEach(t=>{t.addEventListener(`change`,async()=>{let r=t.dataset.notificationType;U(n,r,(await C(r,{time:le(n,r)}))[r]),W(document),e()})}),n}function H(e){let t=S()[e],n=L[e],r=K(t.time);return`
    <div class="notification-settings-row" data-notification-row="${e}">
      <div class="notification-settings-copy">
        <div class="notification-settings-row-title">${n.title}</div>
        <div class="notification-settings-row-subtitle">${n.subtitle}</div>
      </div>
      <div class="notification-settings-time-control" data-notification-time-control="${e}" aria-label="${n.title} 시간">
        <select class="notification-settings-time-select" data-notification-period="${e}" data-notification-type="${e}" aria-label="${n.title} 오전 오후">
          ${R.map(e=>`<option value="${e.value}" ${r.period===e.value?`selected`:``}>${e.label}</option>`).join(``)}
        </select>
        <select class="notification-settings-time-select" data-notification-hour="${e}" data-notification-type="${e}" aria-label="${n.title} 시">
          ${Array.from({length:12},(e,t)=>t+1).map(e=>`<option value="${String(e).padStart(2,`0`)}" ${r.hour===e?`selected`:``}>${e}시</option>`).join(``)}
        </select>
        <select class="notification-settings-time-select" data-notification-minute="${e}" data-notification-type="${e}" aria-label="${n.title} 분">
          ${Array.from({length:60},(e,t)=>`<option value="${String(t).padStart(2,`0`)}" ${r.minute===t?`selected`:``}>${String(t).padStart(2,`0`)}분</option>`).join(``)}
        </select>
      </div>
      <button type="button" class="toggle ${t.enabled?`active`:``}" data-notification-toggle="${e}" aria-label="${n.title}" aria-pressed="${t.enabled?`true`:`false`}"></button>
    </div>
  `}function U(e,t,n){let r=e.querySelector(`[data-notification-row="${t}"]`),i=r?.querySelector(`[data-notification-period="${t}"]`),a=r?.querySelector(`[data-notification-hour="${t}"]`),o=r?.querySelector(`[data-notification-minute="${t}"]`),s=r?.querySelector(`[data-notification-toggle="${t}"]`);if(!r||!i||!a||!o||!s)return;let c=K(n.time);i.value=c.period,a.value=String(c.hour).padStart(2,`0`),o.value=String(c.minute).padStart(2,`0`),s.classList.toggle(`active`,n.enabled),s.setAttribute(`aria-pressed`,n.enabled?`true`:`false`)}function W(e){e.querySelectorAll(`.notification-settings-summary`).forEach(e=>{e.textContent=G()})}function G(){let e=S();return`${e.diary.enabled?`일기 ${q(e.diary.time)}`:`일기 꺼짐`} · ${e.editor.enabled?`에디터 ${q(e.editor.time)}`:`에디터 꺼짐`}`}function le(e,t){let n=e.querySelector(`[data-notification-period="${t}"]`)?.value||`PM`,r=e.querySelector(`[data-notification-hour="${t}"]`)?.value||`12`,i=e.querySelector(`[data-notification-minute="${t}"]`)?.value||`00`;return ue(n,Number(r),i)}function K(e){let[t,n]=String(e||`12:00`).split(`:`).map(Number),r=Number.isInteger(t)?t:12,i=Number.isInteger(n)?n:0;return{period:r<12?`AM`:`PM`,hour:r%12||12,minute:i}}function q(e){let t=K(e);return`${R.find(e=>e.value===t.period)?.label||`오후`} ${t.hour}:${String(t.minute).padStart(2,`0`)}`}function ue(e,t,n){let r=Math.min(Math.max(Number(t)||12,1),12)%12;return e===`PM`&&(r+=12),`${String(r).padStart(2,`0`)}:${String(n).padStart(2,`0`)}`}var de={name:`daystory`,version:`1.3.4`,private:!0,type:`module`,scripts:{dev:`vite`,build:`vite build`,preview:`vite preview`,test:`vitest run --environment jsdom`,"harness:auto":`node scripts/codex-harness.mjs`,harness:`node scripts/codex-harness.mjs`,"harness:status":`node scripts/codex-harness.mjs --status`,"harness:commit":`node scripts/harness-commit.mjs`},devDependencies:{"@capacitor/assets":`^3.0.5`,jsdom:`^29.0.2`,vite:`^8.0.1`,vitest:`^4.1.5`},dependencies:{"@capacitor-firebase/authentication":`^8.2.0`,"@capacitor/android":`^8.3.4`,"@capacitor/app":`^8.1.0`,"@capacitor/camera":`^8.0.0`,"@capacitor/cli":`^8.3.0`,"@capacitor/core":`^8.3.0`,"@capacitor/device":`^8.0.2`,"@capacitor/ios":`^8.3.4`,"@capacitor/local-notifications":`^8.0.2`,"@capacitor/share":`^8.0.1`,"@capacitor/splash-screen":`^8.0.1`,"@capacitor/status-bar":`^8.0.2`,"@revenuecat/purchases-capacitor":`^13.1.0`,cropperjs:`^1.6.2`,firebase:`^10.14.1`}},fe=`daystory:auth-session-active`,pe=`https://0729.notion.site/336c0180451480a4b0a8c60dba754daf?source=copy_link`;function me(){let e=t(`user`),n=t(`profile`),a=t(`theme`);i();let o=Math.max(0,[`light`,`dark`,`system`].indexOf(a));return`
    ${n&&n.role===`editor`?`
    <div class="settings-section">
      <div class="settings-section-title">관리자 도구</div>
      ${Y({id:`setting-editor`,title:r(`settings.row_editor`),subtitle:r(`settings.row_editor_subtitle`),icon:we()})}
    </div>
    `:``}

    <div class="settings-section">
      <div class="settings-section-title">앱 설정</div>
      <div class="theme-option-group" role="group" aria-label="${r(`settings.section_display`)}" data-active="${o}">
        ${J(`light`,r(`settings.theme_light`),a,$())}
        ${J(`dark`,r(`settings.theme_dark`),a,Se())}
        ${J(`system`,r(`settings.theme_system`),a,Ce())}
        <span class="theme-option-thumb" aria-hidden="true"></span>
      </div>
      ${z()}
      ${_e()}
    </div>

    <div class="settings-section">
      <div class="settings-section-title">지원</div>
      ${Y({id:`setting-about`,title:r(`settings.row_about`),subtitle:r(`settings.row_about_subtitle`),icon:Ee()})}
      ${Y({id:`setting-contact`,title:`문의`,icon:De()})}
    </div>

    ${e&&e.id!==`guest`?`
    <div class="settings-section">
      ${Y({id:`setting-logout`,title:r(`settings.row_logout`),icon:Te(),titleClass:`settings-row-danger`,showChevron:!1})}
    </div>
    `:``}

    <div class="settings-privacy-link">
      <a href="${pe}" target="_blank" rel="noopener noreferrer">
        ${r(`settings.privacy_link`)}
      </a>
    </div>

    <div class="settings-version">
      DayStory v${de.version}
    </div>
  `}function he(t){B(t),ge(t),ve(t),Z(t,`#setting-editor`,()=>e(`/editor`)),Z(t,`#setting-about`,()=>e(`/about`)),Z(t,`#setting-contact`,()=>l(`준비중인 기능입니다. 업데이트를 기다려주세요!`,`info`)),Z(t,`#setting-logout`,be)}function J(e,t,n,r){return`
    <button type="button" class="theme-option ${n===e?`active`:``}" data-theme="${e}" aria-pressed="${n===e?`true`:`false`}">
      ${r}
      <span class="theme-option-label">${t}</span>
    </button>
  `}function Y({id:e,title:t,subtitle:n=``,icon:r,titleClass:i=``,showChevron:a=!0}){return`
    <div class="list-item" id="${e}" role="button" tabindex="0">
      <div class="list-item-icon">${r}</div>
      <div class="list-item-content">
        <div class="list-item-title ${i}">${t}</div>
        ${n?`<div class="list-item-subtitle">${n}</div>`:``}
      </div>
      <div class="list-item-action">
        ${a?Q():``}
      </div>
    </div>
  `}function ge(e){e.querySelectorAll(`.theme-option[data-theme]`).forEach(e=>{e.addEventListener(`click`,()=>{let t=e.dataset.theme;n(`theme`,t);let i=e.closest(`.theme-option-group`),a=[...i.querySelectorAll(`.theme-option[data-theme]`)];a.forEach(e=>{e.classList.remove(`active`),e.setAttribute(`aria-pressed`,`false`)}),e.classList.add(`active`),e.setAttribute(`aria-pressed`,`true`),i.dataset.active=a.indexOf(e),l(r(`settings.theme_changed`,{label:xe(t)}),`success`)})})}function _e(){let e=(localStorage.getItem(`ds_default_view`)||`card`)===`calendar`?r(`settings.view_calendar`):r(`settings.view_card`);return`
    <div class="list-item" id="setting-view-mode" role="button" tabindex="0">
      <div class="list-item-icon">${Oe()}</div>
      <div class="list-item-content">
        <div class="list-item-title">${r(`settings.section_view_mode`)}</div>
        <div class="list-item-subtitle" id="view-mode-summary">${e}</div>
      </div>
      <div class="list-item-action">${Q()}</div>
    </div>
  `}function ve(e){let t=e.querySelector(`#setting-view-mode`);if(!t)return;let n=()=>ye(()=>X(e));t.addEventListener(`click`,n),t.addEventListener(`keydown`,e=>{(e.key===`Enter`||e.key===` `)&&(e.preventDefault(),n())})}function ye(e=()=>{}){if(document.querySelector(`.view-mode-settings-overlay`))return;let t=localStorage.getItem(`ds_default_view`)||`card`,n=document.createElement(`div`);n.className=`notification-settings-overlay view-mode-settings-overlay`,n.setAttribute(`role`,`dialog`),n.setAttribute(`aria-modal`,`true`),n.innerHTML=`
    <div class="notification-settings-sheet">
      ${f({title:r(`settings.section_view_mode`),icon:`close`,backLabel:`닫기`})}
      <div class="notification-settings-list" role="radiogroup">
        <button type="button" class="list-item view-mode-option ${t===`card`?`active`:``}" data-view="card" role="radio" aria-checked="${t===`card`}">
          <div class="list-item-icon">
            <svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M2 7v10"/><path d="M6 5v14"/><rect width="12" height="18" x="10" y="3" rx="2"/></svg>
          </div>
          <div class="list-item-content">
            <div class="list-item-title">${r(`settings.view_card_action`)}</div>
          </div>
          <div class="list-item-action">
            <svg class="view-mode-check" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"/></svg>
          </div>
        </button>
        <button type="button" class="list-item view-mode-option ${t===`calendar`?`active`:``}" data-view="calendar" role="radio" aria-checked="${t===`calendar`}">
          <div class="list-item-icon">
            <svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M8 2v4"/><path d="M16 2v4"/><rect width="18" height="18" x="3" y="4" rx="2"/><path d="M3 10h18"/><path d="M8 14h.01"/><path d="M12 14h.01"/><path d="M16 14h.01"/><path d="M8 18h.01"/><path d="M12 18h.01"/><path d="M16 18h.01"/></svg>
          </div>
          <div class="list-item-content">
            <div class="list-item-title">${r(`settings.view_calendar_action`)}</div>
          </div>
          <div class="list-item-action">
            <svg class="view-mode-check" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"/></svg>
          </div>
        </button>
      </div>
    </div>
  `,(document.querySelector(`.mobile-wrapper`)||document.body).appendChild(n),d(),requestAnimationFrame(()=>n.classList.add(`visible`));let i=!1;p(n,()=>{i||(i=!0,u(),n.classList.remove(`visible`),n.addEventListener(`transitionend`,()=>n.remove(),{once:!0}),setTimeout(()=>{n.parentNode&&n.remove()},450))}),n.querySelectorAll(`.view-mode-option[data-view]`).forEach(t=>{t.addEventListener(`click`,()=>{let i=t.dataset.view;localStorage.getItem(`ds_default_view`)!==i&&(localStorage.setItem(`ds_default_view`,i),n.querySelectorAll(`.view-mode-option`).forEach(e=>{e.classList.remove(`active`),e.setAttribute(`aria-checked`,`false`)}),t.classList.add(`active`),t.setAttribute(`aria-checked`,`true`),l(r(`settings.view_mode_changed`),`success`),X(document),e())})})}function X(e){let t=e.querySelector(`#view-mode-summary`);t&&(t.textContent=(localStorage.getItem(`ds_default_view`)||`card`)===`calendar`?r(`settings.view_calendar`):r(`settings.view_card`))}function Z(e,t,n){let r=e.querySelector(t);r&&(r.addEventListener(`click`,n),r.addEventListener(`keydown`,e=>{e.key!==`Enter`&&e.key!==` `||(e.preventDefault(),n(e))}))}async function be(){try{o&&await Promise.race([a(o),new Promise(e=>setTimeout(e,2e3))])}catch(e){console.warn(`로그아웃 오류 (무시됨):`,e)}localStorage.removeItem(fe),n(`user`,null),n(`profile`,null);let e=document.getElementById(`bottom-nav`);e&&(e.style.display=`none`),window.location.hash=`#/login`,l(r(`toast.logged_out`),`success`)}function xe(e){return{system:r(`settings.theme_system`),light:r(`settings.theme_light`),dark:r(`settings.theme_dark`)}[e]}function Q(){return`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" style="width:16px;height:16px"><polyline points="9 18 15 12 9 6"/></svg>`}function $(){return`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="5"/><line x1="12" y1="1" x2="12" y2="3"/><line x1="12" y1="21" x2="12" y2="23"/><line x1="4.22" y1="4.22" x2="5.64" y2="5.64"/><line x1="18.36" y1="18.36" x2="19.78" y2="19.78"/><line x1="1" y1="12" x2="3" y2="12"/><line x1="21" y1="12" x2="23" y2="12"/><line x1="4.22" y1="19.78" x2="5.64" y2="18.36"/><line x1="18.36" y1="5.64" x2="19.78" y2="4.22"/></svg>`}function Se(){return`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z"/></svg>`}function Ce(){return`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="2" y="3" width="20" height="14" rx="2" ry="2"/><line x1="8" y1="21" x2="16" y2="21"/><line x1="12" y1="17" x2="12" y2="21"/></svg>`}function we(){return`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 20h9"/><path d="M16.5 3.5a2.12 2.12 0 0 1 3 3L7 19l-4 1 1-4 12.5-12.5z"/></svg>`}function Te(){return`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/><polyline points="16 17 21 12 16 7"/><line x1="21" y1="12" x2="9" y2="12"/></svg>`}function Ee(){return`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M4 19.5A2.5 2.5 0 0 1 6.5 17H20"/><path d="M6.5 2H20v20H6.5A2.5 2.5 0 0 1 4 19.5v-15A2.5 2.5 0 0 1 6.5 2z"/></svg>`}function De(){return`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><path d="M9.09 9a3 3 0 0 1 5.83 1c0 2-3 3-3 3"/><path d="M12 17h.01"/></svg>`}function Oe(){return`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 7V5a2 2 0 0 1 2-2h2"/><path d="M17 3h2a2 2 0 0 1 2 2v2"/><path d="M21 17v2a2 2 0 0 1-2 2h-2"/><path d="M7 21H5a2 2 0 0 1-2-2v-2"/><circle cx="12" cy="12" r="1"/><path d="M5 12s2.5-5 7-5 7 5 7 5-2.5 5-7 5-7-5-7-5"/></svg>`}function ke(){let e=document.createElement(`div`);return e.className=`settings-page page`,e.innerHTML=`
    ${f({title:r(`nav.settings`),backLabel:r(`common.back`)})}
    ${me()}
  `,he(e),p(e,()=>history.back()),e}export{ke as renderSettings};